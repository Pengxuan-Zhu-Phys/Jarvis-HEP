[Prospino2](http://www.thphys.uni-heidelberg.de/~plehn/index.php?show=prospino)
=========

### Authors

   W. Beenakker, R. Hopker, M. Spira, and T. Plehn

### References
 * http://www.thphys.uni-heidelberg.de/~plehn/index.php?show=prospino and references therein for respective processes.
 * For old versions, [arXiv:hep-ph/9611231](http://arxiv.org/abs/hep-ph/9611232).

