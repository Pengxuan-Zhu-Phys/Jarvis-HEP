#define VERSION  "3.8.9"
#define VERSION_ "CalcHEP  " VERSION
