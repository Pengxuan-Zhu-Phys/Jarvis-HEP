#ifndef __N_COMPHEP__
#define __N_COMPHEP__

extern void n_comphep(void);
#endif
