#include<stdlib.h>

#ifndef __V_and_P_size__
#define __V_and_P_size__

#define VAR_NAME_SIZE 12
#define P_NAME_SIZE 12

#endif