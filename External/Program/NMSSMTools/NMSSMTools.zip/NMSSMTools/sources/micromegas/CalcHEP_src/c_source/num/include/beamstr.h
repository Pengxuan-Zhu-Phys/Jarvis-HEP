#ifndef __BEAMSTR__
#define __BEAMSTR__

extern void initISR( double beta, double coef, 
int bON, double bNcl, double bips, double *xi, double *yi, int nn);

#endif
