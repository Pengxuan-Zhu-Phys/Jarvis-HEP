extern int FError;
int  FError=0;
