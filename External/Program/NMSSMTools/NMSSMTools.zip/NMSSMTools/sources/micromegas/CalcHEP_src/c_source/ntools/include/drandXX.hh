#ifndef __RANDOM__
#define __RANDOM__
  extern double drandXX(void);
  extern  char * seedXX(char * init);
#endif
