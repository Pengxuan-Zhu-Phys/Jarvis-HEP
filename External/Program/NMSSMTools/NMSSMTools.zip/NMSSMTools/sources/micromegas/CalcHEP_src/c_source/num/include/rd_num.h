#ifndef __RD_NUM__
#define __RD_NUM__

extern int rd_num(char * s, double * p);

#endif
