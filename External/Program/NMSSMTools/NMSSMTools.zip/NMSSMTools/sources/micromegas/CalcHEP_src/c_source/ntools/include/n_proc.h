#ifndef __NPROCSS__
#define __NPROCSS__

extern int nPROCSS;

#endif
