#ifndef __VIEWDIR__
#define __VIEWDIR__
extern int viewDir(char * dirName);
extern int checkDir(char * dirName);
#endif 

