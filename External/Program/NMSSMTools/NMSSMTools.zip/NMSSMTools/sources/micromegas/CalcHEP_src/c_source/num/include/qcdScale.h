#ifndef __qcdScale__
#define __qcdScale__

extern int initScales(char*strR,char*strF1,char*strF2,char*strShower,char*mess);
extern void Scale(int nsub,double*,double*,double*,double*,double*);

#endif
