#ifndef __SF_EPA__
#define __SF_EPA__

extern int p_epa__(int* pNum);
extern void n_epa__(int i, char *name);
extern int r_epa__(int i, char *name);
extern int m_epa__(int i, int*);
extern int mc_epa__(int i);
extern int  i_epa__(int i, double * be, double * mass);
extern double c_epa__(int i, double x,double q);
#endif
