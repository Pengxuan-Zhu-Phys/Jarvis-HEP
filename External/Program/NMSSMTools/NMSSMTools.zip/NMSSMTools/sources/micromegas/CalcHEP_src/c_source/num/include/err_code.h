#ifndef __ERR_CODE__
#define __ERR_CODE__

extern int err_code;
extern void errormessage(void);
#endif
