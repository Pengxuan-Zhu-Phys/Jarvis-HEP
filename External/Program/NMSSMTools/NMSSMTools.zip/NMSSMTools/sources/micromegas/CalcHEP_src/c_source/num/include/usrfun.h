#ifndef __USR_PARAM__
#define __USR_PARAM__

extern double usrfun(char * param, int n_in, int n_out,double * pvect,char** pnames,int*pdg);
extern double usrFF(int n_in,int n_out, double *pvect,char**pnames,int*pdg);
#endif
