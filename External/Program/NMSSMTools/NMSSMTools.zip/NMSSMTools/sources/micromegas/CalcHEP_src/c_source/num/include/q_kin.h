#ifndef __Q_KIN__
#define __Q_KIN__

#include"nType.h"

extern int mkmom(double*x,double*tfact,double*x1,double*x2,REAL*pv);
extern int imkmom(double P1,double P2);

#endif
