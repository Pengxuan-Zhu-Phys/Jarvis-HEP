* 2to2.h
* common blocks for 2to2.F
* this file is part of FormCalc
* last modified 25 Apr 04 th


#include "model.h"

	double precision preflux, flux, sqrtS, Pout
	integer helicities
	logical reset
	common /var2to2/ preflux, flux, sqrtS, Pout,
     &    helicities, reset

