#!/bin/sh -x

./custombetas.x --slha-input-file=LesHouches.in.MSSMcbs
