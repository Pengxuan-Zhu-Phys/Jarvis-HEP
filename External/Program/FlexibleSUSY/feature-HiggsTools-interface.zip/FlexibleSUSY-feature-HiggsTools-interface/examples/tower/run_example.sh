#!/bin/sh -x

./run_tower.x --slha-input-file=LesHouches.in.tower --slha-output-file=
