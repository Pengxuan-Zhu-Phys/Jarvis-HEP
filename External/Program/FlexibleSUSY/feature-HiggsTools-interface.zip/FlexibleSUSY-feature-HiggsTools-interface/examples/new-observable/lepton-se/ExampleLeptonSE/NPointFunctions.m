topologies[1] = {
   Tadpoles -> tadpole,
   Sunsets  -> sunset,
   Fermi    -> all
};
