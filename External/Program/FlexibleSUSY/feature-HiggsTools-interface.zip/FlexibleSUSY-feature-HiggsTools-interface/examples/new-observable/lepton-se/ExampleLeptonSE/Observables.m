Observables`DefineObservable[
   FlexibleSUSYObservable`ExampleLeptonSE[field_@gen_, contr_],
   GetObservableType        -> {2},
   GetObservablePrototype   -> "ex_lepton_se_contr(int gen, auto model)"
];
