Observables`DefineObservable[
   FlexibleSUSYObservable`ExampleConstantObservable[num_],
   GetObservableType        -> {1},
   GetObservablePrototype   -> "calculate_example_constant_observable(double num)"
];
