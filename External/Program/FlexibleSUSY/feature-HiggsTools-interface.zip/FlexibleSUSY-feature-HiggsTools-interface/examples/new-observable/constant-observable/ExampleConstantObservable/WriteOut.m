WriteOut`WriteObservable[
   "FlexibleSUSYLowEnergy",
   obs:FlexibleSUSYObservable`ExampleConstantObservable[_]
] := "Re(observables." <> Observables`GetObservableName@obs <> "(0))";
