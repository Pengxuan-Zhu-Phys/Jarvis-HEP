topologies[1] = {
   All -> triangle
};

momenta[1] = {
   triangle -> 1
};
