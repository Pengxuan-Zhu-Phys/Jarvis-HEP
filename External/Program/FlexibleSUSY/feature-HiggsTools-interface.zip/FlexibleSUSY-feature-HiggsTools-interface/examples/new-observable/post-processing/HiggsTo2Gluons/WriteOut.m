WriteOut`WriteObservable[
   "FlexibleSUSYLowEnergy",
   obs:FlexibleSUSYObservable`HiggsTo2Gluons[__]
] := "Re(observables." <> Observables`GetObservableName[obs] <> "(0))";
