Observables`DefineObservable[
   FlexibleSUSYObservable`ExampleFermionMass[fermion_@gen_],
   GetObservableType        -> {2},
   GetObservablePrototype   -> "ex_fermion_mass(int gen, auto model, auto qedqcd)",
   GetObservableDescription -> "fermion[gen] (lepton[gen] if in Block ExampleLeptonMass) mass"
];
