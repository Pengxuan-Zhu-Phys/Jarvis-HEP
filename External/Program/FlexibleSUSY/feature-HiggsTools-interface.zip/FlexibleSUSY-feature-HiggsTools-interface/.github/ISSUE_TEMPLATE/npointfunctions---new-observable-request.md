---
name: NPointFunctions - new observable request
about: Request adding a new observable
title: "[NPointFunctions]"
labels: ''
assignees: uukhas

---

**Specify the observable you'd like to see computed**
