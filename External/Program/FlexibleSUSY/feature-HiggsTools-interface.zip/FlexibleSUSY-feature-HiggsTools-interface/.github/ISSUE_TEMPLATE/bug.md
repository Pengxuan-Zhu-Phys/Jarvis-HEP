---
name: Bug
about: Use this template for reporting a bug.
title: "[BUG DESCRIPTION]"
labels: bug
assignees: expander,wkotlarski
---
### Bug description

### Steps to reproduce

### Context information
* Operating system:
* FlexibleSUSY version:
* SARAH version:

### Anything else
