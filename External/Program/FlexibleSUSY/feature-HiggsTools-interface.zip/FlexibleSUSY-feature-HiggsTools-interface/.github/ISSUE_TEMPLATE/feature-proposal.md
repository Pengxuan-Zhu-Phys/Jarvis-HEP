---
name: Feature proposal
about: Use this template to propose a new feature.
title: "[FEATURE DESCRIPTION]"
labels: enhancement
assignees: expander,pathron,wkotlarski
---
### Feature description

### Why it is important
