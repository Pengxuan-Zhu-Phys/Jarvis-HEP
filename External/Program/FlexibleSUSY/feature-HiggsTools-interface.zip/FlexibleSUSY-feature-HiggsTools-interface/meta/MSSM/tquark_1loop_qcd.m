+GSY^2*(+colorCF)+GS^2*(+4*colorCF)+Log[mmt/mmu]*GS^2*(-3*colorCF	)

