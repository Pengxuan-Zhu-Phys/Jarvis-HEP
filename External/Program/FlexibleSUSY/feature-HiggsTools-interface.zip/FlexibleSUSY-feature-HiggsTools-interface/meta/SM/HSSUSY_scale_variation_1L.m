(* Created by Wolfram Mathematica 9.0 : www.wolfram.com *)
(27*g1^4*Log[MS/Q] + 90*g1^2*g2^2*Log[MS/Q] + 225*g2^4*Log[MS/Q] - 
   1200*gb^4*Log[MS/Q] - 1200*gt^4*Log[MS/Q] - 400*gtau^4*Log[MS/Q] - 
   27*g1^4*Cos[2*ArcTan[tb]]^2*Log[MS/Q] - 180*g1^2*g2^2*Cos[2*ArcTan[tb]]^2*
    Log[MS/Q] - 225*g2^4*Cos[2*ArcTan[tb]]^2*Log[MS/Q] + 
   180*g1^2*gb^2*Cos[2*ArcTan[tb]]^2*Log[MS/Q] + 
   300*g2^2*gb^2*Cos[2*ArcTan[tb]]^2*Log[MS/Q] + 
   180*g1^2*gt^2*Cos[2*ArcTan[tb]]^2*Log[MS/Q] + 
   300*g2^2*gt^2*Cos[2*ArcTan[tb]]^2*Log[MS/Q] + 
   60*g1^2*gtau^2*Cos[2*ArcTan[tb]]^2*Log[MS/Q] + 
   100*g2^2*gtau^2*Cos[2*ArcTan[tb]]^2*Log[MS/Q] + 
   27*g1^4*Cos[2*ArcTan[tb]]^4*Log[MS/Q] + 90*g1^2*g2^2*Cos[2*ArcTan[tb]]^4*
    Log[MS/Q] + 75*g2^4*Cos[2*ArcTan[tb]]^4*Log[MS/Q])/100 + 
 (-(Cos[2*ArcTan[tb]]^2*((123*g1^4*Log[MS/Q])/25 - (19*g2^4*Log[MS/Q])/3)) - 
   ((3*g1^2)/5 + g2^2)*((12*gt^2*Cos[2*ArcTan[tb]]*Log[MS/Q]*
       Sin[2*ArcTan[tb]])/tb - 12*gb^2*tb*Cos[2*ArcTan[tb]]*Log[MS/Q]*
      Sin[2*ArcTan[tb]] - 4*gtau^2*tb*Cos[2*ArcTan[tb]]*Log[MS/Q]*
      Sin[2*ArcTan[tb]]))/4
