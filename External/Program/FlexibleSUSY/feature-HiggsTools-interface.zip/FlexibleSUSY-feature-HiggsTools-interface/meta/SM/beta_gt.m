{gt (-((17 g1^2)/20) - (9 g2^2)/4 - 8 g3^2 + (3 gb^2)/2 + (9 gt^2)/2 +
 g\[Tau]^2),

 -(1/1200) gt (-2374 g1^4 + 5 g1^2 (108 g2^2 - 304 g3^2 - 3 (7 gb^2 +
  393 gt^2 + 150 g\[Tau]^2)) + 75 (92 g2^4 - 3 g2^2 (48 g3^2 + 33 gb^2
  + 75 gt^2 + 10 g\[Tau]^2) + 4 (432 g3^4 + gb^4 + 48 gt^4 - 16 g3^2
  (gb^2 + 9 gt^2) + 9 gt^2 g\[Tau]^2 + 9 g\[Tau]^4 + gb^2 (11 gt^2 - 5
  g\[Tau]^2) + 24 gt^2 \[Lambda] - 6 \[Lambda]^2))),

 (1/288000) gt (g1^6 (9162276 - 3765024 Zeta[3]) - 15 g1^4 (40673 gb^2
 + 458179 gt^2 + 289770 g\[Tau]^2 + 26136 \[Lambda] + 19104 gb^2
 Zeta[3] + 8928 gt^2 Zeta[3] + 154944 g\[Tau]^2 Zeta[3] + 36 g2^2
 (-2045 + 3672 Zeta[3]) + 128 g3^2 (-2047 + 4488 Zeta[3])) - 150 g1^2
 (54 g2^4 (-91 + 216 Zeta[3]) + 9 g2^2 (3424 g3^2 - 2699 gt^2 + 694
 g\[Tau]^2 - 312 \[Lambda] - 3936 gt^2 Zeta[3] + 384 g\[Tau]^2 Zeta[3]
 - 3 gb^2 (415 + 192 Zeta[3])) + 4 (gb^4 (2877 - 912 Zeta[3]) + 8 g3^4
 (-1633 + 2112 Zeta[3]) + 16 g3^2 (108 gt^2 (7 - 10 Zeta[3]) + gb^2
 (457 + 168 Zeta[3])) + gb^2 (gt^2 (4149 - 240 Zeta[3]) + 4 g\[Tau]^2
 (-491 + 648 Zeta[3])) + 6 (2437 gt^4 + gt^2 (508 \[Lambda] - 48
 g\[Tau]^2 (-21 + 8 Zeta[3])) + 9 (-20 \[Lambda]^2 + 3 g\[Tau]^4 (5 +
 16 Zeta[3]))))) + 125 (20 g2^6 (91 + 16200 Zeta[3]) - 27 g2^4 (-10797
 gt^2 - 742 g\[Tau]^2 + 456 \[Lambda] + 7776 gt^2 Zeta[3] + 1728
 g\[Tau]^2 Zeta[3] + 64 g3^2 (-145 + 144 Zeta[3]) + 3 gb^2 (-1149 +
 800 Zeta[3])) - 216 g2^2 (gb^4 (761 - 336 Zeta[3]) + 8 g3^4 (-329 +
 192 Zeta[3]) + 16 g3^2 (8 gt^2 (14 - 15 Zeta[3]) + 9 gb^2 (1 + 8
 Zeta[3])) + gb^2 (12 g\[Tau]^2 (17 - 8 Zeta[3]) + gt^2 (769 + 48
 Zeta[3])) + 6 (177 gt^4 - 20 \[Lambda]^2 + g\[Tau]^4 (35 - 16
 Zeta[3]) + 4 gt^2 (15 \[Lambda] + g\[Tau]^2 (9 + 4 Zeta[3])))) + 48
 (32 g3^6 (-2083 + 960 Zeta[3]) + 3 (71 g\[Tau]^6 + 120 g\[Tau]^4
 \[Lambda] - 90 g\[Tau]^2 \[Lambda]^2 - 72 \[Lambda]^3 + 24 gt^4 (7
 g\[Tau]^2 + 66 \[Lambda]) + 3 gt^2 (138 g\[Tau]^4 + 80 g\[Tau]^2
 \[Lambda] + 5 \[Lambda]^2) + gb^2 (739 gt^4 + 212 g\[Tau]^4 - 291
 \[Lambda]^2 + 8 gt^2 (7 g\[Tau]^2 + 93 \[Lambda])) + 2 gb^4 (176
 g\[Tau]^2 + 60 \[Lambda] + gt^2 (825 - 384 Zeta[3])) + 48 g\[Tau]^6
 Zeta[3] + 9 gb^6 (53 + 8 Zeta[3]) + 6 gt^6 (113 + 36 Zeta[3])) - 8
 g3^4 (3 gb^2 (305 + 88 Zeta[3]) + gt^2 (-3827 + 1368 Zeta[3])) - 8
 g3^2 (3 gt^2 (314 gt^2 - 5 g\[Tau]^2 - 16 \[Lambda]) + 12 gb^4 (-41 +
 32 Zeta[3]) + gb^2 (43 g\[Tau]^2 + 6 gt^2 (-27 + 32 Zeta[3])))))),

 (* from Chetyrkin, Zoller [JHEP 1606 (2016) 175] [arXiv:1604.00853]
    https://www.ttp.kit.edu/Progdata/ttp16/ttp16-008/ *)
 -(1/ 81) g3^8 gt (1379027 + 6048 \[Pi]^4 - 2277312 Zeta[3] + 561600
   Zeta[5])
}
