(* Created by Wolfram Mathematica 9.0 : www.wolfram.com *)
-2944*g3^4*gt^4*Log[MS/Q]^3 + 4416*g3^2*gt^6*Log[MS/Q]^3 - 
 1548*gt^8*Log[MS/Q]^3 - 
 256*Pi^4*
  ((-((-14*g3^4*gt^4*Log[MS/Q] + (g3^2*gt^3*(-160*g3^2*gt*Log[MS/Q] + 
           90*gt^3*Log[MS/Q]))/5)*
       (((At - \[Mu]/tb)*(24 + (12*(At - \[Mu]/tb))/M3 - 
           (28*(At - \[Mu]/tb)^2)/M3^2 - (At - \[Mu]/tb)^3/M3^3 + 
           (2*(At - \[Mu]/tb)^4)/M3^4))/M3 - 
        (2*(At - \[Mu]/tb)*(24 - (24*(At - \[Mu]/tb))/M3 - 
           (4*(At - \[Mu]/tb)^2)/M3^2 + (At - \[Mu]/tb)^3/M3^3)*
          Log[Sqrt[mq2[3, 3]*mu2[3, 3]]/Q^2])/M3 + 
        36*Log[Sqrt[mq2[3, 3]*mu2[3, 3]]/Q^2]^2)) - 
     g3^2*gt^4*((2*(5*At^4*tb^4 - 2*At^3*M3*tb^4 - 42*At^2*M3^2*tb^4 + 
          12*At*M3^3*tb^4 + 12*M3^4*tb^4 - 20*At^3*tb^3*\[Mu] + 
          6*At^2*M3*tb^3*\[Mu] + 84*At*M3^2*tb^3*\[Mu] - 12*M3^3*tb^3*\[Mu] + 
          30*At^2*tb^2*\[Mu]^2 - 6*At*M3*tb^2*\[Mu]^2 - 
          42*M3^2*tb^2*\[Mu]^2 - 20*At*tb*\[Mu]^3 + 2*M3*tb*\[Mu]^3 + 
          5*\[Mu]^4)*(180*At*gt^2*tb*Log[MS/Q] + 90*At*g3^2*tb^3*Log[MS/Q] + 
          180*At*gt^2*tb^3*Log[MS/Q] + 160*g3^2*M3*tb^3*Log[MS/Q] - 
          90*gt^2*\[Mu]*Log[MS/Q] - 90*g3^2*tb^2*\[Mu]*Log[MS/Q] - 
          90*gt^2*tb^2*\[Mu]*Log[MS/Q]))/(15*M3^5*tb^7) + 
       (36*Log[Sqrt[mq2[3, 3]*mu2[3, 3]]/Q^2]*
         (mu2[3, 3]*((-32*g3^2*M3^2*Log[MS/Q])/3 + (2*gt^2*mA^2*Log[MS/Q])/
             tb^2 + (2*At^2*gt^2*(1 + tb^2)*Log[MS/Q])/tb^2 - 
            (2*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/tb^2 + 
            (2*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3])/tb^2 + 
            (2*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^2) + 
          mq2[3, 3]*((-32*g3^2*M3^2*Log[MS/Q])/3 + (4*gt^2*mA^2*Log[MS/Q])/
             tb^2 + (4*At^2*gt^2*(1 + tb^2)*Log[MS/Q])/tb^2 - 
            (4*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/tb^2 + 
            (4*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3])/tb^2 + 
            (4*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^2)))/
        (mq2[3, 3]*mu2[3, 3]) - 
       2*(-((At - \[Mu]/tb)*(-3*At^2*tb^2 + 8*At*M3*tb^2 + 24*M3^2*tb^2 + 
             6*At*tb*\[Mu] - 8*M3*tb*\[Mu] - 3*\[Mu]^2)*
            (180*At*gt^2*tb*Log[MS/Q] + 90*At*g3^2*tb^3*Log[MS/Q] + 
             180*At*gt^2*tb^3*Log[MS/Q] + 160*g3^2*M3*tb^3*Log[MS/Q] - 
             90*gt^2*\[Mu]*Log[MS/Q] - 90*g3^2*tb^2*\[Mu]*Log[MS/Q] - 
             90*gt^2*tb^2*\[Mu]*Log[MS/Q])*Log[Sqrt[mq2[3, 3]*mu2[3, 3]]/
              Q^2])/(15*M3^4*tb^5) + (24 - (24*(At - \[Mu]/tb))/M3 - 
           (4*(At - \[Mu]/tb)^2)/M3^2 + (At - \[Mu]/tb)^3/M3^3)*
          ((((32*g3^2*M3*Log[MS/Q])/3 + (12*At*gt^2*(1 + tb^2)*Log[MS/Q])/tb^
                2 - (3*(10*gt^2*\[Mu]*Log[MS/Q] + 10*gt^2*tb^2*\[Mu]*
                  Log[MS/Q]))/(5*tb^3))*Log[Sqrt[mq2[3, 3]*mu2[3, 3]]/Q^2])/
            M3 + (At - \[Mu]/tb)*((6*g3^2*Log[MS/Q]*Log[
                Sqrt[mq2[3, 3]*mu2[3, 3]]/Q^2])/M3 + 
             (mu2[3, 3]*((-32*g3^2*M3^2*Log[MS/Q])/3 + (2*gt^2*mA^2*
                   Log[MS/Q])/tb^2 + (2*At^2*gt^2*(1 + tb^2)*Log[MS/Q])/
                  tb^2 - (2*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/tb^2 + 
                 (2*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3])/tb^2 + 
                 (2*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^2) + mq2[3, 3]*
                ((-32*g3^2*M3^2*Log[MS/Q])/3 + (4*gt^2*mA^2*Log[MS/Q])/tb^2 + 
                 (4*At^2*gt^2*(1 + tb^2)*Log[MS/Q])/tb^2 - (4*gt^2*(1 + tb^2)*
                   \[Mu]^2*Log[MS/Q])/tb^2 + (4*gt^2*(1 + tb^2)*Log[MS/Q]*
                   mq2[3, 3])/tb^2 + (4*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/
                  tb^2))/(2*M3*mq2[3, 3]*mu2[3, 3]))))))/(192*Pi^4) + 
   (3*(((-6*gt^8*(1 + tb^2)*Log[MS/Q])/tb^2 + (1 + tb^2)*
         ((6*gt^8*(1 + tb^2)*Log[MS/Q])/tb^4 + 
          (3*gt^5*(-160*g3^2*gt*Log[MS/Q] + 90*gt^3*Log[MS/Q]))/(10*tb^2)))*
       (-1/2 - 8.34993159891064/(1 + tb^2) - 
        4*Log[Sqrt[mq2[3, 3]*mu2[3, 3]]/Q^2] + 
        (13*Log[Sqrt[mq2[3, 3]*mu2[3, 3]]/Q^2])/(1 + tb^2) + 
        3*Log[Sqrt[mq2[3, 3]*mu2[3, 3]]/Q^2]^2 - 
        (3*Log[Sqrt[mq2[3, 3]*mu2[3, 3]]/Q^2]^2)/(1 + tb^2) - 
        (2*(At*tb - \[Mu])^3*(At*tb - \[Mu] + 2*tb*\[Mu]*Csc[2*ArcTan[tb]])*
          (-68343/156250 + Log[Sqrt[mq2[3, 3]*mu2[3, 3]]/Q^2]))/
         (tb^4*(1 + tb^2)*mq2[3, 3]*mu2[3, 3]) + 
        ((-(At*tb) + \[Mu])^6*(-1 + Log[Sqrt[mq2[3, 3]*mu2[3, 3]]/Q^2]))/
         (2*tb^4*(1 + tb^2)*(mq2[3, 3]*mu2[3, 3])^(3/2)) + 
        (19*\[Mu]^2)/(2*Sqrt[mq2[3, 3]*mu2[3, 3]]) - 
        (6*\[Mu]^2*Log[Sqrt[mq2[3, 3]*mu2[3, 3]]/Q^2])/
         Sqrt[mq2[3, 3]*mu2[3, 3]] + (12*(At*tb - \[Mu])*
          (At*tb - \[Mu] + 2*tb*\[Mu]*Csc[2*ArcTan[tb]])*
          (9782/234375 + Log[Sqrt[mq2[3, 3]*mu2[3, 3]]/Q^2]))/
         (tb^2*(1 + tb^2)*Sqrt[mq2[3, 3]*mu2[3, 3]]) + 
        (3*(At*tb - \[Mu] + 2*tb*\[Mu]*Csc[2*ArcTan[tb]])^2*
          (9782/234375 + Log[Sqrt[mq2[3, 3]*mu2[3, 3]]/Q^2]))/
         (tb^2*(1 + tb^2)*Sqrt[mq2[3, 3]*mu2[3, 3]]) + 
        ((At - \[Mu]/tb)^4*(25 - 25/(1 + tb^2) - 
           26*Log[Sqrt[mq2[3, 3]*mu2[3, 3]]/Q^2] + 
           (24*Log[Sqrt[mq2[3, 3]*mu2[3, 3]]/Q^2])/(1 + tb^2) + 
           \[Mu]^2/Sqrt[mq2[3, 3]*mu2[3, 3]] + 
           (2*(At*tb - \[Mu] + 2*tb*\[Mu]*Csc[2*ArcTan[tb]])^2*
             (-19433/468750 + Log[Sqrt[mq2[3, 3]*mu2[3, 3]]/Q^2]))/
            (tb^2*(1 + tb^2)*Sqrt[mq2[3, 3]*mu2[3, 3]]) - 
           (4*\[Mu]^2*Log[Sqrt[mq2[3, 3]*mu2[3, 3]]/Q^2])/
            Sqrt[mq2[3, 3]*mu2[3, 3]]))/(4*mq2[3, 3]*mu2[3, 3]) + 
        ((At - \[Mu]/tb)^2*(-13 + 19.6878144/(1 + tb^2) + 
           27*Log[Sqrt[mq2[3, 3]*mu2[3, 3]]/Q^2] - 
           (24*Log[Sqrt[mq2[3, 3]*mu2[3, 3]]/Q^2])/(1 + tb^2) - 
           (3*\[Mu]^2)/Sqrt[mq2[3, 3]*mu2[3, 3]] + 
           (6*\[Mu]^2*Log[Sqrt[mq2[3, 3]*mu2[3, 3]]/Q^2])/
            Sqrt[mq2[3, 3]*mu2[3, 3]] - (3*(At*tb - \[Mu] + 2*tb*\[Mu]*
                Csc[2*ArcTan[tb]])^2*(0.007049244444444251 + 
              Log[Sqrt[mq2[3, 3]*mu2[3, 3]]/Q^2]))/(tb^2*(1 + tb^2)*
             Sqrt[mq2[3, 3]*mu2[3, 3]])))/Sqrt[mq2[3, 3]*mu2[3, 3]]) + 
      (gt^6*(1 + tb^2)*((-50.09958959346384*gt^2*Log[MS/Q])/(1 + tb^2) - 
         (2*(mu2[3, 3]*((-32*g3^2*M3^2*Log[MS/Q])/3 + (2*gt^2*mA^2*Log[MS/Q])/
               tb^2 + (2*At^2*gt^2*(1 + tb^2)*Log[MS/Q])/tb^2 - 
              (2*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/tb^2 + (2*gt^2*(1 + tb^2)*
                Log[MS/Q]*mq2[3, 3])/tb^2 + (2*gt^2*(1 + tb^2)*Log[MS/Q]*
                mu2[3, 3])/tb^2) + mq2[3, 3]*((-32*g3^2*M3^2*Log[MS/Q])/3 + 
              (4*gt^2*mA^2*Log[MS/Q])/tb^2 + (4*At^2*gt^2*(1 + tb^2)*
                Log[MS/Q])/tb^2 - (4*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/tb^
                2 + (4*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3])/tb^2 + 
              (4*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^2)))/
          (mq2[3, 3]*mu2[3, 3]) + (3*Log[Sqrt[mq2[3, 3]*mu2[3, 3]]/Q^2]*
           (mu2[3, 3]*((-32*g3^2*M3^2*Log[MS/Q])/3 + (2*gt^2*mA^2*Log[MS/Q])/
               tb^2 + (2*At^2*gt^2*(1 + tb^2)*Log[MS/Q])/tb^2 - 
              (2*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/tb^2 + (2*gt^2*(1 + tb^2)*
                Log[MS/Q]*mq2[3, 3])/tb^2 + (2*gt^2*(1 + tb^2)*Log[MS/Q]*
                mu2[3, 3])/tb^2) + mq2[3, 3]*((-32*g3^2*M3^2*Log[MS/Q])/3 + 
              (4*gt^2*mA^2*Log[MS/Q])/tb^2 + (4*At^2*gt^2*(1 + tb^2)*
                Log[MS/Q])/tb^2 - (4*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/tb^
                2 + (4*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3])/tb^2 + 
              (4*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^2)))/
          (mq2[3, 3]*mu2[3, 3]) + 
         13*((6*gt^2*Log[MS/Q]*Log[Sqrt[mq2[3, 3]*mu2[3, 3]]/Q^2])/
            (1 + tb^2) + (mu2[3, 3]*((-32*g3^2*M3^2*Log[MS/Q])/3 + 
               (2*gt^2*mA^2*Log[MS/Q])/tb^2 + (2*At^2*gt^2*(1 + tb^2)*
                 Log[MS/Q])/tb^2 - (2*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/
                tb^2 + (2*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3])/tb^2 + 
               (2*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^2) + 
             mq2[3, 3]*((-32*g3^2*M3^2*Log[MS/Q])/3 + (4*gt^2*mA^2*Log[MS/Q])/
                tb^2 + (4*At^2*gt^2*(1 + tb^2)*Log[MS/Q])/tb^2 - 
               (4*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/tb^2 + (4*gt^2*
                 (1 + tb^2)*Log[MS/Q]*mq2[3, 3])/tb^2 + (4*gt^2*(1 + tb^2)*
                 Log[MS/Q]*mu2[3, 3])/tb^2))/(2*(1 + tb^2)*mq2[3, 3]*
             mu2[3, 3])) - 3*((6*gt^2*Log[MS/Q]*Log[Sqrt[mq2[3, 3]*mu2[3, 3]]/
                Q^2]^2)/(1 + tb^2) + (Log[Sqrt[mq2[3, 3]*mu2[3, 3]]/Q^2]*
             (mu2[3, 3]*((-32*g3^2*M3^2*Log[MS/Q])/3 + (2*gt^2*mA^2*
                  Log[MS/Q])/tb^2 + (2*At^2*gt^2*(1 + tb^2)*Log[MS/Q])/tb^2 - 
                (2*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/tb^2 + 
                (2*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3])/tb^2 + 
                (2*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^2) + 
              mq2[3, 3]*((-32*g3^2*M3^2*Log[MS/Q])/3 + (4*gt^2*mA^2*
                  Log[MS/Q])/tb^2 + (4*At^2*gt^2*(1 + tb^2)*Log[MS/Q])/tb^2 - 
                (4*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/tb^2 + 
                (4*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3])/tb^2 + 
                (4*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^2)))/
            ((1 + tb^2)*mq2[3, 3]*mu2[3, 3])) + 
         (19*((6*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/(tb^2*Sqrt[mq2[3, 3]*
                mu2[3, 3]]) - (\[Mu]^2*(mu2[3, 3]*((-32*g3^2*M3^2*Log[MS/Q])/
                  3 + (2*gt^2*mA^2*Log[MS/Q])/tb^2 + (2*At^2*gt^2*(1 + tb^2)*
                   Log[MS/Q])/tb^2 - (2*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/
                  tb^2 + (2*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3])/tb^2 + 
                 (2*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^2) + mq2[3, 3]*
                ((-32*g3^2*M3^2*Log[MS/Q])/3 + (4*gt^2*mA^2*Log[MS/Q])/tb^2 + 
                 (4*At^2*gt^2*(1 + tb^2)*Log[MS/Q])/tb^2 - (4*gt^2*(1 + tb^2)*
                   \[Mu]^2*Log[MS/Q])/tb^2 + (4*gt^2*(1 + tb^2)*Log[MS/Q]*
                   mq2[3, 3])/tb^2 + (4*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/
                  tb^2)))/(2*mq2[3, 3]*mu2[3, 3]*Sqrt[mq2[3, 3]*mu2[3, 3]])))/
          2 + (-13 + 19.6878144/(1 + tb^2) + 27*Log[Sqrt[mq2[3, 3]*mu2[3, 3]]/
              Q^2] - (24*Log[Sqrt[mq2[3, 3]*mu2[3, 3]]/Q^2])/(1 + tb^2) - 
           (3*\[Mu]^2)/Sqrt[mq2[3, 3]*mu2[3, 3]] + 
           (6*\[Mu]^2*Log[Sqrt[mq2[3, 3]*mu2[3, 3]]/Q^2])/
            Sqrt[mq2[3, 3]*mu2[3, 3]] - (3*(At*tb - \[Mu] + 2*tb*\[Mu]*
                Csc[2*ArcTan[tb]])^2*(0.007049244444444251 + 
              Log[Sqrt[mq2[3, 3]*mu2[3, 3]]/Q^2]))/(tb^2*(1 + tb^2)*
             Sqrt[mq2[3, 3]*mu2[3, 3]]))*
          ((2*(At - \[Mu]/tb)*((32*g3^2*M3*Log[MS/Q])/3 + (12*At*gt^2*
                (1 + tb^2)*Log[MS/Q])/tb^2 - (3*(10*gt^2*\[Mu]*Log[MS/Q] + 
                 10*gt^2*tb^2*\[Mu]*Log[MS/Q]))/(5*tb^3)))/
            Sqrt[mq2[3, 3]*mu2[3, 3]] - ((At - \[Mu]/tb)^2*
             (mu2[3, 3]*((-32*g3^2*M3^2*Log[MS/Q])/3 + (2*gt^2*mA^2*
                  Log[MS/Q])/tb^2 + (2*At^2*gt^2*(1 + tb^2)*Log[MS/Q])/tb^2 - 
                (2*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/tb^2 + 
                (2*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3])/tb^2 + 
                (2*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^2) + 
              mq2[3, 3]*((-32*g3^2*M3^2*Log[MS/Q])/3 + (4*gt^2*mA^2*
                  Log[MS/Q])/tb^2 + (4*At^2*gt^2*(1 + tb^2)*Log[MS/Q])/tb^2 - 
                (4*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/tb^2 + 
                (4*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3])/tb^2 + 
                (4*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^2)))/
            (2*mq2[3, 3]*mu2[3, 3]*Sqrt[mq2[3, 3]*mu2[3, 3]])) - 
         6*(-(\[Mu]^2*Log[Sqrt[mq2[3, 3]*mu2[3, 3]]/Q^2]*(mu2[3, 3]*
                ((-32*g3^2*M3^2*Log[MS/Q])/3 + (2*gt^2*mA^2*Log[MS/Q])/tb^2 + 
                 (2*At^2*gt^2*(1 + tb^2)*Log[MS/Q])/tb^2 - (2*gt^2*(1 + tb^2)*
                   \[Mu]^2*Log[MS/Q])/tb^2 + (2*gt^2*(1 + tb^2)*Log[MS/Q]*
                   mq2[3, 3])/tb^2 + (2*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/
                  tb^2) + mq2[3, 3]*((-32*g3^2*M3^2*Log[MS/Q])/3 + 
                 (4*gt^2*mA^2*Log[MS/Q])/tb^2 + (4*At^2*gt^2*(1 + tb^2)*
                   Log[MS/Q])/tb^2 - (4*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/
                  tb^2 + (4*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3])/tb^2 + 
                 (4*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^2)))/
            (2*mq2[3, 3]*mu2[3, 3]*Sqrt[mq2[3, 3]*mu2[3, 3]]) + 
           ((6*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q]*Log[Sqrt[mq2[3, 3]*
                   mu2[3, 3]]/Q^2])/tb^2 + (\[Mu]^2*(mu2[3, 3]*
                 ((-32*g3^2*M3^2*Log[MS/Q])/3 + (2*gt^2*mA^2*Log[MS/Q])/
                   tb^2 + (2*At^2*gt^2*(1 + tb^2)*Log[MS/Q])/tb^2 - 
                  (2*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/tb^2 + 
                  (2*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3])/tb^2 + 
                  (2*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^2) + 
                mq2[3, 3]*((-32*g3^2*M3^2*Log[MS/Q])/3 + (4*gt^2*mA^2*
                    Log[MS/Q])/tb^2 + (4*At^2*gt^2*(1 + tb^2)*Log[MS/Q])/
                   tb^2 - (4*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/tb^2 + 
                  (4*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3])/tb^2 + 
                  (4*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^2)))/
              (2*mq2[3, 3]*mu2[3, 3]))/Sqrt[mq2[3, 3]*mu2[3, 3]]) + 
         ((6*gt^2*(-(At*tb) + \[Mu])^6*Log[MS/Q]*
             (-1 + Log[Sqrt[mq2[3, 3]*mu2[3, 3]]/Q^2]))/(tb^4*(1 + tb^2)*
             (mq2[3, 3]*mu2[3, 3])^(3/2)) + 
           ((6*(-(At*tb) + \[Mu])^5*((3*At*gt^2*(1 + tb^2)*Log[MS/Q])/tb + 
                (3*gt^2*(1 + tb^2)*\[Mu]*Log[MS/Q])/tb^2 - 
                tb*((32*g3^2*M3*Log[MS/Q])/3 + (12*At*gt^2*(1 + tb^2)*
                    Log[MS/Q])/tb^2))*(-1 + Log[Sqrt[mq2[3, 3]*mu2[3, 3]]/
                  Q^2]))/(tb^4*(mq2[3, 3]*mu2[3, 3])^(3/2)) + 
             (-(At*tb) + \[Mu])^6*((-3*(-1 + Log[Sqrt[mq2[3, 3]*mu2[3, 3]]/
                    Q^2])*(mu2[3, 3]*((-32*g3^2*M3^2*Log[MS/Q])/3 + 
                    (2*gt^2*mA^2*Log[MS/Q])/tb^2 + (2*At^2*gt^2*(1 + tb^2)*
                      Log[MS/Q])/tb^2 - (2*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/
                     tb^2 + (2*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3])/tb^2 + 
                    (2*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^2) + 
                  mq2[3, 3]*((-32*g3^2*M3^2*Log[MS/Q])/3 + (4*gt^2*mA^2*
                      Log[MS/Q])/tb^2 + (4*At^2*gt^2*(1 + tb^2)*Log[MS/Q])/
                     tb^2 - (4*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/tb^2 + 
                    (4*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3])/tb^2 + 
                    (4*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^2)))/
                (2*tb^4*mq2[3, 3]*mu2[3, 3]*(mq2[3, 3]*mu2[3, 3])^(3/2)) + 
               ((12*gt^2*(1 + tb^2)*Log[MS/Q]*(-1 + Log[Sqrt[mq2[3, 3]*
                        mu2[3, 3]]/Q^2]))/tb^6 + (mu2[3, 3]*((-32*g3^2*M3^2*
                       Log[MS/Q])/3 + (2*gt^2*mA^2*Log[MS/Q])/tb^2 + 
                     (2*At^2*gt^2*(1 + tb^2)*Log[MS/Q])/tb^2 - 
                     (2*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/tb^2 + 
                     (2*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3])/tb^2 + 
                     (2*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^2) + 
                   mq2[3, 3]*((-32*g3^2*M3^2*Log[MS/Q])/3 + (4*gt^2*mA^2*
                       Log[MS/Q])/tb^2 + (4*At^2*gt^2*(1 + tb^2)*Log[MS/Q])/
                      tb^2 - (4*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/tb^2 + 
                     (4*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3])/tb^2 + 
                     (4*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^2))/
                  (2*tb^4*mq2[3, 3]*mu2[3, 3]))/(mq2[3, 3]*mu2[3, 3])^(3/2)))/
            (1 + tb^2))/2 + 3*((2*(At*tb - \[Mu] + 2*tb*\[Mu]*Csc[
                2*ArcTan[tb]])*((-3*At*gt^2*(1 + tb^2)*Log[MS/Q])/tb - 
              (3*gt^2*(1 + tb^2)*\[Mu]*Log[MS/Q])/tb^2 + 12*gt^2*\[Mu]*Cot[
                2*ArcTan[tb]]*Csc[2*ArcTan[tb]]*Log[MS/Q] + 
              tb*((32*g3^2*M3*Log[MS/Q])/3 + (12*At*gt^2*(1 + tb^2)*
                  Log[MS/Q])/tb^2))*(9782/234375 + Log[Sqrt[mq2[3, 3]*
                  mu2[3, 3]]/Q^2]))/(tb^2*(1 + tb^2)*Sqrt[mq2[3, 3]*mu2[3, 
                3]]) + (At*tb - \[Mu] + 2*tb*\[Mu]*Csc[2*ArcTan[tb]])^2*
            ((6*gt^2*Log[MS/Q]*(9782/234375 + Log[Sqrt[mq2[3, 3]*mu2[3, 3]]/
                  Q^2]))/(tb^2*(1 + tb^2)*Sqrt[mq2[3, 3]*mu2[3, 3]]) + 
             (-((9782/234375 + Log[Sqrt[mq2[3, 3]*mu2[3, 3]]/Q^2])*
                  (mu2[3, 3]*((-32*g3^2*M3^2*Log[MS/Q])/3 + (2*gt^2*mA^2*
                       Log[MS/Q])/tb^2 + (2*At^2*gt^2*(1 + tb^2)*Log[MS/Q])/
                      tb^2 - (2*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/tb^2 + 
                     (2*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3])/tb^2 + 
                     (2*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^2) + 
                   mq2[3, 3]*((-32*g3^2*M3^2*Log[MS/Q])/3 + (4*gt^2*mA^2*
                       Log[MS/Q])/tb^2 + (4*At^2*gt^2*(1 + tb^2)*Log[MS/Q])/
                      tb^2 - (4*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/tb^2 + 
                     (4*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3])/tb^2 + 
                     (4*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^2)))/
                (2*tb^2*mq2[3, 3]*mu2[3, 3]*Sqrt[mq2[3, 3]*mu2[3, 3]]) + 
               ((6*gt^2*(1 + tb^2)*Log[MS/Q]*(9782/234375 + Log[
                     Sqrt[mq2[3, 3]*mu2[3, 3]]/Q^2]))/tb^4 + 
                 (mu2[3, 3]*((-32*g3^2*M3^2*Log[MS/Q])/3 + (2*gt^2*mA^2*
                       Log[MS/Q])/tb^2 + (2*At^2*gt^2*(1 + tb^2)*Log[MS/Q])/
                      tb^2 - (2*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/tb^2 + 
                     (2*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3])/tb^2 + 
                     (2*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^2) + 
                   mq2[3, 3]*((-32*g3^2*M3^2*Log[MS/Q])/3 + (4*gt^2*mA^2*
                       Log[MS/Q])/tb^2 + (4*At^2*gt^2*(1 + tb^2)*Log[MS/Q])/
                      tb^2 - (4*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/tb^2 + 
                     (4*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3])/tb^2 + 
                     (4*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^2))/
                  (2*tb^2*mq2[3, 3]*mu2[3, 3]))/Sqrt[mq2[3, 3]*mu2[3, 3]])/
              (1 + tb^2))) + ((At - \[Mu]/tb)^2*((118.1268864*gt^2*Log[MS/Q])/
             (1 + tb^2) + (27*(mu2[3, 3]*((-32*g3^2*M3^2*Log[MS/Q])/3 + 
                 (2*gt^2*mA^2*Log[MS/Q])/tb^2 + (2*At^2*gt^2*(1 + tb^2)*
                   Log[MS/Q])/tb^2 - (2*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/
                  tb^2 + (2*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3])/tb^2 + 
                 (2*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^2) + mq2[3, 3]*
                ((-32*g3^2*M3^2*Log[MS/Q])/3 + (4*gt^2*mA^2*Log[MS/Q])/tb^2 + 
                 (4*At^2*gt^2*(1 + tb^2)*Log[MS/Q])/tb^2 - (4*gt^2*(1 + tb^2)*
                   \[Mu]^2*Log[MS/Q])/tb^2 + (4*gt^2*(1 + tb^2)*Log[MS/Q]*
                   mq2[3, 3])/tb^2 + (4*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/
                  tb^2)))/(2*mq2[3, 3]*mu2[3, 3]) - 
            24*((6*gt^2*Log[MS/Q]*Log[Sqrt[mq2[3, 3]*mu2[3, 3]]/Q^2])/(1 + 
                tb^2) + (mu2[3, 3]*((-32*g3^2*M3^2*Log[MS/Q])/3 + 
                  (2*gt^2*mA^2*Log[MS/Q])/tb^2 + (2*At^2*gt^2*(1 + tb^2)*
                    Log[MS/Q])/tb^2 - (2*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/
                   tb^2 + (2*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3])/tb^2 + 
                  (2*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^2) + 
                mq2[3, 3]*((-32*g3^2*M3^2*Log[MS/Q])/3 + (4*gt^2*mA^2*
                    Log[MS/Q])/tb^2 + (4*At^2*gt^2*(1 + tb^2)*Log[MS/Q])/
                   tb^2 - (4*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/tb^2 + 
                  (4*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3])/tb^2 + 
                  (4*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^2))/(2*
                (1 + tb^2)*mq2[3, 3]*mu2[3, 3])) - 
            3*((6*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/(tb^2*Sqrt[mq2[3, 3]*
                  mu2[3, 3]]) - (\[Mu]^2*(mu2[3, 3]*((-32*g3^2*M3^2*
                     Log[MS/Q])/3 + (2*gt^2*mA^2*Log[MS/Q])/tb^2 + 
                   (2*At^2*gt^2*(1 + tb^2)*Log[MS/Q])/tb^2 - 
                   (2*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/tb^2 + 
                   (2*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3])/tb^2 + 
                   (2*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^2) + 
                 mq2[3, 3]*((-32*g3^2*M3^2*Log[MS/Q])/3 + (4*gt^2*mA^2*
                     Log[MS/Q])/tb^2 + (4*At^2*gt^2*(1 + tb^2)*Log[MS/Q])/
                    tb^2 - (4*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/tb^2 + 
                   (4*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3])/tb^2 + 
                   (4*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^2)))/(2*
                mq2[3, 3]*mu2[3, 3]*Sqrt[mq2[3, 3]*mu2[3, 3]])) + 
            6*(-(\[Mu]^2*Log[Sqrt[mq2[3, 3]*mu2[3, 3]]/Q^2]*
                 (mu2[3, 3]*((-32*g3^2*M3^2*Log[MS/Q])/3 + (2*gt^2*mA^2*
                      Log[MS/Q])/tb^2 + (2*At^2*gt^2*(1 + tb^2)*Log[MS/Q])/
                     tb^2 - (2*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/tb^2 + 
                    (2*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3])/tb^2 + 
                    (2*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^2) + 
                  mq2[3, 3]*((-32*g3^2*M3^2*Log[MS/Q])/3 + (4*gt^2*mA^2*
                      Log[MS/Q])/tb^2 + (4*At^2*gt^2*(1 + tb^2)*Log[MS/Q])/
                     tb^2 - (4*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/tb^2 + 
                    (4*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3])/tb^2 + 
                    (4*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^2)))/(2*
                mq2[3, 3]*mu2[3, 3]*Sqrt[mq2[3, 3]*mu2[3, 3]]) + 
              ((6*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q]*Log[Sqrt[mq2[3, 3]*
                      mu2[3, 3]]/Q^2])/tb^2 + (\[Mu]^2*(mu2[3, 3]*
                    ((-32*g3^2*M3^2*Log[MS/Q])/3 + (2*gt^2*mA^2*Log[MS/Q])/
                      tb^2 + (2*At^2*gt^2*(1 + tb^2)*Log[MS/Q])/tb^2 - 
                     (2*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/tb^2 + 
                     (2*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3])/tb^2 + 
                     (2*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^2) + 
                   mq2[3, 3]*((-32*g3^2*M3^2*Log[MS/Q])/3 + (4*gt^2*mA^2*
                       Log[MS/Q])/tb^2 + (4*At^2*gt^2*(1 + tb^2)*Log[MS/Q])/
                      tb^2 - (4*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/tb^2 + 
                     (4*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3])/tb^2 + 
                     (4*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^2)))/
                 (2*mq2[3, 3]*mu2[3, 3]))/Sqrt[mq2[3, 3]*mu2[3, 3]]) - 
            3*((2*(At*tb - \[Mu] + 2*tb*\[Mu]*Csc[2*ArcTan[tb]])*
                ((-3*At*gt^2*(1 + tb^2)*Log[MS/Q])/tb - (3*gt^2*(1 + tb^2)*
                   \[Mu]*Log[MS/Q])/tb^2 + 12*gt^2*\[Mu]*Cot[2*ArcTan[tb]]*
                  Csc[2*ArcTan[tb]]*Log[MS/Q] + tb*((32*g3^2*M3*Log[MS/Q])/
                    3 + (12*At*gt^2*(1 + tb^2)*Log[MS/Q])/tb^2))*
                (0.007049244444444251 + Log[Sqrt[mq2[3, 3]*mu2[3, 3]]/Q^2]))/(
                tb^2*(1 + tb^2)*Sqrt[mq2[3, 3]*mu2[3, 3]]) + 
              (At*tb - \[Mu] + 2*tb*\[Mu]*Csc[2*ArcTan[tb]])^2*(
                (6*gt^2*Log[MS/Q]*(0.007049244444444251 + Log[
                    Sqrt[mq2[3, 3]*mu2[3, 3]]/Q^2]))/(tb^2*(1 + tb^2)*
                  Sqrt[mq2[3, 3]*mu2[3, 3]]) + (-((0.007049244444444251 + 
                      Log[Sqrt[mq2[3, 3]*mu2[3, 3]]/Q^2])*(mu2[3, 3]*
                       ((-32*g3^2*M3^2*Log[MS/Q])/3 + (2*gt^2*mA^2*Log[MS/Q])/
                         tb^2 + (2*At^2*gt^2*(1 + tb^2)*Log[MS/Q])/tb^2 - 
                        (2*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/tb^2 + 
                        (2*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3])/tb^2 + 
                        (2*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^2) + 
                      mq2[3, 3]*((-32*g3^2*M3^2*Log[MS/Q])/3 + (4*gt^2*mA^2*
                          Log[MS/Q])/tb^2 + (4*At^2*gt^2*(1 + tb^2)*
                          Log[MS/Q])/tb^2 - (4*gt^2*(1 + tb^2)*\[Mu]^2*
                          Log[MS/Q])/tb^2 + (4*gt^2*(1 + tb^2)*Log[MS/Q]*
                          mq2[3, 3])/tb^2 + (4*gt^2*(1 + tb^2)*Log[MS/Q]*
                          mu2[3, 3])/tb^2)))/(2*tb^2*mq2[3, 3]*mu2[3, 3]*
                    Sqrt[mq2[3, 3]*mu2[3, 3]]) + ((6*gt^2*(1 + tb^2)*
                      Log[MS/Q]*(0.007049244444444251 + Log[Sqrt[mq2[3, 3]*
                          mu2[3, 3]]/Q^2]))/tb^4 + (mu2[3, 3]*((-32*g3^2*M3^2*
                          Log[MS/Q])/3 + (2*gt^2*mA^2*Log[MS/Q])/tb^2 + 
                        (2*At^2*gt^2*(1 + tb^2)*Log[MS/Q])/tb^2 - 
                        (2*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/tb^2 + 
                        (2*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3])/tb^2 + 
                        (2*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^2) + 
                      mq2[3, 3]*((-32*g3^2*M3^2*Log[MS/Q])/3 + (4*gt^2*mA^2*
                          Log[MS/Q])/tb^2 + (4*At^2*gt^2*(1 + tb^2)*
                          Log[MS/Q])/tb^2 - (4*gt^2*(1 + tb^2)*\[Mu]^2*
                          Log[MS/Q])/tb^2 + (4*gt^2*(1 + tb^2)*Log[MS/Q]*
                          mq2[3, 3])/tb^2 + (4*gt^2*(1 + tb^2)*Log[MS/Q]*
                          mu2[3, 3])/tb^2))/(2*tb^2*mq2[3, 3]*mu2[3, 3]))/
                   Sqrt[mq2[3, 3]*mu2[3, 3]])/(1 + tb^2)))))/
          Sqrt[mq2[3, 3]*mu2[3, 3]] + 
         12*(((At*tb - \[Mu])*((-3*At*gt^2*(1 + tb^2)*Log[MS/Q])/tb - 
              (3*gt^2*(1 + tb^2)*\[Mu]*Log[MS/Q])/tb^2 + 12*gt^2*\[Mu]*Cot[
                2*ArcTan[tb]]*Csc[2*ArcTan[tb]]*Log[MS/Q] + 
              tb*((32*g3^2*M3*Log[MS/Q])/3 + (12*At*gt^2*(1 + tb^2)*
                  Log[MS/Q])/tb^2))*(9782/234375 + Log[Sqrt[mq2[3, 3]*
                  mu2[3, 3]]/Q^2]))/(tb^2*(1 + tb^2)*Sqrt[mq2[3, 3]*mu2[3, 
                3]]) + (At*tb - \[Mu] + 2*tb*\[Mu]*Csc[2*ArcTan[tb]])*
            ((6*gt^2*(At*tb - \[Mu])*Log[MS/Q]*(9782/234375 + 
                Log[Sqrt[mq2[3, 3]*mu2[3, 3]]/Q^2]))/(tb^2*(1 + tb^2)*Sqrt[
                mq2[3, 3]*mu2[3, 3]]) + ((((-3*At*gt^2*(1 + tb^2)*Log[MS/Q])/
                   tb - (3*gt^2*(1 + tb^2)*\[Mu]*Log[MS/Q])/tb^2 + 
                  tb*((32*g3^2*M3*Log[MS/Q])/3 + (12*At*gt^2*(1 + tb^2)*
                      Log[MS/Q])/tb^2))*(9782/234375 + Log[Sqrt[mq2[3, 3]*
                      mu2[3, 3]]/Q^2]))/(tb^2*Sqrt[mq2[3, 3]*mu2[3, 3]]) + 
               (At*tb - \[Mu])*(-((9782/234375 + Log[Sqrt[mq2[3, 3]*mu2[3, 
                          3]]/Q^2])*(mu2[3, 3]*((-32*g3^2*M3^2*Log[MS/Q])/3 + 
                       (2*gt^2*mA^2*Log[MS/Q])/tb^2 + (2*At^2*gt^2*(1 + tb^2)*
                         Log[MS/Q])/tb^2 - (2*gt^2*(1 + tb^2)*\[Mu]^2*
                         Log[MS/Q])/tb^2 + (2*gt^2*(1 + tb^2)*Log[MS/Q]*
                         mq2[3, 3])/tb^2 + (2*gt^2*(1 + tb^2)*Log[MS/Q]*
                         mu2[3, 3])/tb^2) + mq2[3, 3]*((-32*g3^2*M3^2*
                         Log[MS/Q])/3 + (4*gt^2*mA^2*Log[MS/Q])/tb^2 + 
                       (4*At^2*gt^2*(1 + tb^2)*Log[MS/Q])/tb^2 - 
                       (4*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/tb^2 + 
                       (4*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3])/tb^2 + 
                       (4*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^2)))/
                  (2*tb^2*mq2[3, 3]*mu2[3, 3]*Sqrt[mq2[3, 3]*mu2[3, 3]]) + 
                 ((6*gt^2*(1 + tb^2)*Log[MS/Q]*(9782/234375 + Log[
                       Sqrt[mq2[3, 3]*mu2[3, 3]]/Q^2]))/tb^4 + 
                   (mu2[3, 3]*((-32*g3^2*M3^2*Log[MS/Q])/3 + (2*gt^2*mA^2*
                         Log[MS/Q])/tb^2 + (2*At^2*gt^2*(1 + tb^2)*Log[MS/Q])/
                        tb^2 - (2*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/tb^2 + 
                       (2*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3])/tb^2 + 
                       (2*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^2) + 
                     mq2[3, 3]*((-32*g3^2*M3^2*Log[MS/Q])/3 + (4*gt^2*mA^2*
                         Log[MS/Q])/tb^2 + (4*At^2*gt^2*(1 + tb^2)*Log[MS/Q])/
                        tb^2 - (4*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/tb^2 + 
                       (4*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3])/tb^2 + 
                       (4*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^2))/
                    (2*tb^2*mq2[3, 3]*mu2[3, 3]))/Sqrt[mq2[3, 3]*mu2[3, 3]]))/
              (1 + tb^2))) - 2*(((At*tb - \[Mu])^3*((-3*At*gt^2*(1 + tb^2)*
                Log[MS/Q])/tb - (3*gt^2*(1 + tb^2)*\[Mu]*Log[MS/Q])/tb^2 + 
              12*gt^2*\[Mu]*Cot[2*ArcTan[tb]]*Csc[2*ArcTan[tb]]*Log[MS/Q] + 
              tb*((32*g3^2*M3*Log[MS/Q])/3 + (12*At*gt^2*(1 + tb^2)*
                  Log[MS/Q])/tb^2))*(-68343/156250 + 
              Log[Sqrt[mq2[3, 3]*mu2[3, 3]]/Q^2]))/(tb^4*(1 + tb^2)*mq2[3, 3]*
             mu2[3, 3]) + (At*tb - \[Mu] + 2*tb*\[Mu]*Csc[2*ArcTan[tb]])*
            ((6*gt^2*(At*tb - \[Mu])^3*Log[MS/Q]*(-68343/156250 + 
                Log[Sqrt[mq2[3, 3]*mu2[3, 3]]/Q^2]))/(tb^4*(1 + tb^2)*mq2[3, 
                3]*mu2[3, 3]) + ((3*(At*tb - \[Mu])^2*((-3*At*gt^2*(1 + tb^2)*
                    Log[MS/Q])/tb - (3*gt^2*(1 + tb^2)*\[Mu]*Log[MS/Q])/
                   tb^2 + tb*((32*g3^2*M3*Log[MS/Q])/3 + (12*At*gt^2*
                      (1 + tb^2)*Log[MS/Q])/tb^2))*(-68343/156250 + 
                  Log[Sqrt[mq2[3, 3]*mu2[3, 3]]/Q^2]))/(tb^4*mq2[3, 3]*
                 mu2[3, 3]) + (At*tb - \[Mu])^3*(((-68343/156250 + 
                    Log[Sqrt[mq2[3, 3]*mu2[3, 3]]/Q^2])*(-4*gt^2*Log[MS/Q] - 
                    (4*gt^2*Log[MS/Q])/tb^2 - (4*At^2*gt^2*Log[MS/Q])/
                     mu2[3, 3] + (32*g3^2*M3^2*Log[MS/Q])/(3*mu2[3, 3]) - 
                    (4*At^2*gt^2*Log[MS/Q])/(tb^2*mu2[3, 3]) - (4*gt^2*mA^2*
                      Log[MS/Q])/(tb^2*mu2[3, 3]) + (4*gt^2*\[Mu]^2*
                      Log[MS/Q])/mu2[3, 3] + (4*gt^2*\[Mu]^2*Log[MS/Q])/
                     (tb^2*mu2[3, 3]) - (4*gt^2*Log[MS/Q]*mq2[3, 3])/
                     mu2[3, 3] - (4*gt^2*Log[MS/Q]*mq2[3, 3])/(tb^2*
                      mu2[3, 3])))/(tb^4*mq2[3, 3]*mu2[3, 3]) + 
                 (((-68343/156250 + Log[Sqrt[mq2[3, 3]*mu2[3, 3]]/Q^2])*
                     (-2*gt^2*Log[MS/Q] - (2*gt^2*Log[MS/Q])/tb^2 - 
                      (2*At^2*gt^2*Log[MS/Q])/mq2[3, 3] + (32*g3^2*M3^2*
                        Log[MS/Q])/(3*mq2[3, 3]) - (2*At^2*gt^2*Log[MS/Q])/
                       (tb^2*mq2[3, 3]) - (2*gt^2*mA^2*Log[MS/Q])/(tb^2*
                        mq2[3, 3]) + (2*gt^2*\[Mu]^2*Log[MS/Q])/mq2[3, 3] + 
                      (2*gt^2*\[Mu]^2*Log[MS/Q])/(tb^2*mq2[3, 3]) - 
                      (2*gt^2*Log[MS/Q]*mu2[3, 3])/mq2[3, 3] - 
                      (2*gt^2*Log[MS/Q]*mu2[3, 3])/(tb^2*mq2[3, 3])))/
                    (tb^4*mq2[3, 3]) + ((12*gt^2*(1 + tb^2)*Log[MS/Q]*
                       (-68343/156250 + Log[Sqrt[mq2[3, 3]*mu2[3, 3]]/Q^2]))/
                      tb^6 + (mu2[3, 3]*((-32*g3^2*M3^2*Log[MS/Q])/3 + 
                         (2*gt^2*mA^2*Log[MS/Q])/tb^2 + (2*At^2*gt^2*(1 + 
                          tb^2)*Log[MS/Q])/tb^2 - (2*gt^2*(1 + tb^2)*\[Mu]^2*
                          Log[MS/Q])/tb^2 + (2*gt^2*(1 + tb^2)*Log[MS/Q]*
                          mq2[3, 3])/tb^2 + (2*gt^2*(1 + tb^2)*Log[MS/Q]*
                          mu2[3, 3])/tb^2) + mq2[3, 3]*((-32*g3^2*M3^2*
                          Log[MS/Q])/3 + (4*gt^2*mA^2*Log[MS/Q])/tb^2 + 
                         (4*At^2*gt^2*(1 + tb^2)*Log[MS/Q])/tb^2 - 
                         (4*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/tb^2 + 
                         (4*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3])/tb^2 + 
                         (4*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^2))/
                      (2*tb^4*mq2[3, 3]*mu2[3, 3]))/mq2[3, 3])/mu2[3, 3]))/
              (1 + tb^2))) + ((25 - 25/(1 + tb^2) - 
             26*Log[Sqrt[mq2[3, 3]*mu2[3, 3]]/Q^2] + 
             (24*Log[Sqrt[mq2[3, 3]*mu2[3, 3]]/Q^2])/(1 + tb^2) + 
             \[Mu]^2/Sqrt[mq2[3, 3]*mu2[3, 3]] + 
             (2*(At*tb - \[Mu] + 2*tb*\[Mu]*Csc[2*ArcTan[tb]])^2*(
                -19433/468750 + Log[Sqrt[mq2[3, 3]*mu2[3, 3]]/Q^2]))/
              (tb^2*(1 + tb^2)*Sqrt[mq2[3, 3]*mu2[3, 3]]) - 
             (4*\[Mu]^2*Log[Sqrt[mq2[3, 3]*mu2[3, 3]]/Q^2])/Sqrt[mq2[3, 3]*
                mu2[3, 3]])*((4*(At - \[Mu]/tb)^3*((32*g3^2*M3*Log[MS/Q])/3 + 
                (12*At*gt^2*(1 + tb^2)*Log[MS/Q])/tb^2 - 
                (3*(10*gt^2*\[Mu]*Log[MS/Q] + 10*gt^2*tb^2*\[Mu]*Log[MS/Q]))/
                 (5*tb^3)))/(mq2[3, 3]*mu2[3, 3]) + (At - \[Mu]/tb)^4*
              ((-4*gt^2*Log[MS/Q] - (4*gt^2*Log[MS/Q])/tb^2 - 
                 (4*At^2*gt^2*Log[MS/Q])/mu2[3, 3] + (32*g3^2*M3^2*Log[MS/Q])/
                  (3*mu2[3, 3]) - (4*At^2*gt^2*Log[MS/Q])/(tb^2*mu2[3, 3]) - 
                 (4*gt^2*mA^2*Log[MS/Q])/(tb^2*mu2[3, 3]) + (4*gt^2*\[Mu]^2*
                   Log[MS/Q])/mu2[3, 3] + (4*gt^2*\[Mu]^2*Log[MS/Q])/
                  (tb^2*mu2[3, 3]) - (4*gt^2*Log[MS/Q]*mq2[3, 3])/mu2[3, 3] - 
                 (4*gt^2*Log[MS/Q]*mq2[3, 3])/(tb^2*mu2[3, 3]))/(mq2[3, 3]*
                 mu2[3, 3]) + (-2*gt^2*Log[MS/Q] - (2*gt^2*Log[MS/Q])/tb^2 - 
                 (2*At^2*gt^2*Log[MS/Q])/mq2[3, 3] + (32*g3^2*M3^2*Log[MS/Q])/
                  (3*mq2[3, 3]) - (2*At^2*gt^2*Log[MS/Q])/(tb^2*mq2[3, 3]) - 
                 (2*gt^2*mA^2*Log[MS/Q])/(tb^2*mq2[3, 3]) + (2*gt^2*\[Mu]^2*
                   Log[MS/Q])/mq2[3, 3] + (2*gt^2*\[Mu]^2*Log[MS/Q])/
                  (tb^2*mq2[3, 3]) - (2*gt^2*Log[MS/Q]*mu2[3, 3])/mq2[3, 3] - 
                 (2*gt^2*Log[MS/Q]*mu2[3, 3])/(tb^2*mq2[3, 3]))/(mq2[3, 3]*
                 mu2[3, 3]))) + ((At - \[Mu]/tb)^4*((-150*gt^2*Log[MS/Q])/(
                1 + tb^2) + (6*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/(tb^2*
                Sqrt[mq2[3, 3]*mu2[3, 3]]) - (13*(mu2[3, 3]*
                  ((-32*g3^2*M3^2*Log[MS/Q])/3 + (2*gt^2*mA^2*Log[MS/Q])/
                    tb^2 + (2*At^2*gt^2*(1 + tb^2)*Log[MS/Q])/tb^2 - 
                   (2*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/tb^2 + 
                   (2*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3])/tb^2 + 
                   (2*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^2) + 
                 mq2[3, 3]*((-32*g3^2*M3^2*Log[MS/Q])/3 + (4*gt^2*mA^2*
                     Log[MS/Q])/tb^2 + (4*At^2*gt^2*(1 + tb^2)*Log[MS/Q])/
                    tb^2 - (4*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/tb^2 + 
                   (4*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3])/tb^2 + 
                   (4*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^2)))/(mq2[3, 3]*
                mu2[3, 3]) - (\[Mu]^2*(mu2[3, 3]*((-32*g3^2*M3^2*Log[MS/Q])/
                    3 + (2*gt^2*mA^2*Log[MS/Q])/tb^2 + (2*At^2*gt^2*
                     (1 + tb^2)*Log[MS/Q])/tb^2 - (2*gt^2*(1 + tb^2)*\[Mu]^2*
                     Log[MS/Q])/tb^2 + (2*gt^2*(1 + tb^2)*Log[MS/Q]*
                     mq2[3, 3])/tb^2 + (2*gt^2*(1 + tb^2)*Log[MS/Q]*
                     mu2[3, 3])/tb^2) + mq2[3, 3]*((-32*g3^2*M3^2*Log[MS/Q])/
                    3 + (4*gt^2*mA^2*Log[MS/Q])/tb^2 + (4*At^2*gt^2*
                     (1 + tb^2)*Log[MS/Q])/tb^2 - (4*gt^2*(1 + tb^2)*\[Mu]^2*
                     Log[MS/Q])/tb^2 + (4*gt^2*(1 + tb^2)*Log[MS/Q]*
                     mq2[3, 3])/tb^2 + (4*gt^2*(1 + tb^2)*Log[MS/Q]*
                     mu2[3, 3])/tb^2)))/(2*mq2[3, 3]*mu2[3, 3]*
                Sqrt[mq2[3, 3]*mu2[3, 3]]) + 24*((6*gt^2*Log[MS/Q]*
                  Log[Sqrt[mq2[3, 3]*mu2[3, 3]]/Q^2])/(1 + tb^2) + 
                (mu2[3, 3]*((-32*g3^2*M3^2*Log[MS/Q])/3 + (2*gt^2*mA^2*
                      Log[MS/Q])/tb^2 + (2*At^2*gt^2*(1 + tb^2)*Log[MS/Q])/
                     tb^2 - (2*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/tb^2 + 
                    (2*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3])/tb^2 + 
                    (2*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^2) + 
                  mq2[3, 3]*((-32*g3^2*M3^2*Log[MS/Q])/3 + (4*gt^2*mA^2*
                      Log[MS/Q])/tb^2 + (4*At^2*gt^2*(1 + tb^2)*Log[MS/Q])/
                     tb^2 - (4*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/tb^2 + 
                    (4*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3])/tb^2 + 
                    (4*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^2))/
                 (2*(1 + tb^2)*mq2[3, 3]*mu2[3, 3])) - 
              4*(-(\[Mu]^2*Log[Sqrt[mq2[3, 3]*mu2[3, 3]]/Q^2]*
                   (mu2[3, 3]*((-32*g3^2*M3^2*Log[MS/Q])/3 + (2*gt^2*mA^2*
                        Log[MS/Q])/tb^2 + (2*At^2*gt^2*(1 + tb^2)*Log[MS/Q])/
                       tb^2 - (2*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/tb^2 + 
                      (2*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3])/tb^2 + 
                      (2*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^2) + 
                    mq2[3, 3]*((-32*g3^2*M3^2*Log[MS/Q])/3 + (4*gt^2*mA^2*
                        Log[MS/Q])/tb^2 + (4*At^2*gt^2*(1 + tb^2)*Log[MS/Q])/
                       tb^2 - (4*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/tb^2 + 
                      (4*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3])/tb^2 + 
                      (4*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^2)))/
                 (2*mq2[3, 3]*mu2[3, 3]*Sqrt[mq2[3, 3]*mu2[3, 3]]) + 
                ((6*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q]*Log[Sqrt[mq2[3, 3]*
                        mu2[3, 3]]/Q^2])/tb^2 + (\[Mu]^2*(mu2[3, 3]*
                      ((-32*g3^2*M3^2*Log[MS/Q])/3 + (2*gt^2*mA^2*Log[MS/Q])/
                        tb^2 + (2*At^2*gt^2*(1 + tb^2)*Log[MS/Q])/tb^2 - 
                       (2*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/tb^2 + 
                       (2*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3])/tb^2 + 
                       (2*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^2) + 
                     mq2[3, 3]*((-32*g3^2*M3^2*Log[MS/Q])/3 + (4*gt^2*mA^2*
                         Log[MS/Q])/tb^2 + (4*At^2*gt^2*(1 + tb^2)*Log[MS/Q])/
                        tb^2 - (4*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/tb^2 + 
                       (4*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3])/tb^2 + 
                       (4*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^2)))/
                   (2*mq2[3, 3]*mu2[3, 3]))/Sqrt[mq2[3, 3]*mu2[3, 3]]) + 
              2*((2*(At*tb - \[Mu] + 2*tb*\[Mu]*Csc[2*ArcTan[tb]])*
                  ((-3*At*gt^2*(1 + tb^2)*Log[MS/Q])/tb - (3*gt^2*(1 + tb^2)*
                     \[Mu]*Log[MS/Q])/tb^2 + 12*gt^2*\[Mu]*Cot[2*ArcTan[tb]]*
                    Csc[2*ArcTan[tb]]*Log[MS/Q] + tb*((32*g3^2*M3*Log[MS/Q])/
                      3 + (12*At*gt^2*(1 + tb^2)*Log[MS/Q])/tb^2))*
                  (-19433/468750 + Log[Sqrt[mq2[3, 3]*mu2[3, 3]]/Q^2]))/
                 (tb^2*(1 + tb^2)*Sqrt[mq2[3, 3]*mu2[3, 3]]) + 
                (At*tb - \[Mu] + 2*tb*\[Mu]*Csc[2*ArcTan[tb]])^2*
                 ((6*gt^2*Log[MS/Q]*(-19433/468750 + Log[Sqrt[mq2[3, 3]*
                         mu2[3, 3]]/Q^2]))/(tb^2*(1 + tb^2)*Sqrt[mq2[3, 3]*
                      mu2[3, 3]]) + (-((-19433/468750 + Log[Sqrt[mq2[3, 3]*
                          mu2[3, 3]]/Q^2])*(mu2[3, 3]*((-32*g3^2*M3^2*
                          Log[MS/Q])/3 + (2*gt^2*mA^2*Log[MS/Q])/tb^2 + 
                          (2*At^2*gt^2*(1 + tb^2)*Log[MS/Q])/tb^2 - 
                          (2*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/tb^2 + 
                          (2*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3])/tb^2 + 
                          (2*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^2) + 
                        mq2[3, 3]*((-32*g3^2*M3^2*Log[MS/Q])/3 + (4*gt^2*mA^2*
                          Log[MS/Q])/tb^2 + (4*At^2*gt^2*(1 + tb^2)*Log[
                          MS/Q])/tb^2 - (4*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/
                          tb^2 + (4*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3])/
                          tb^2 + (4*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/
                          tb^2)))/(2*tb^2*mq2[3, 3]*mu2[3, 3]*Sqrt[mq2[3, 3]*
                        mu2[3, 3]]) + ((6*gt^2*(1 + tb^2)*Log[MS/Q]*
                        (-19433/468750 + Log[Sqrt[mq2[3, 3]*mu2[3, 3]]/Q^2]))/
                       tb^4 + (mu2[3, 3]*((-32*g3^2*M3^2*Log[MS/Q])/3 + 
                          (2*gt^2*mA^2*Log[MS/Q])/tb^2 + (2*At^2*gt^2*
                          (1 + tb^2)*Log[MS/Q])/tb^2 - (2*gt^2*(1 + tb^2)*
                          \[Mu]^2*Log[MS/Q])/tb^2 + (2*gt^2*(1 + tb^2)*
                          Log[MS/Q]*mq2[3, 3])/tb^2 + (2*gt^2*(1 + tb^2)*
                          Log[MS/Q]*mu2[3, 3])/tb^2) + mq2[3, 3]*
                         ((-32*g3^2*M3^2*Log[MS/Q])/3 + (4*gt^2*mA^2*
                          Log[MS/Q])/tb^2 + (4*At^2*gt^2*(1 + tb^2)*Log[
                          MS/Q])/tb^2 - (4*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/
                          tb^2 + (4*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3])/
                          tb^2 + (4*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/
                          tb^2))/(2*tb^2*mq2[3, 3]*mu2[3, 3]))/Sqrt[mq2[3, 3]*
                       mu2[3, 3]])/(1 + tb^2)))))/(mq2[3, 3]*mu2[3, 3]))/4))/
       tb^2))/(256*Pi^4)) - 
 3*(((gt^2*(-160*g3^2*gt*Log[MS/Q] + 90*gt^3*Log[MS/Q])^2)/100 + 
     2*gt^2*((-160*g3^2*gt*Log[MS/Q] + 90*gt^3*Log[MS/Q])^2/400 + 
       2*gt*(88*g3^4*gt*Log[MS/Q]^2 - 72*g3^2*gt^3*Log[MS/Q]^2 + 
         (243*gt^5*Log[MS/Q]^2)/8)))*Log[mq2[3, 3]/Q^2] + 
   (gt^3*(-160*g3^2*gt*Log[MS/Q] + 90*gt^3*Log[MS/Q])*
     ((-32*g3^2*M3^2*Log[MS/Q])/3 + (2*gt^2*mA^2*Log[MS/Q])/tb^2 + 
      (2*At^2*gt^2*(1 + tb^2)*Log[MS/Q])/tb^2 - 
      (2*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/tb^2 + 
      (2*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3])/tb^2 + 
      (2*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^2))/(5*mq2[3, 3]) + 
   (gt^4*((((-32*g3^2*M3^2*Log[MS/Q])/3 + (2*gt^2*mA^2*Log[MS/Q])/tb^2 + 
         (2*At^2*gt^2*(1 + tb^2)*Log[MS/Q])/tb^2 - 
         (2*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/tb^2 + 
         (2*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3])/tb^2 + 
         (2*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^2)*(-2*gt^2*Log[MS/Q] - 
         (2*gt^2*Log[MS/Q])/tb^2 - (2*At^2*gt^2*Log[MS/Q])/mq2[3, 3] + 
         (32*g3^2*M3^2*Log[MS/Q])/(3*mq2[3, 3]) - (2*At^2*gt^2*Log[MS/Q])/
          (tb^2*mq2[3, 3]) - (2*gt^2*mA^2*Log[MS/Q])/(tb^2*mq2[3, 3]) + 
         (2*gt^2*\[Mu]^2*Log[MS/Q])/mq2[3, 3] + (2*gt^2*\[Mu]^2*Log[MS/Q])/
          (tb^2*mq2[3, 3]) - (2*gt^2*Log[MS/Q]*mu2[3, 3])/mq2[3, 3] - 
         (2*gt^2*Log[MS/Q]*mu2[3, 3])/(tb^2*mq2[3, 3])))/mq2[3, 3] + 
      (2*(96*g3^4*M3^2*Log[MS/Q]^2 - (32*g3^2*gt^2*mA^2*Log[MS/Q]^2)/
          (3*tb^2) + (6*gt^4*mA^2*Log[MS/Q]^2)/tb^2 + 
         (18*gt^4*mA^2*(1 + tb^2)*Log[MS/Q]^2)/tb^4 - 
         (32*At^2*g3^2*gt^2*(1 + tb^2)*Log[MS/Q]^2)/(3*tb^2) + 
         (64*At*g3^2*gt^2*M3*(1 + tb^2)*Log[MS/Q]^2)/(3*tb^2) - 
         (64*g3^2*gt^2*M3^2*(1 + tb^2)*Log[MS/Q]^2)/(3*tb^2) + 
         (42*At^2*gt^4*(1 + tb^2)^2*Log[MS/Q]^2)/tb^4 + 
         (32*g3^2*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q]^2)/(3*tb^2) - 
         (24*gt^4*(1 + tb^2)^2*\[Mu]^2*Log[MS/Q]^2)/tb^4 + 
         (g3^4*M3^2*Log[MS/Q]*(-6 + 12*Log[M3^2/Q^2] + Log[md2[1, 1]/Q^2] + 
            Log[md2[2, 2]/Q^2] + Log[md2[3, 3]/Q^2] + 2*Log[mq2[1, 1]/Q^2] + 
            2*Log[mq2[2, 2]/Q^2] + 2*Log[mq2[3, 3]/Q^2] + 
            Log[mu2[1, 1]/Q^2] + Log[mu2[2, 2]/Q^2] + Log[mu2[3, 3]/Q^2]))/
          (9*Pi^2) - (32*g3^2*gt^2*(1 + tb^2)*Log[MS/Q]^2*mq2[3, 3])/
          (3*tb^2) + (18*gt^4*(1 + tb^2)^2*Log[MS/Q]^2*mq2[3, 3])/tb^4 - 
         (32*g3^2*gt^2*(1 + tb^2)*Log[MS/Q]^2*mu2[3, 3])/(3*tb^2) + 
         (18*gt^4*(1 + tb^2)^2*Log[MS/Q]^2*mu2[3, 3])/tb^4 + 
         (4*gt^2*mA^2*Log[MS/Q]*((-4*g3^2)/3 - 
            gt^2*((3*(-1 + 2*Log[mA^2/Q^2]))/(8*tb^2) + (3*(1 + tb^2)*
                Log[\[Mu]^2/Q^2])/(4*tb^2) - ((At - \[Mu]/tb)^2*
                TCF[5][Sqrt[mq2[3, 3]]/Sqrt[mu2[3, 3]]])/(4*
                Sqrt[mq2[3, 3]*mu2[3, 3]]) + ((1 + tb^2)*TCF[6][
                 Sqrt[mq2[3, 3]]/\[Mu]])/tb^2 + ((1 + tb^2)*TCF[6][
                 Sqrt[mu2[3, 3]]/\[Mu]])/(2*tb^2)) - 
            (4*g3^2*(Log[M3^2/Q^2] + TCF[6][Sqrt[mq2[3, 3]]/M3] + TCF[6][
                Sqrt[mu2[3, 3]]/M3] - ((At - \[Mu]/tb)*TCF[9][Sqrt[mq2[3, 3]]/
                   M3, Sqrt[mu2[3, 3]]/M3])/M3))/3))/tb^2 + 
         (4*At^2*gt^2*(1 + tb^2)*Log[MS/Q]*((-4*g3^2)/3 - 
            gt^2*((3*(-1 + 2*Log[mA^2/Q^2]))/(8*tb^2) + (3*(1 + tb^2)*
                Log[\[Mu]^2/Q^2])/(4*tb^2) - ((At - \[Mu]/tb)^2*
                TCF[5][Sqrt[mq2[3, 3]]/Sqrt[mu2[3, 3]]])/(4*
                Sqrt[mq2[3, 3]*mu2[3, 3]]) + ((1 + tb^2)*TCF[6][
                 Sqrt[mq2[3, 3]]/\[Mu]])/tb^2 + ((1 + tb^2)*TCF[6][
                 Sqrt[mu2[3, 3]]/\[Mu]])/(2*tb^2)) - 
            (4*g3^2*(Log[M3^2/Q^2] + TCF[6][Sqrt[mq2[3, 3]]/M3] + TCF[6][
                Sqrt[mu2[3, 3]]/M3] - ((At - \[Mu]/tb)*TCF[9][Sqrt[mq2[3, 3]]/
                   M3, Sqrt[mu2[3, 3]]/M3])/M3))/3))/tb^2 - 
         (4*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q]*((-4*g3^2)/3 - 
            gt^2*((3*(-1 + 2*Log[mA^2/Q^2]))/(8*tb^2) + (3*(1 + tb^2)*
                Log[\[Mu]^2/Q^2])/(4*tb^2) - ((At - \[Mu]/tb)^2*
                TCF[5][Sqrt[mq2[3, 3]]/Sqrt[mu2[3, 3]]])/(4*
                Sqrt[mq2[3, 3]*mu2[3, 3]]) + ((1 + tb^2)*TCF[6][
                 Sqrt[mq2[3, 3]]/\[Mu]])/tb^2 + ((1 + tb^2)*TCF[6][
                 Sqrt[mu2[3, 3]]/\[Mu]])/(2*tb^2)) - 
            (4*g3^2*(Log[M3^2/Q^2] + TCF[6][Sqrt[mq2[3, 3]]/M3] + TCF[6][
                Sqrt[mu2[3, 3]]/M3] - ((At - \[Mu]/tb)*TCF[9][Sqrt[mq2[3, 3]]/
                   M3, Sqrt[mu2[3, 3]]/M3])/M3))/3))/tb^2 + 
         (4*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3]*((-4*g3^2)/3 - 
            gt^2*((3*(-1 + 2*Log[mA^2/Q^2]))/(8*tb^2) + (3*(1 + tb^2)*
                Log[\[Mu]^2/Q^2])/(4*tb^2) - ((At - \[Mu]/tb)^2*
                TCF[5][Sqrt[mq2[3, 3]]/Sqrt[mu2[3, 3]]])/(4*
                Sqrt[mq2[3, 3]*mu2[3, 3]]) + ((1 + tb^2)*TCF[6][
                 Sqrt[mq2[3, 3]]/\[Mu]])/tb^2 + ((1 + tb^2)*TCF[6][
                 Sqrt[mu2[3, 3]]/\[Mu]])/(2*tb^2)) - 
            (4*g3^2*(Log[M3^2/Q^2] + TCF[6][Sqrt[mq2[3, 3]]/M3] + TCF[6][
                Sqrt[mu2[3, 3]]/M3] - ((At - \[Mu]/tb)*TCF[9][Sqrt[mq2[3, 3]]/
                   M3, Sqrt[mu2[3, 3]]/M3])/M3))/3))/tb^2 + 
         (4*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3]*((-4*g3^2)/3 - 
            gt^2*((3*(-1 + 2*Log[mA^2/Q^2]))/(8*tb^2) + (3*(1 + tb^2)*
                Log[\[Mu]^2/Q^2])/(4*tb^2) - ((At - \[Mu]/tb)^2*
                TCF[5][Sqrt[mq2[3, 3]]/Sqrt[mu2[3, 3]]])/(4*
                Sqrt[mq2[3, 3]*mu2[3, 3]]) + ((1 + tb^2)*TCF[6][
                 Sqrt[mq2[3, 3]]/\[Mu]])/tb^2 + ((1 + tb^2)*TCF[6][
                 Sqrt[mu2[3, 3]]/\[Mu]])/(2*tb^2)) - 
            (4*g3^2*(Log[M3^2/Q^2] + TCF[6][Sqrt[mq2[3, 3]]/M3] + TCF[6][
                Sqrt[mu2[3, 3]]/M3] - ((At - \[Mu]/tb)*TCF[9][Sqrt[mq2[3, 3]]/
                   M3, Sqrt[mu2[3, 3]]/M3])/M3))/3))/tb^2))/mq2[3, 3]))/2) - 
 3*(((gt^2*(-160*g3^2*gt*Log[MS/Q] + 90*gt^3*Log[MS/Q])^2)/100 + 
     2*gt^2*((-160*g3^2*gt*Log[MS/Q] + 90*gt^3*Log[MS/Q])^2/400 + 
       2*gt*(88*g3^4*gt*Log[MS/Q]^2 - 72*g3^2*gt^3*Log[MS/Q]^2 + 
         (243*gt^5*Log[MS/Q]^2)/8)))*Log[mu2[3, 3]/Q^2] + 
   (gt^3*(-160*g3^2*gt*Log[MS/Q] + 90*gt^3*Log[MS/Q])*
     ((-32*g3^2*M3^2*Log[MS/Q])/3 + (4*gt^2*mA^2*Log[MS/Q])/tb^2 + 
      (4*At^2*gt^2*(1 + tb^2)*Log[MS/Q])/tb^2 - 
      (4*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/tb^2 + 
      (4*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3])/tb^2 + 
      (4*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^2))/(5*mu2[3, 3]) + 
   (gt^4*(((-4*gt^2*Log[MS/Q] - (4*gt^2*Log[MS/Q])/tb^2 - 
         (4*At^2*gt^2*Log[MS/Q])/mu2[3, 3] + (32*g3^2*M3^2*Log[MS/Q])/
          (3*mu2[3, 3]) - (4*At^2*gt^2*Log[MS/Q])/(tb^2*mu2[3, 3]) - 
         (4*gt^2*mA^2*Log[MS/Q])/(tb^2*mu2[3, 3]) + 
         (4*gt^2*\[Mu]^2*Log[MS/Q])/mu2[3, 3] + (4*gt^2*\[Mu]^2*Log[MS/Q])/
          (tb^2*mu2[3, 3]) - (4*gt^2*Log[MS/Q]*mq2[3, 3])/mu2[3, 3] - 
         (4*gt^2*Log[MS/Q]*mq2[3, 3])/(tb^2*mu2[3, 3]))*
        ((-32*g3^2*M3^2*Log[MS/Q])/3 + (4*gt^2*mA^2*Log[MS/Q])/tb^2 + 
         (4*At^2*gt^2*(1 + tb^2)*Log[MS/Q])/tb^2 - 
         (4*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/tb^2 + 
         (4*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3])/tb^2 + 
         (4*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^2))/mu2[3, 3] + 
      (2*(96*g3^4*M3^2*Log[MS/Q]^2 - (64*g3^2*gt^2*mA^2*Log[MS/Q]^2)/
          (3*tb^2) + (12*gt^4*mA^2*Log[MS/Q]^2)/tb^2 + 
         (36*gt^4*mA^2*(1 + tb^2)*Log[MS/Q]^2)/tb^4 - 
         (64*At^2*g3^2*gt^2*(1 + tb^2)*Log[MS/Q]^2)/(3*tb^2) + 
         (128*At*g3^2*gt^2*M3*(1 + tb^2)*Log[MS/Q]^2)/(3*tb^2) - 
         (128*g3^2*gt^2*M3^2*(1 + tb^2)*Log[MS/Q]^2)/(3*tb^2) + 
         (84*At^2*gt^4*(1 + tb^2)^2*Log[MS/Q]^2)/tb^4 + 
         (64*g3^2*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q]^2)/(3*tb^2) - 
         (48*gt^4*(1 + tb^2)^2*\[Mu]^2*Log[MS/Q]^2)/tb^4 + 
         (g3^4*M3^2*Log[MS/Q]*(-6 + 12*Log[M3^2/Q^2] + Log[md2[1, 1]/Q^2] + 
            Log[md2[2, 2]/Q^2] + Log[md2[3, 3]/Q^2] + 2*Log[mq2[1, 1]/Q^2] + 
            2*Log[mq2[2, 2]/Q^2] + 2*Log[mq2[3, 3]/Q^2] + 
            Log[mu2[1, 1]/Q^2] + Log[mu2[2, 2]/Q^2] + Log[mu2[3, 3]/Q^2]))/
          (9*Pi^2) - (64*g3^2*gt^2*(1 + tb^2)*Log[MS/Q]^2*mq2[3, 3])/
          (3*tb^2) + (36*gt^4*(1 + tb^2)^2*Log[MS/Q]^2*mq2[3, 3])/tb^4 - 
         (64*g3^2*gt^2*(1 + tb^2)*Log[MS/Q]^2*mu2[3, 3])/(3*tb^2) + 
         (36*gt^4*(1 + tb^2)^2*Log[MS/Q]^2*mu2[3, 3])/tb^4 + 
         (8*gt^2*mA^2*Log[MS/Q]*((-4*g3^2)/3 - 
            gt^2*((3*(-1 + 2*Log[mA^2/Q^2]))/(8*tb^2) + (3*(1 + tb^2)*
                Log[\[Mu]^2/Q^2])/(4*tb^2) - ((At - \[Mu]/tb)^2*
                TCF[5][Sqrt[mq2[3, 3]]/Sqrt[mu2[3, 3]]])/(4*
                Sqrt[mq2[3, 3]*mu2[3, 3]]) + ((1 + tb^2)*TCF[6][
                 Sqrt[mq2[3, 3]]/\[Mu]])/tb^2 + ((1 + tb^2)*TCF[6][
                 Sqrt[mu2[3, 3]]/\[Mu]])/(2*tb^2)) - 
            (4*g3^2*(Log[M3^2/Q^2] + TCF[6][Sqrt[mq2[3, 3]]/M3] + TCF[6][
                Sqrt[mu2[3, 3]]/M3] - ((At - \[Mu]/tb)*TCF[9][Sqrt[mq2[3, 3]]/
                   M3, Sqrt[mu2[3, 3]]/M3])/M3))/3))/tb^2 + 
         (8*At^2*gt^2*(1 + tb^2)*Log[MS/Q]*((-4*g3^2)/3 - 
            gt^2*((3*(-1 + 2*Log[mA^2/Q^2]))/(8*tb^2) + (3*(1 + tb^2)*
                Log[\[Mu]^2/Q^2])/(4*tb^2) - ((At - \[Mu]/tb)^2*
                TCF[5][Sqrt[mq2[3, 3]]/Sqrt[mu2[3, 3]]])/(4*
                Sqrt[mq2[3, 3]*mu2[3, 3]]) + ((1 + tb^2)*TCF[6][
                 Sqrt[mq2[3, 3]]/\[Mu]])/tb^2 + ((1 + tb^2)*TCF[6][
                 Sqrt[mu2[3, 3]]/\[Mu]])/(2*tb^2)) - 
            (4*g3^2*(Log[M3^2/Q^2] + TCF[6][Sqrt[mq2[3, 3]]/M3] + TCF[6][
                Sqrt[mu2[3, 3]]/M3] - ((At - \[Mu]/tb)*TCF[9][Sqrt[mq2[3, 3]]/
                   M3, Sqrt[mu2[3, 3]]/M3])/M3))/3))/tb^2 - 
         (8*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q]*((-4*g3^2)/3 - 
            gt^2*((3*(-1 + 2*Log[mA^2/Q^2]))/(8*tb^2) + (3*(1 + tb^2)*
                Log[\[Mu]^2/Q^2])/(4*tb^2) - ((At - \[Mu]/tb)^2*
                TCF[5][Sqrt[mq2[3, 3]]/Sqrt[mu2[3, 3]]])/(4*
                Sqrt[mq2[3, 3]*mu2[3, 3]]) + ((1 + tb^2)*TCF[6][
                 Sqrt[mq2[3, 3]]/\[Mu]])/tb^2 + ((1 + tb^2)*TCF[6][
                 Sqrt[mu2[3, 3]]/\[Mu]])/(2*tb^2)) - 
            (4*g3^2*(Log[M3^2/Q^2] + TCF[6][Sqrt[mq2[3, 3]]/M3] + TCF[6][
                Sqrt[mu2[3, 3]]/M3] - ((At - \[Mu]/tb)*TCF[9][Sqrt[mq2[3, 3]]/
                   M3, Sqrt[mu2[3, 3]]/M3])/M3))/3))/tb^2 + 
         (8*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3]*((-4*g3^2)/3 - 
            gt^2*((3*(-1 + 2*Log[mA^2/Q^2]))/(8*tb^2) + (3*(1 + tb^2)*
                Log[\[Mu]^2/Q^2])/(4*tb^2) - ((At - \[Mu]/tb)^2*
                TCF[5][Sqrt[mq2[3, 3]]/Sqrt[mu2[3, 3]]])/(4*
                Sqrt[mq2[3, 3]*mu2[3, 3]]) + ((1 + tb^2)*TCF[6][
                 Sqrt[mq2[3, 3]]/\[Mu]])/tb^2 + ((1 + tb^2)*TCF[6][
                 Sqrt[mu2[3, 3]]/\[Mu]])/(2*tb^2)) - 
            (4*g3^2*(Log[M3^2/Q^2] + TCF[6][Sqrt[mq2[3, 3]]/M3] + TCF[6][
                Sqrt[mu2[3, 3]]/M3] - ((At - \[Mu]/tb)*TCF[9][Sqrt[mq2[3, 3]]/
                   M3, Sqrt[mu2[3, 3]]/M3])/M3))/3))/tb^2 + 
         (8*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3]*((-4*g3^2)/3 - 
            gt^2*((3*(-1 + 2*Log[mA^2/Q^2]))/(8*tb^2) + (3*(1 + tb^2)*
                Log[\[Mu]^2/Q^2])/(4*tb^2) - ((At - \[Mu]/tb)^2*
                TCF[5][Sqrt[mq2[3, 3]]/Sqrt[mu2[3, 3]]])/(4*
                Sqrt[mq2[3, 3]*mu2[3, 3]]) + ((1 + tb^2)*TCF[6][
                 Sqrt[mq2[3, 3]]/\[Mu]])/tb^2 + ((1 + tb^2)*TCF[6][
                 Sqrt[mu2[3, 3]]/\[Mu]])/(2*tb^2)) - 
            (4*g3^2*(Log[M3^2/Q^2] + TCF[6][Sqrt[mq2[3, 3]]/M3] + TCF[6][
                Sqrt[mu2[3, 3]]/M3] - ((At - \[Mu]/tb)*TCF[9][Sqrt[mq2[3, 3]]/
                   M3, Sqrt[mu2[3, 3]]/M3])/M3))/3))/tb^2))/mu2[3, 3]))/2) - 
 6*((TCF[1][Sqrt[mq2[3, 3]/mu2[3, 3]]] - 
     ((At - \[Mu]/tb)^2*TCF[2][Sqrt[mq2[3, 3]/mu2[3, 3]]])/
      (12*Sqrt[mq2[3, 3]*mu2[3, 3]]))*
    (2*(At - \[Mu]/tb)*((32*g3^2*M3*Log[MS/Q])/3 + 
       (12*At*gt^2*(1 + tb^2)*Log[MS/Q])/tb^2 - 
       (3*(10*gt^2*\[Mu]*Log[MS/Q] + 10*gt^2*tb^2*\[Mu]*Log[MS/Q]))/(5*tb^3))*
      ((gt^3*(-160*g3^2*gt*Log[MS/Q] + 90*gt^3*Log[MS/Q]))/
        (5*Sqrt[mq2[3, 3]*mu2[3, 3]]) - 
       (gt^4*(mu2[3, 3]*((-32*g3^2*M3^2*Log[MS/Q])/3 + 
            (2*gt^2*mA^2*Log[MS/Q])/tb^2 + (2*At^2*gt^2*(1 + tb^2)*Log[MS/Q])/
             tb^2 - (2*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/tb^2 + 
            (2*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3])/tb^2 + 
            (2*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^2) + 
          mq2[3, 3]*((-32*g3^2*M3^2*Log[MS/Q])/3 + (4*gt^2*mA^2*Log[MS/Q])/
             tb^2 + (4*At^2*gt^2*(1 + tb^2)*Log[MS/Q])/tb^2 - 
            (4*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/tb^2 + 
            (4*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3])/tb^2 + 
            (4*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^2)))/
        (2*mq2[3, 3]*mu2[3, 3]*Sqrt[mq2[3, 3]*mu2[3, 3]])) + 
     (gt^4*(((32*g3^2*M3*Log[MS/Q])/3 + (12*At*gt^2*(1 + tb^2)*Log[MS/Q])/
           tb^2 - (3*(10*gt^2*\[Mu]*Log[MS/Q] + 10*gt^2*tb^2*\[Mu]*
              Log[MS/Q]))/(5*tb^3))^2 + 2*(At - \[Mu]/tb)*
         (-64*g3^4*M3*Log[MS/Q]^2 - (64*At*g3^2*gt^2*(1 + tb^2)*Log[MS/Q]^2)/
           tb^2 + (64*g3^2*gt^2*M3*(1 + tb^2)*Log[MS/Q]^2)/tb^2 + 
          (144*At*gt^4*(1 + tb^2)^2*Log[MS/Q]^2)/tb^4 - 
          (3*gt^2*(1 + tb^2)*\[Mu]*Log[MS/Q]*(3*gt^2*Log[MS/Q] + 
             (3*gt^2*Log[MS/Q])/tb^2))/tb^3 - (g3^4*M3*Log[MS/Q]*
            (-6 + 12*Log[M3^2/Q^2] + Log[md2[1, 1]/Q^2] + 
             Log[md2[2, 2]/Q^2] + Log[md2[3, 3]/Q^2] + 2*Log[mq2[1, 1]/Q^2] + 
             2*Log[mq2[2, 2]/Q^2] + 2*Log[mq2[3, 3]/Q^2] + 
             Log[mu2[1, 1]/Q^2] + Log[mu2[2, 2]/Q^2] + Log[mu2[3, 3]/Q^2]))/
           (9*Pi^2) + (24*At*gt^2*(1 + tb^2)*Log[MS/Q]*((-4*g3^2)/3 - 
             gt^2*((3*(-1 + 2*Log[mA^2/Q^2]))/(8*tb^2) + (3*(1 + tb^2)*
                 Log[\[Mu]^2/Q^2])/(4*tb^2) - ((At - \[Mu]/tb)^2*
                 TCF[5][Sqrt[mq2[3, 3]]/Sqrt[mu2[3, 3]]])/
                (4*Sqrt[mq2[3, 3]*mu2[3, 3]]) + ((1 + tb^2)*TCF[6][
                  Sqrt[mq2[3, 3]]/\[Mu]])/tb^2 + ((1 + tb^2)*TCF[6][
                  Sqrt[mu2[3, 3]]/\[Mu]])/(2*tb^2)) - 
             (4*g3^2*(Log[M3^2/Q^2] + TCF[6][Sqrt[mq2[3, 3]]/M3] + 
                TCF[6][Sqrt[mu2[3, 3]]/M3] - ((At - \[Mu]/tb)*TCF[9][
                   Sqrt[mq2[3, 3]]/M3, Sqrt[mu2[3, 3]]/M3])/M3))/3))/tb^2 - 
          (-((1 + tb^2)*(-45*gt^4 + 32*g3^2*gt^2*tb^2 - 45*gt^4*tb^2)*\[Mu]*
               Log[MS/Q]^2)/(2*tb^4) + (6*gt^2*(1 + tb^2)*\[Mu]*Log[MS/Q]*
              ((-4*g3^2)/3 - gt^2*((3*(-1 + 2*Log[mA^2/Q^2]))/(8*tb^2) + 
                 (3*(1 + tb^2)*Log[\[Mu]^2/Q^2])/(4*tb^2) - 
                 ((At - \[Mu]/tb)^2*TCF[5][Sqrt[mq2[3, 3]]/Sqrt[mu2[3, 3]]])/
                  (4*Sqrt[mq2[3, 3]*mu2[3, 3]]) + ((1 + tb^2)*TCF[6][
                    Sqrt[mq2[3, 3]]/\[Mu]])/tb^2 + ((1 + tb^2)*TCF[6][
                    Sqrt[mu2[3, 3]]/\[Mu]])/(2*tb^2)) - (4*g3^2*
                 (Log[M3^2/Q^2] + TCF[6][Sqrt[mq2[3, 3]]/M3] + TCF[6][
                   Sqrt[mu2[3, 3]]/M3] - ((At - \[Mu]/tb)*TCF[9][
                     Sqrt[mq2[3, 3]]/M3, Sqrt[mu2[3, 3]]/M3])/M3))/3))/tb^2)/
           tb - (\[Mu]*((-3*gt^2*(1 + tb^2)*Log[MS/Q]*(-3*gt^2*Log[MS/Q] - 
                (3*gt^2*Log[MS/Q])/tb^2))/tb^2 - 
             (((1 + tb^2)*(-27*gt^4 + 32*g3^2*gt^2*tb^2 - 27*gt^4*tb^2)*
                 Log[MS/Q]^2)/(2*tb^3) - (6*gt^2*(1 + tb^2)*Log[MS/Q]*
                 ((-4*g3^2)/3 - gt^2*((3*(-1 + 2*Log[mA^2/Q^2]))/(8*tb^2) + 
                    (3*(1 + tb^2)*Log[\[Mu]^2/Q^2])/(4*tb^2) - 
                    ((At - \[Mu]/tb)^2*TCF[5][Sqrt[mq2[3, 3]]/Sqrt[mu2[3, 
                          3]]])/(4*Sqrt[mq2[3, 3]*mu2[3, 3]]) + 
                    ((1 + tb^2)*TCF[6][Sqrt[mq2[3, 3]]/\[Mu]])/tb^2 + 
                    ((1 + tb^2)*TCF[6][Sqrt[mu2[3, 3]]/\[Mu]])/(2*tb^2)) - 
                  (4*g3^2*(Log[M3^2/Q^2] + TCF[6][Sqrt[mq2[3, 3]]/M3] + 
                     TCF[6][Sqrt[mu2[3, 3]]/M3] - ((At - \[Mu]/tb)*TCF[9][
                        Sqrt[mq2[3, 3]]/M3, Sqrt[mu2[3, 3]]/M3])/M3))/3))/tb)/
              tb))/tb)))/Sqrt[mq2[3, 3]*mu2[3, 3]] + 
     (At - \[Mu]/tb)^2*
      ((gt^4*((3*(-160*g3^2*gt*Log[MS/Q] + 90*gt^3*Log[MS/Q])^2)/(200*gt^2) + 
          (4*(88*g3^4*gt*Log[MS/Q]^2 - 72*g3^2*gt^3*Log[MS/Q]^2 + 
             (243*gt^5*Log[MS/Q]^2)/8))/gt))/Sqrt[mq2[3, 3]*mu2[3, 3]] - 
       (gt^3*(-160*g3^2*gt*Log[MS/Q] + 90*gt^3*Log[MS/Q])*
         (mu2[3, 3]*((-32*g3^2*M3^2*Log[MS/Q])/3 + (2*gt^2*mA^2*Log[MS/Q])/
             tb^2 + (2*At^2*gt^2*(1 + tb^2)*Log[MS/Q])/tb^2 - 
            (2*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/tb^2 + 
            (2*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3])/tb^2 + 
            (2*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^2) + 
          mq2[3, 3]*((-32*g3^2*M3^2*Log[MS/Q])/3 + (4*gt^2*mA^2*Log[MS/Q])/
             tb^2 + (4*At^2*gt^2*(1 + tb^2)*Log[MS/Q])/tb^2 - 
            (4*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/tb^2 + 
            (4*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3])/tb^2 + 
            (4*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^2)))/
        (10*mq2[3, 3]*mu2[3, 3]*Sqrt[mq2[3, 3]*mu2[3, 3]]) + 
       (gt^4*((3*(mu2[3, 3]*((-32*g3^2*M3^2*Log[MS/Q])/3 + 
                (2*gt^2*mA^2*Log[MS/Q])/tb^2 + (2*At^2*gt^2*(1 + tb^2)*
                  Log[MS/Q])/tb^2 - (2*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/
                 tb^2 + (2*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3])/tb^2 + 
                (2*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^2) + 
              mq2[3, 3]*((-32*g3^2*M3^2*Log[MS/Q])/3 + (4*gt^2*mA^2*
                  Log[MS/Q])/tb^2 + (4*At^2*gt^2*(1 + tb^2)*Log[MS/Q])/tb^2 - 
                (4*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/tb^2 + 
                (4*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3])/tb^2 + 
                (4*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^2))^2)/
           (4*mq2[3, 3]^2*mu2[3, 3]^2) - 
          (((-32*g3^2*M3^2*Log[MS/Q])/3 + (2*gt^2*mA^2*Log[MS/Q])/tb^2 + 
              (2*At^2*gt^2*(1 + tb^2)*Log[MS/Q])/tb^2 - (2*gt^2*(1 + tb^2)*
                \[Mu]^2*Log[MS/Q])/tb^2 + (2*gt^2*(1 + tb^2)*Log[MS/Q]*
                mq2[3, 3])/tb^2 + (2*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^
                2)*((-32*g3^2*M3^2*Log[MS/Q])/3 + (4*gt^2*mA^2*Log[MS/Q])/tb^
                2 + (4*At^2*gt^2*(1 + tb^2)*Log[MS/Q])/tb^2 - 
              (4*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/tb^2 + (4*gt^2*(1 + tb^2)*
                Log[MS/Q]*mq2[3, 3])/tb^2 + (4*gt^2*(1 + tb^2)*Log[MS/Q]*
                mu2[3, 3])/tb^2) + mu2[3, 3]*(96*g3^4*M3^2*Log[MS/Q]^2 - 
              (32*g3^2*gt^2*mA^2*Log[MS/Q]^2)/(3*tb^2) + (6*gt^4*mA^2*
                Log[MS/Q]^2)/tb^2 + (18*gt^4*mA^2*(1 + tb^2)*Log[MS/Q]^2)/tb^
                4 - (32*At^2*g3^2*gt^2*(1 + tb^2)*Log[MS/Q]^2)/(3*tb^2) + 
              (64*At*g3^2*gt^2*M3*(1 + tb^2)*Log[MS/Q]^2)/(3*tb^2) - 
              (64*g3^2*gt^2*M3^2*(1 + tb^2)*Log[MS/Q]^2)/(3*tb^2) + 
              (42*At^2*gt^4*(1 + tb^2)^2*Log[MS/Q]^2)/tb^4 + (32*g3^2*gt^2*
                (1 + tb^2)*\[Mu]^2*Log[MS/Q]^2)/(3*tb^2) - 
              (24*gt^4*(1 + tb^2)^2*\[Mu]^2*Log[MS/Q]^2)/tb^4 + 
              (g3^4*M3^2*Log[MS/Q]*(-6 + 12*Log[M3^2/Q^2] + Log[md2[1, 1]/
                   Q^2] + Log[md2[2, 2]/Q^2] + Log[md2[3, 3]/Q^2] + 
                 2*Log[mq2[1, 1]/Q^2] + 2*Log[mq2[2, 2]/Q^2] + 
                 2*Log[mq2[3, 3]/Q^2] + Log[mu2[1, 1]/Q^2] + 
                 Log[mu2[2, 2]/Q^2] + Log[mu2[3, 3]/Q^2]))/(9*Pi^2) - 
              (32*g3^2*gt^2*(1 + tb^2)*Log[MS/Q]^2*mq2[3, 3])/(3*tb^2) + 
              (18*gt^4*(1 + tb^2)^2*Log[MS/Q]^2*mq2[3, 3])/tb^4 - 
              (32*g3^2*gt^2*(1 + tb^2)*Log[MS/Q]^2*mu2[3, 3])/(3*tb^2) + 
              (18*gt^4*(1 + tb^2)^2*Log[MS/Q]^2*mu2[3, 3])/tb^4 + 
              (4*gt^2*mA^2*Log[MS/Q]*((-4*g3^2)/3 - gt^2*
                  ((3*(-1 + 2*Log[mA^2/Q^2]))/(8*tb^2) + (3*(1 + tb^2)*
                     Log[\[Mu]^2/Q^2])/(4*tb^2) - ((At - \[Mu]/tb)^2*
                     TCF[5][Sqrt[mq2[3, 3]]/Sqrt[mu2[3, 3]]])/
                    (4*Sqrt[mq2[3, 3]*mu2[3, 3]]) + ((1 + tb^2)*TCF[6][
                      Sqrt[mq2[3, 3]]/\[Mu]])/tb^2 + ((1 + tb^2)*TCF[6][
                      Sqrt[mu2[3, 3]]/\[Mu]])/(2*tb^2)) - 
                 (4*g3^2*(Log[M3^2/Q^2] + TCF[6][Sqrt[mq2[3, 3]]/M3] + 
                    TCF[6][Sqrt[mu2[3, 3]]/M3] - ((At - \[Mu]/tb)*TCF[9][
                       Sqrt[mq2[3, 3]]/M3, Sqrt[mu2[3, 3]]/M3])/M3))/3))/tb^
                2 + (4*At^2*gt^2*(1 + tb^2)*Log[MS/Q]*((-4*g3^2)/3 - 
                 gt^2*((3*(-1 + 2*Log[mA^2/Q^2]))/(8*tb^2) + (3*(1 + tb^2)*
                     Log[\[Mu]^2/Q^2])/(4*tb^2) - ((At - \[Mu]/tb)^2*
                     TCF[5][Sqrt[mq2[3, 3]]/Sqrt[mu2[3, 3]]])/
                    (4*Sqrt[mq2[3, 3]*mu2[3, 3]]) + ((1 + tb^2)*TCF[6][
                      Sqrt[mq2[3, 3]]/\[Mu]])/tb^2 + ((1 + tb^2)*TCF[6][
                      Sqrt[mu2[3, 3]]/\[Mu]])/(2*tb^2)) - 
                 (4*g3^2*(Log[M3^2/Q^2] + TCF[6][Sqrt[mq2[3, 3]]/M3] + 
                    TCF[6][Sqrt[mu2[3, 3]]/M3] - ((At - \[Mu]/tb)*TCF[9][
                       Sqrt[mq2[3, 3]]/M3, Sqrt[mu2[3, 3]]/M3])/M3))/3))/tb^
                2 - (4*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q]*((-4*g3^2)/3 - 
                 gt^2*((3*(-1 + 2*Log[mA^2/Q^2]))/(8*tb^2) + (3*(1 + tb^2)*
                     Log[\[Mu]^2/Q^2])/(4*tb^2) - ((At - \[Mu]/tb)^2*
                     TCF[5][Sqrt[mq2[3, 3]]/Sqrt[mu2[3, 3]]])/
                    (4*Sqrt[mq2[3, 3]*mu2[3, 3]]) + ((1 + tb^2)*TCF[6][
                      Sqrt[mq2[3, 3]]/\[Mu]])/tb^2 + ((1 + tb^2)*TCF[6][
                      Sqrt[mu2[3, 3]]/\[Mu]])/(2*tb^2)) - 
                 (4*g3^2*(Log[M3^2/Q^2] + TCF[6][Sqrt[mq2[3, 3]]/M3] + 
                    TCF[6][Sqrt[mu2[3, 3]]/M3] - ((At - \[Mu]/tb)*TCF[9][
                       Sqrt[mq2[3, 3]]/M3, Sqrt[mu2[3, 3]]/M3])/M3))/3))/tb^
                2 + (4*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3]*((-4*g3^2)/3 - 
                 gt^2*((3*(-1 + 2*Log[mA^2/Q^2]))/(8*tb^2) + (3*(1 + tb^2)*
                     Log[\[Mu]^2/Q^2])/(4*tb^2) - ((At - \[Mu]/tb)^2*
                     TCF[5][Sqrt[mq2[3, 3]]/Sqrt[mu2[3, 3]]])/
                    (4*Sqrt[mq2[3, 3]*mu2[3, 3]]) + ((1 + tb^2)*TCF[6][
                      Sqrt[mq2[3, 3]]/\[Mu]])/tb^2 + ((1 + tb^2)*TCF[6][
                      Sqrt[mu2[3, 3]]/\[Mu]])/(2*tb^2)) - 
                 (4*g3^2*(Log[M3^2/Q^2] + TCF[6][Sqrt[mq2[3, 3]]/M3] + 
                    TCF[6][Sqrt[mu2[3, 3]]/M3] - ((At - \[Mu]/tb)*TCF[9][
                       Sqrt[mq2[3, 3]]/M3, Sqrt[mu2[3, 3]]/M3])/M3))/3))/tb^
                2 + (4*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3]*((-4*g3^2)/3 - 
                 gt^2*((3*(-1 + 2*Log[mA^2/Q^2]))/(8*tb^2) + (3*(1 + tb^2)*
                     Log[\[Mu]^2/Q^2])/(4*tb^2) - ((At - \[Mu]/tb)^2*
                     TCF[5][Sqrt[mq2[3, 3]]/Sqrt[mu2[3, 3]]])/
                    (4*Sqrt[mq2[3, 3]*mu2[3, 3]]) + ((1 + tb^2)*TCF[6][
                      Sqrt[mq2[3, 3]]/\[Mu]])/tb^2 + ((1 + tb^2)*TCF[6][
                      Sqrt[mu2[3, 3]]/\[Mu]])/(2*tb^2)) - 
                 (4*g3^2*(Log[M3^2/Q^2] + TCF[6][Sqrt[mq2[3, 3]]/M3] + 
                    TCF[6][Sqrt[mu2[3, 3]]/M3] - ((At - \[Mu]/tb)*TCF[9][
                       Sqrt[mq2[3, 3]]/M3, Sqrt[mu2[3, 3]]/M3])/M3))/3))/tb^
                2) + mq2[3, 3]*(96*g3^4*M3^2*Log[MS/Q]^2 - (64*g3^2*gt^2*mA^2*
                Log[MS/Q]^2)/(3*tb^2) + (12*gt^4*mA^2*Log[MS/Q]^2)/tb^2 + 
              (36*gt^4*mA^2*(1 + tb^2)*Log[MS/Q]^2)/tb^4 - (64*At^2*g3^2*gt^2*
                (1 + tb^2)*Log[MS/Q]^2)/(3*tb^2) + (128*At*g3^2*gt^2*M3*
                (1 + tb^2)*Log[MS/Q]^2)/(3*tb^2) - (128*g3^2*gt^2*M3^2*
                (1 + tb^2)*Log[MS/Q]^2)/(3*tb^2) + (84*At^2*gt^4*(1 + tb^2)^2*
                Log[MS/Q]^2)/tb^4 + (64*g3^2*gt^2*(1 + tb^2)*\[Mu]^2*
                Log[MS/Q]^2)/(3*tb^2) - (48*gt^4*(1 + tb^2)^2*\[Mu]^2*
                Log[MS/Q]^2)/tb^4 + (g3^4*M3^2*Log[MS/Q]*(-6 + 
                 12*Log[M3^2/Q^2] + Log[md2[1, 1]/Q^2] + Log[md2[2, 2]/Q^2] + 
                 Log[md2[3, 3]/Q^2] + 2*Log[mq2[1, 1]/Q^2] + 
                 2*Log[mq2[2, 2]/Q^2] + 2*Log[mq2[3, 3]/Q^2] + 
                 Log[mu2[1, 1]/Q^2] + Log[mu2[2, 2]/Q^2] + Log[mu2[3, 3]/
                   Q^2]))/(9*Pi^2) - (64*g3^2*gt^2*(1 + tb^2)*Log[MS/Q]^2*
                mq2[3, 3])/(3*tb^2) + (36*gt^4*(1 + tb^2)^2*Log[MS/Q]^2*
                mq2[3, 3])/tb^4 - (64*g3^2*gt^2*(1 + tb^2)*Log[MS/Q]^2*
                mu2[3, 3])/(3*tb^2) + (36*gt^4*(1 + tb^2)^2*Log[MS/Q]^2*
                mu2[3, 3])/tb^4 + (8*gt^2*mA^2*Log[MS/Q]*((-4*g3^2)/3 - 
                 gt^2*((3*(-1 + 2*Log[mA^2/Q^2]))/(8*tb^2) + (3*(1 + tb^2)*
                     Log[\[Mu]^2/Q^2])/(4*tb^2) - ((At - \[Mu]/tb)^2*
                     TCF[5][Sqrt[mq2[3, 3]]/Sqrt[mu2[3, 3]]])/
                    (4*Sqrt[mq2[3, 3]*mu2[3, 3]]) + ((1 + tb^2)*TCF[6][
                      Sqrt[mq2[3, 3]]/\[Mu]])/tb^2 + ((1 + tb^2)*TCF[6][
                      Sqrt[mu2[3, 3]]/\[Mu]])/(2*tb^2)) - 
                 (4*g3^2*(Log[M3^2/Q^2] + TCF[6][Sqrt[mq2[3, 3]]/M3] + 
                    TCF[6][Sqrt[mu2[3, 3]]/M3] - ((At - \[Mu]/tb)*TCF[9][
                       Sqrt[mq2[3, 3]]/M3, Sqrt[mu2[3, 3]]/M3])/M3))/3))/tb^
                2 + (8*At^2*gt^2*(1 + tb^2)*Log[MS/Q]*((-4*g3^2)/3 - 
                 gt^2*((3*(-1 + 2*Log[mA^2/Q^2]))/(8*tb^2) + (3*(1 + tb^2)*
                     Log[\[Mu]^2/Q^2])/(4*tb^2) - ((At - \[Mu]/tb)^2*
                     TCF[5][Sqrt[mq2[3, 3]]/Sqrt[mu2[3, 3]]])/
                    (4*Sqrt[mq2[3, 3]*mu2[3, 3]]) + ((1 + tb^2)*TCF[6][
                      Sqrt[mq2[3, 3]]/\[Mu]])/tb^2 + ((1 + tb^2)*TCF[6][
                      Sqrt[mu2[3, 3]]/\[Mu]])/(2*tb^2)) - 
                 (4*g3^2*(Log[M3^2/Q^2] + TCF[6][Sqrt[mq2[3, 3]]/M3] + 
                    TCF[6][Sqrt[mu2[3, 3]]/M3] - ((At - \[Mu]/tb)*TCF[9][
                       Sqrt[mq2[3, 3]]/M3, Sqrt[mu2[3, 3]]/M3])/M3))/3))/tb^
                2 - (8*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q]*((-4*g3^2)/3 - 
                 gt^2*((3*(-1 + 2*Log[mA^2/Q^2]))/(8*tb^2) + (3*(1 + tb^2)*
                     Log[\[Mu]^2/Q^2])/(4*tb^2) - ((At - \[Mu]/tb)^2*
                     TCF[5][Sqrt[mq2[3, 3]]/Sqrt[mu2[3, 3]]])/
                    (4*Sqrt[mq2[3, 3]*mu2[3, 3]]) + ((1 + tb^2)*TCF[6][
                      Sqrt[mq2[3, 3]]/\[Mu]])/tb^2 + ((1 + tb^2)*TCF[6][
                      Sqrt[mu2[3, 3]]/\[Mu]])/(2*tb^2)) - 
                 (4*g3^2*(Log[M3^2/Q^2] + TCF[6][Sqrt[mq2[3, 3]]/M3] + 
                    TCF[6][Sqrt[mu2[3, 3]]/M3] - ((At - \[Mu]/tb)*TCF[9][
                       Sqrt[mq2[3, 3]]/M3, Sqrt[mu2[3, 3]]/M3])/M3))/3))/tb^
                2 + (8*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3]*((-4*g3^2)/3 - 
                 gt^2*((3*(-1 + 2*Log[mA^2/Q^2]))/(8*tb^2) + (3*(1 + tb^2)*
                     Log[\[Mu]^2/Q^2])/(4*tb^2) - ((At - \[Mu]/tb)^2*
                     TCF[5][Sqrt[mq2[3, 3]]/Sqrt[mu2[3, 3]]])/
                    (4*Sqrt[mq2[3, 3]*mu2[3, 3]]) + ((1 + tb^2)*TCF[6][
                      Sqrt[mq2[3, 3]]/\[Mu]])/tb^2 + ((1 + tb^2)*TCF[6][
                      Sqrt[mu2[3, 3]]/\[Mu]])/(2*tb^2)) - 
                 (4*g3^2*(Log[M3^2/Q^2] + TCF[6][Sqrt[mq2[3, 3]]/M3] + 
                    TCF[6][Sqrt[mu2[3, 3]]/M3] - ((At - \[Mu]/tb)*TCF[9][
                       Sqrt[mq2[3, 3]]/M3, Sqrt[mu2[3, 3]]/M3])/M3))/3))/tb^
                2 + (8*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3]*((-4*g3^2)/3 - 
                 gt^2*((3*(-1 + 2*Log[mA^2/Q^2]))/(8*tb^2) + (3*(1 + tb^2)*
                     Log[\[Mu]^2/Q^2])/(4*tb^2) - ((At - \[Mu]/tb)^2*
                     TCF[5][Sqrt[mq2[3, 3]]/Sqrt[mu2[3, 3]]])/
                    (4*Sqrt[mq2[3, 3]*mu2[3, 3]]) + ((1 + tb^2)*TCF[6][
                      Sqrt[mq2[3, 3]]/\[Mu]])/tb^2 + ((1 + tb^2)*TCF[6][
                      Sqrt[mu2[3, 3]]/\[Mu]])/(2*tb^2)) - 
                 (4*g3^2*(Log[M3^2/Q^2] + TCF[6][Sqrt[mq2[3, 3]]/M3] + 
                    TCF[6][Sqrt[mu2[3, 3]]/M3] - ((At - \[Mu]/tb)*TCF[9][
                       Sqrt[mq2[3, 3]]/M3, Sqrt[mu2[3, 3]]/M3])/M3))/3))/tb^
                2))/(mq2[3, 3]*mu2[3, 3])))/(2*Sqrt[mq2[3, 3]*mu2[3, 3]]))) + 
   ((2*gt^4*(At - \[Mu]/tb)*((32*g3^2*M3*Log[MS/Q])/3 + 
        (12*At*gt^2*(1 + tb^2)*Log[MS/Q])/tb^2 - 
        (3*(10*gt^2*\[Mu]*Log[MS/Q] + 10*gt^2*tb^2*\[Mu]*Log[MS/Q]))/
         (5*tb^3)))/Sqrt[mq2[3, 3]*mu2[3, 3]] + (At - \[Mu]/tb)^2*
      ((gt^3*(-160*g3^2*gt*Log[MS/Q] + 90*gt^3*Log[MS/Q]))/
        (5*Sqrt[mq2[3, 3]*mu2[3, 3]]) - 
       (gt^4*(mu2[3, 3]*((-32*g3^2*M3^2*Log[MS/Q])/3 + 
            (2*gt^2*mA^2*Log[MS/Q])/tb^2 + (2*At^2*gt^2*(1 + tb^2)*Log[MS/Q])/
             tb^2 - (2*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/tb^2 + 
            (2*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3])/tb^2 + 
            (2*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^2) + 
          mq2[3, 3]*((-32*g3^2*M3^2*Log[MS/Q])/3 + (4*gt^2*mA^2*Log[MS/Q])/
             tb^2 + (4*At^2*gt^2*(1 + tb^2)*Log[MS/Q])/tb^2 - 
            (4*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/tb^2 + 
            (4*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3])/tb^2 + 
            (4*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^2)))/
        (2*mq2[3, 3]*mu2[3, 3]*Sqrt[mq2[3, 3]*mu2[3, 3]])))*
    ((Sqrt[mq2[3, 3]/mu2[3, 3]]*mu2[3, 3]*
       ((mq2[3, 3]*(-4*gt^2*Log[MS/Q] - (4*gt^2*Log[MS/Q])/tb^2 - 
           (4*At^2*gt^2*Log[MS/Q])/mu2[3, 3] + (32*g3^2*M3^2*Log[MS/Q])/
            (3*mu2[3, 3]) - (4*At^2*gt^2*Log[MS/Q])/(tb^2*mu2[3, 3]) - 
           (4*gt^2*mA^2*Log[MS/Q])/(tb^2*mu2[3, 3]) + 
           (4*gt^2*\[Mu]^2*Log[MS/Q])/mu2[3, 3] + (4*gt^2*\[Mu]^2*Log[MS/Q])/
            (tb^2*mu2[3, 3]) - (4*gt^2*Log[MS/Q]*mq2[3, 3])/mu2[3, 3] - 
           (4*gt^2*Log[MS/Q]*mq2[3, 3])/(tb^2*mu2[3, 3])))/mu2[3, 3] + 
        ((-32*g3^2*M3^2*Log[MS/Q])/3 + (2*gt^2*mA^2*Log[MS/Q])/tb^2 + 
          (2*At^2*gt^2*(1 + tb^2)*Log[MS/Q])/tb^2 - 
          (2*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/tb^2 + 
          (2*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3])/tb^2 + 
          (2*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^2)/mu2[3, 3])*
       Derivative[1][TCF[1]][Sqrt[mq2[3, 3]/mu2[3, 3]]])/(2*mq2[3, 3]) + 
     ((-2*(At - \[Mu]/tb)*((32*g3^2*M3*Log[MS/Q])/3 + 
          (12*At*gt^2*(1 + tb^2)*Log[MS/Q])/tb^2 - 
          (3*(10*gt^2*\[Mu]*Log[MS/Q] + 10*gt^2*tb^2*\[Mu]*Log[MS/Q]))/
           (5*tb^3))*TCF[2][Sqrt[mq2[3, 3]/mu2[3, 3]]])/
        Sqrt[mq2[3, 3]*mu2[3, 3]] - (At - \[Mu]/tb)^2*
        (-((mu2[3, 3]*((-32*g3^2*M3^2*Log[MS/Q])/3 + (2*gt^2*mA^2*Log[MS/Q])/
                tb^2 + (2*At^2*gt^2*(1 + tb^2)*Log[MS/Q])/tb^2 - 
               (2*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/tb^2 + (2*gt^2*
                 (1 + tb^2)*Log[MS/Q]*mq2[3, 3])/tb^2 + (2*gt^2*(1 + tb^2)*
                 Log[MS/Q]*mu2[3, 3])/tb^2) + mq2[3, 3]*((-32*g3^2*M3^2*
                 Log[MS/Q])/3 + (4*gt^2*mA^2*Log[MS/Q])/tb^2 + (4*At^2*gt^2*
                 (1 + tb^2)*Log[MS/Q])/tb^2 - (4*gt^2*(1 + tb^2)*\[Mu]^2*
                 Log[MS/Q])/tb^2 + (4*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3])/
                tb^2 + (4*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^2))*
            TCF[2][Sqrt[mq2[3, 3]/mu2[3, 3]]])/(2*mq2[3, 3]*mu2[3, 3]*
           Sqrt[mq2[3, 3]*mu2[3, 3]]) + (Sqrt[mq2[3, 3]/mu2[3, 3]]*mu2[3, 3]*
           ((mq2[3, 3]*(-4*gt^2*Log[MS/Q] - (4*gt^2*Log[MS/Q])/tb^2 - 
               (4*At^2*gt^2*Log[MS/Q])/mu2[3, 3] + (32*g3^2*M3^2*Log[MS/Q])/
                (3*mu2[3, 3]) - (4*At^2*gt^2*Log[MS/Q])/(tb^2*mu2[3, 3]) - 
               (4*gt^2*mA^2*Log[MS/Q])/(tb^2*mu2[3, 3]) + (4*gt^2*\[Mu]^2*
                 Log[MS/Q])/mu2[3, 3] + (4*gt^2*\[Mu]^2*Log[MS/Q])/
                (tb^2*mu2[3, 3]) - (4*gt^2*Log[MS/Q]*mq2[3, 3])/mu2[3, 3] - 
               (4*gt^2*Log[MS/Q]*mq2[3, 3])/(tb^2*mu2[3, 3])))/mu2[3, 3] + 
            ((-32*g3^2*M3^2*Log[MS/Q])/3 + (2*gt^2*mA^2*Log[MS/Q])/tb^2 + 
              (2*At^2*gt^2*(1 + tb^2)*Log[MS/Q])/tb^2 - (2*gt^2*(1 + tb^2)*
                \[Mu]^2*Log[MS/Q])/tb^2 + (2*gt^2*(1 + tb^2)*Log[MS/Q]*
                mq2[3, 3])/tb^2 + (2*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^
                2)/mu2[3, 3])*Derivative[1][TCF[2]][
            Sqrt[mq2[3, 3]/mu2[3, 3]]])/(2*mq2[3, 3]*
           Sqrt[mq2[3, 3]*mu2[3, 3]])))/12) + 
   (gt^4*(At - \[Mu]/tb)^2*((Sqrt[mq2[3, 3]/mu2[3, 3]]*
        (-(mu2[3, 3]^2*((mq2[3, 3]*(-4*gt^2*Log[MS/Q] - (4*gt^2*Log[MS/Q])/
                  tb^2 - (4*At^2*gt^2*Log[MS/Q])/mu2[3, 3] + 
                 (32*g3^2*M3^2*Log[MS/Q])/(3*mu2[3, 3]) - (4*At^2*gt^2*
                   Log[MS/Q])/(tb^2*mu2[3, 3]) - (4*gt^2*mA^2*Log[MS/Q])/
                  (tb^2*mu2[3, 3]) + (4*gt^2*\[Mu]^2*Log[MS/Q])/mu2[3, 3] + 
                 (4*gt^2*\[Mu]^2*Log[MS/Q])/(tb^2*mu2[3, 3]) - 
                 (4*gt^2*Log[MS/Q]*mq2[3, 3])/mu2[3, 3] - (4*gt^2*Log[MS/Q]*
                   mq2[3, 3])/(tb^2*mu2[3, 3])))/mu2[3, 3] + 
              ((-32*g3^2*M3^2*Log[MS/Q])/3 + (2*gt^2*mA^2*Log[MS/Q])/tb^2 + 
                (2*At^2*gt^2*(1 + tb^2)*Log[MS/Q])/tb^2 - (2*gt^2*(1 + tb^2)*
                  \[Mu]^2*Log[MS/Q])/tb^2 + (2*gt^2*(1 + tb^2)*Log[MS/Q]*
                  mq2[3, 3])/tb^2 + (2*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/
                 tb^2)/mu2[3, 3])^2)/(4*mq2[3, 3]^2) + 
         (mu2[3, 3]*(((-4*gt^2*Log[MS/Q] - (4*gt^2*Log[MS/Q])/tb^2 - 
               (4*At^2*gt^2*Log[MS/Q])/mu2[3, 3] + (32*g3^2*M3^2*Log[MS/Q])/
                (3*mu2[3, 3]) - (4*At^2*gt^2*Log[MS/Q])/(tb^2*mu2[3, 3]) - 
               (4*gt^2*mA^2*Log[MS/Q])/(tb^2*mu2[3, 3]) + (4*gt^2*\[Mu]^2*
                 Log[MS/Q])/mu2[3, 3] + (4*gt^2*\[Mu]^2*Log[MS/Q])/
                (tb^2*mu2[3, 3]) - (4*gt^2*Log[MS/Q]*mq2[3, 3])/mu2[3, 3] - 
               (4*gt^2*Log[MS/Q]*mq2[3, 3])/(tb^2*mu2[3, 3]))*
              ((-32*g3^2*M3^2*Log[MS/Q])/3 + (2*gt^2*mA^2*Log[MS/Q])/tb^2 + 
               (2*At^2*gt^2*(1 + tb^2)*Log[MS/Q])/tb^2 - (2*gt^2*(1 + tb^2)*
                 \[Mu]^2*Log[MS/Q])/tb^2 + (2*gt^2*(1 + tb^2)*Log[MS/Q]*
                 mq2[3, 3])/tb^2 + (2*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/
                tb^2))/mu2[3, 3] + (96*g3^4*M3^2*Log[MS/Q]^2 - 
              (32*g3^2*gt^2*mA^2*Log[MS/Q]^2)/(3*tb^2) + (6*gt^4*mA^2*
                Log[MS/Q]^2)/tb^2 + (18*gt^4*mA^2*(1 + tb^2)*Log[MS/Q]^2)/tb^
                4 - (32*At^2*g3^2*gt^2*(1 + tb^2)*Log[MS/Q]^2)/(3*tb^2) + 
              (64*At*g3^2*gt^2*M3*(1 + tb^2)*Log[MS/Q]^2)/(3*tb^2) - 
              (64*g3^2*gt^2*M3^2*(1 + tb^2)*Log[MS/Q]^2)/(3*tb^2) + 
              (42*At^2*gt^4*(1 + tb^2)^2*Log[MS/Q]^2)/tb^4 + (32*g3^2*gt^2*
                (1 + tb^2)*\[Mu]^2*Log[MS/Q]^2)/(3*tb^2) - 
              (24*gt^4*(1 + tb^2)^2*\[Mu]^2*Log[MS/Q]^2)/tb^4 + 
              (g3^4*M3^2*Log[MS/Q]*(-6 + 12*Log[M3^2/Q^2] + Log[md2[1, 1]/
                   Q^2] + Log[md2[2, 2]/Q^2] + Log[md2[3, 3]/Q^2] + 
                 2*Log[mq2[1, 1]/Q^2] + 2*Log[mq2[2, 2]/Q^2] + 
                 2*Log[mq2[3, 3]/Q^2] + Log[mu2[1, 1]/Q^2] + 
                 Log[mu2[2, 2]/Q^2] + Log[mu2[3, 3]/Q^2]))/(9*Pi^2) - 
              (32*g3^2*gt^2*(1 + tb^2)*Log[MS/Q]^2*mq2[3, 3])/(3*tb^2) + 
              (18*gt^4*(1 + tb^2)^2*Log[MS/Q]^2*mq2[3, 3])/tb^4 - 
              (32*g3^2*gt^2*(1 + tb^2)*Log[MS/Q]^2*mu2[3, 3])/(3*tb^2) + 
              (18*gt^4*(1 + tb^2)^2*Log[MS/Q]^2*mu2[3, 3])/tb^4 + 
              (4*gt^2*mA^2*Log[MS/Q]*((-4*g3^2)/3 - gt^2*
                  ((3*(-1 + 2*Log[mA^2/Q^2]))/(8*tb^2) + (3*(1 + tb^2)*
                     Log[\[Mu]^2/Q^2])/(4*tb^2) - ((At - \[Mu]/tb)^2*
                     TCF[5][Sqrt[mq2[3, 3]]/Sqrt[mu2[3, 3]]])/
                    (4*Sqrt[mq2[3, 3]*mu2[3, 3]]) + ((1 + tb^2)*TCF[6][
                      Sqrt[mq2[3, 3]]/\[Mu]])/tb^2 + ((1 + tb^2)*TCF[6][
                      Sqrt[mu2[3, 3]]/\[Mu]])/(2*tb^2)) - 
                 (4*g3^2*(Log[M3^2/Q^2] + TCF[6][Sqrt[mq2[3, 3]]/M3] + 
                    TCF[6][Sqrt[mu2[3, 3]]/M3] - ((At - \[Mu]/tb)*TCF[9][
                       Sqrt[mq2[3, 3]]/M3, Sqrt[mu2[3, 3]]/M3])/M3))/3))/tb^
                2 + (4*At^2*gt^2*(1 + tb^2)*Log[MS/Q]*((-4*g3^2)/3 - 
                 gt^2*((3*(-1 + 2*Log[mA^2/Q^2]))/(8*tb^2) + (3*(1 + tb^2)*
                     Log[\[Mu]^2/Q^2])/(4*tb^2) - ((At - \[Mu]/tb)^2*
                     TCF[5][Sqrt[mq2[3, 3]]/Sqrt[mu2[3, 3]]])/
                    (4*Sqrt[mq2[3, 3]*mu2[3, 3]]) + ((1 + tb^2)*TCF[6][
                      Sqrt[mq2[3, 3]]/\[Mu]])/tb^2 + ((1 + tb^2)*TCF[6][
                      Sqrt[mu2[3, 3]]/\[Mu]])/(2*tb^2)) - 
                 (4*g3^2*(Log[M3^2/Q^2] + TCF[6][Sqrt[mq2[3, 3]]/M3] + 
                    TCF[6][Sqrt[mu2[3, 3]]/M3] - ((At - \[Mu]/tb)*TCF[9][
                       Sqrt[mq2[3, 3]]/M3, Sqrt[mu2[3, 3]]/M3])/M3))/3))/tb^
                2 - (4*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q]*((-4*g3^2)/3 - 
                 gt^2*((3*(-1 + 2*Log[mA^2/Q^2]))/(8*tb^2) + (3*(1 + tb^2)*
                     Log[\[Mu]^2/Q^2])/(4*tb^2) - ((At - \[Mu]/tb)^2*
                     TCF[5][Sqrt[mq2[3, 3]]/Sqrt[mu2[3, 3]]])/
                    (4*Sqrt[mq2[3, 3]*mu2[3, 3]]) + ((1 + tb^2)*TCF[6][
                      Sqrt[mq2[3, 3]]/\[Mu]])/tb^2 + ((1 + tb^2)*TCF[6][
                      Sqrt[mu2[3, 3]]/\[Mu]])/(2*tb^2)) - 
                 (4*g3^2*(Log[M3^2/Q^2] + TCF[6][Sqrt[mq2[3, 3]]/M3] + 
                    TCF[6][Sqrt[mu2[3, 3]]/M3] - ((At - \[Mu]/tb)*TCF[9][
                       Sqrt[mq2[3, 3]]/M3, Sqrt[mu2[3, 3]]/M3])/M3))/3))/tb^
                2 + (4*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3]*((-4*g3^2)/3 - 
                 gt^2*((3*(-1 + 2*Log[mA^2/Q^2]))/(8*tb^2) + (3*(1 + tb^2)*
                     Log[\[Mu]^2/Q^2])/(4*tb^2) - ((At - \[Mu]/tb)^2*
                     TCF[5][Sqrt[mq2[3, 3]]/Sqrt[mu2[3, 3]]])/
                    (4*Sqrt[mq2[3, 3]*mu2[3, 3]]) + ((1 + tb^2)*TCF[6][
                      Sqrt[mq2[3, 3]]/\[Mu]])/tb^2 + ((1 + tb^2)*TCF[6][
                      Sqrt[mu2[3, 3]]/\[Mu]])/(2*tb^2)) - 
                 (4*g3^2*(Log[M3^2/Q^2] + TCF[6][Sqrt[mq2[3, 3]]/M3] + 
                    TCF[6][Sqrt[mu2[3, 3]]/M3] - ((At - \[Mu]/tb)*TCF[9][
                       Sqrt[mq2[3, 3]]/M3, Sqrt[mu2[3, 3]]/M3])/M3))/3))/tb^
                2 + (4*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3]*((-4*g3^2)/3 - 
                 gt^2*((3*(-1 + 2*Log[mA^2/Q^2]))/(8*tb^2) + (3*(1 + tb^2)*
                     Log[\[Mu]^2/Q^2])/(4*tb^2) - ((At - \[Mu]/tb)^2*
                     TCF[5][Sqrt[mq2[3, 3]]/Sqrt[mu2[3, 3]]])/
                    (4*Sqrt[mq2[3, 3]*mu2[3, 3]]) + ((1 + tb^2)*TCF[6][
                      Sqrt[mq2[3, 3]]/\[Mu]])/tb^2 + ((1 + tb^2)*TCF[6][
                      Sqrt[mu2[3, 3]]/\[Mu]])/(2*tb^2)) - 
                 (4*g3^2*(Log[M3^2/Q^2] + TCF[6][Sqrt[mq2[3, 3]]/M3] + 
                    TCF[6][Sqrt[mu2[3, 3]]/M3] - ((At - \[Mu]/tb)*TCF[9][
                       Sqrt[mq2[3, 3]]/M3, Sqrt[mu2[3, 3]]/M3])/M3))/3))/tb^
                2)/mu2[3, 3] + (mq2[3, 3]*(((4*gt^2*Log[MS/Q] + 
                  (4*gt^2*Log[MS/Q])/tb^2 + (4*At^2*gt^2*Log[MS/Q])/
                   mu2[3, 3] - (32*g3^2*M3^2*Log[MS/Q])/(3*mu2[3, 3]) + 
                  (4*At^2*gt^2*Log[MS/Q])/(tb^2*mu2[3, 3]) + (4*gt^2*mA^2*
                    Log[MS/Q])/(tb^2*mu2[3, 3]) - (4*gt^2*\[Mu]^2*Log[MS/Q])/
                   mu2[3, 3] - (4*gt^2*\[Mu]^2*Log[MS/Q])/(tb^2*mu2[3, 3]) + 
                  (4*gt^2*Log[MS/Q]*mq2[3, 3])/mu2[3, 3] + (4*gt^2*Log[MS/Q]*
                    mq2[3, 3])/(tb^2*mu2[3, 3]))*((-32*g3^2*M3^2*Log[MS/Q])/
                   3 + (4*gt^2*mA^2*Log[MS/Q])/tb^2 + (4*At^2*gt^2*(1 + tb^2)*
                    Log[MS/Q])/tb^2 - (4*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/
                   tb^2 + (4*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3])/tb^2 + 
                  (4*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^2))/mu2[3, 3] - 
               (96*g3^4*M3^2*Log[MS/Q]^2 - (64*g3^2*gt^2*mA^2*Log[MS/Q]^2)/
                  (3*tb^2) + (12*gt^4*mA^2*Log[MS/Q]^2)/tb^2 + 
                 (36*gt^4*mA^2*(1 + tb^2)*Log[MS/Q]^2)/tb^4 - 
                 (64*At^2*g3^2*gt^2*(1 + tb^2)*Log[MS/Q]^2)/(3*tb^2) + 
                 (128*At*g3^2*gt^2*M3*(1 + tb^2)*Log[MS/Q]^2)/(3*tb^2) - 
                 (128*g3^2*gt^2*M3^2*(1 + tb^2)*Log[MS/Q]^2)/(3*tb^2) + 
                 (84*At^2*gt^4*(1 + tb^2)^2*Log[MS/Q]^2)/tb^4 + 
                 (64*g3^2*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q]^2)/(3*tb^2) - 
                 (48*gt^4*(1 + tb^2)^2*\[Mu]^2*Log[MS/Q]^2)/tb^4 + 
                 (g3^4*M3^2*Log[MS/Q]*(-6 + 12*Log[M3^2/Q^2] + Log[md2[1, 1]/
                      Q^2] + Log[md2[2, 2]/Q^2] + Log[md2[3, 3]/Q^2] + 
                    2*Log[mq2[1, 1]/Q^2] + 2*Log[mq2[2, 2]/Q^2] + 
                    2*Log[mq2[3, 3]/Q^2] + Log[mu2[1, 1]/Q^2] + 
                    Log[mu2[2, 2]/Q^2] + Log[mu2[3, 3]/Q^2]))/(9*Pi^2) - 
                 (64*g3^2*gt^2*(1 + tb^2)*Log[MS/Q]^2*mq2[3, 3])/(3*tb^2) + 
                 (36*gt^4*(1 + tb^2)^2*Log[MS/Q]^2*mq2[3, 3])/tb^4 - 
                 (64*g3^2*gt^2*(1 + tb^2)*Log[MS/Q]^2*mu2[3, 3])/(3*tb^2) + 
                 (36*gt^4*(1 + tb^2)^2*Log[MS/Q]^2*mu2[3, 3])/tb^4 + 
                 (8*gt^2*mA^2*Log[MS/Q]*((-4*g3^2)/3 - gt^2*
                     ((3*(-1 + 2*Log[mA^2/Q^2]))/(8*tb^2) + (3*(1 + tb^2)*
                        Log[\[Mu]^2/Q^2])/(4*tb^2) - ((At - \[Mu]/tb)^2*
                        TCF[5][Sqrt[mq2[3, 3]]/Sqrt[mu2[3, 3]]])/
                       (4*Sqrt[mq2[3, 3]*mu2[3, 3]]) + ((1 + tb^2)*TCF[6][
                         Sqrt[mq2[3, 3]]/\[Mu]])/tb^2 + ((1 + tb^2)*TCF[6][
                         Sqrt[mu2[3, 3]]/\[Mu]])/(2*tb^2)) - 
                    (4*g3^2*(Log[M3^2/Q^2] + TCF[6][Sqrt[mq2[3, 3]]/M3] + 
                       TCF[6][Sqrt[mu2[3, 3]]/M3] - ((At - \[Mu]/tb)*TCF[9][
                          Sqrt[mq2[3, 3]]/M3, Sqrt[mu2[3, 3]]/M3])/M3))/3))/
                  tb^2 + (8*At^2*gt^2*(1 + tb^2)*Log[MS/Q]*((-4*g3^2)/3 - 
                    gt^2*((3*(-1 + 2*Log[mA^2/Q^2]))/(8*tb^2) + (3*(1 + tb^2)*
                        Log[\[Mu]^2/Q^2])/(4*tb^2) - ((At - \[Mu]/tb)^2*
                        TCF[5][Sqrt[mq2[3, 3]]/Sqrt[mu2[3, 3]]])/
                       (4*Sqrt[mq2[3, 3]*mu2[3, 3]]) + ((1 + tb^2)*TCF[6][
                         Sqrt[mq2[3, 3]]/\[Mu]])/tb^2 + ((1 + tb^2)*TCF[6][
                         Sqrt[mu2[3, 3]]/\[Mu]])/(2*tb^2)) - 
                    (4*g3^2*(Log[M3^2/Q^2] + TCF[6][Sqrt[mq2[3, 3]]/M3] + 
                       TCF[6][Sqrt[mu2[3, 3]]/M3] - ((At - \[Mu]/tb)*TCF[9][
                          Sqrt[mq2[3, 3]]/M3, Sqrt[mu2[3, 3]]/M3])/M3))/3))/
                  tb^2 - (8*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q]*((-4*g3^2)/3 - 
                    gt^2*((3*(-1 + 2*Log[mA^2/Q^2]))/(8*tb^2) + (3*(1 + tb^2)*
                        Log[\[Mu]^2/Q^2])/(4*tb^2) - ((At - \[Mu]/tb)^2*
                        TCF[5][Sqrt[mq2[3, 3]]/Sqrt[mu2[3, 3]]])/
                       (4*Sqrt[mq2[3, 3]*mu2[3, 3]]) + ((1 + tb^2)*TCF[6][
                         Sqrt[mq2[3, 3]]/\[Mu]])/tb^2 + ((1 + tb^2)*TCF[6][
                         Sqrt[mu2[3, 3]]/\[Mu]])/(2*tb^2)) - 
                    (4*g3^2*(Log[M3^2/Q^2] + TCF[6][Sqrt[mq2[3, 3]]/M3] + 
                       TCF[6][Sqrt[mu2[3, 3]]/M3] - ((At - \[Mu]/tb)*TCF[9][
                          Sqrt[mq2[3, 3]]/M3, Sqrt[mu2[3, 3]]/M3])/M3))/3))/
                  tb^2 + (8*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3]*
                   ((-4*g3^2)/3 - gt^2*((3*(-1 + 2*Log[mA^2/Q^2]))/(8*tb^2) + 
                      (3*(1 + tb^2)*Log[\[Mu]^2/Q^2])/(4*tb^2) - 
                      ((At - \[Mu]/tb)^2*TCF[5][Sqrt[mq2[3, 3]]/Sqrt[mu2[3, 
                          3]]])/(4*Sqrt[mq2[3, 3]*mu2[3, 3]]) + ((1 + tb^2)*
                        TCF[6][Sqrt[mq2[3, 3]]/\[Mu]])/tb^2 + ((1 + tb^2)*
                        TCF[6][Sqrt[mu2[3, 3]]/\[Mu]])/(2*tb^2)) - 
                    (4*g3^2*(Log[M3^2/Q^2] + TCF[6][Sqrt[mq2[3, 3]]/M3] + 
                       TCF[6][Sqrt[mu2[3, 3]]/M3] - ((At - \[Mu]/tb)*TCF[9][
                          Sqrt[mq2[3, 3]]/M3, Sqrt[mu2[3, 3]]/M3])/M3))/3))/
                  tb^2 + (8*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3]*
                   ((-4*g3^2)/3 - gt^2*((3*(-1 + 2*Log[mA^2/Q^2]))/(8*tb^2) + 
                      (3*(1 + tb^2)*Log[\[Mu]^2/Q^2])/(4*tb^2) - 
                      ((At - \[Mu]/tb)^2*TCF[5][Sqrt[mq2[3, 3]]/Sqrt[mu2[3, 
                          3]]])/(4*Sqrt[mq2[3, 3]*mu2[3, 3]]) + ((1 + tb^2)*
                        TCF[6][Sqrt[mq2[3, 3]]/\[Mu]])/tb^2 + ((1 + tb^2)*
                        TCF[6][Sqrt[mu2[3, 3]]/\[Mu]])/(2*tb^2)) - 
                    (4*g3^2*(Log[M3^2/Q^2] + TCF[6][Sqrt[mq2[3, 3]]/M3] + 
                       TCF[6][Sqrt[mu2[3, 3]]/M3] - ((At - \[Mu]/tb)*TCF[9][
                          Sqrt[mq2[3, 3]]/M3, Sqrt[mu2[3, 3]]/M3])/M3))/3))/
                  tb^2)/mu2[3, 3]))/mu2[3, 3]))/mq2[3, 3])*
        Derivative[1][TCF[1]][Sqrt[mq2[3, 3]/mu2[3, 3]]])/2 + 
      (mu2[3, 3]*((mq2[3, 3]*(-4*gt^2*Log[MS/Q] - (4*gt^2*Log[MS/Q])/tb^2 - 
             (4*At^2*gt^2*Log[MS/Q])/mu2[3, 3] + (32*g3^2*M3^2*Log[MS/Q])/
              (3*mu2[3, 3]) - (4*At^2*gt^2*Log[MS/Q])/(tb^2*mu2[3, 3]) - 
             (4*gt^2*mA^2*Log[MS/Q])/(tb^2*mu2[3, 3]) + 
             (4*gt^2*\[Mu]^2*Log[MS/Q])/mu2[3, 3] + (4*gt^2*\[Mu]^2*Log[
                MS/Q])/(tb^2*mu2[3, 3]) - (4*gt^2*Log[MS/Q]*mq2[3, 3])/
              mu2[3, 3] - (4*gt^2*Log[MS/Q]*mq2[3, 3])/(tb^2*mu2[3, 3])))/
           mu2[3, 3] + ((-32*g3^2*M3^2*Log[MS/Q])/3 + (2*gt^2*mA^2*Log[MS/Q])/
             tb^2 + (2*At^2*gt^2*(1 + tb^2)*Log[MS/Q])/tb^2 - 
            (2*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/tb^2 + 
            (2*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3])/tb^2 + 
            (2*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^2)/mu2[3, 3])^2*
        Derivative[2][TCF[1]][Sqrt[mq2[3, 3]/mu2[3, 3]]])/(8*mq2[3, 3]) + 
      (-((TCF[2][Sqrt[mq2[3, 3]/mu2[3, 3]]]*(((32*g3^2*M3*Log[MS/Q])/3 + 
              (12*At*gt^2*(1 + tb^2)*Log[MS/Q])/tb^2 - 
              (3*(10*gt^2*\[Mu]*Log[MS/Q] + 10*gt^2*tb^2*\[Mu]*Log[MS/Q]))/(5*
                tb^3))^2 + 2*(At - \[Mu]/tb)*(-64*g3^4*M3*Log[MS/Q]^2 - 
              (64*At*g3^2*gt^2*(1 + tb^2)*Log[MS/Q]^2)/tb^2 + 
              (64*g3^2*gt^2*M3*(1 + tb^2)*Log[MS/Q]^2)/tb^2 + 
              (144*At*gt^4*(1 + tb^2)^2*Log[MS/Q]^2)/tb^4 - 
              (3*gt^2*(1 + tb^2)*\[Mu]*Log[MS/Q]*(3*gt^2*Log[MS/Q] + 
                 (3*gt^2*Log[MS/Q])/tb^2))/tb^3 - (g3^4*M3*Log[MS/Q]*
                (-6 + 12*Log[M3^2/Q^2] + Log[md2[1, 1]/Q^2] + 
                 Log[md2[2, 2]/Q^2] + Log[md2[3, 3]/Q^2] + 
                 2*Log[mq2[1, 1]/Q^2] + 2*Log[mq2[2, 2]/Q^2] + 
                 2*Log[mq2[3, 3]/Q^2] + Log[mu2[1, 1]/Q^2] + 
                 Log[mu2[2, 2]/Q^2] + Log[mu2[3, 3]/Q^2]))/(9*Pi^2) + 
              (24*At*gt^2*(1 + tb^2)*Log[MS/Q]*((-4*g3^2)/3 - 
                 gt^2*((3*(-1 + 2*Log[mA^2/Q^2]))/(8*tb^2) + (3*(1 + tb^2)*
                     Log[\[Mu]^2/Q^2])/(4*tb^2) - ((At - \[Mu]/tb)^2*
                     TCF[5][Sqrt[mq2[3, 3]]/Sqrt[mu2[3, 3]]])/
                    (4*Sqrt[mq2[3, 3]*mu2[3, 3]]) + ((1 + tb^2)*TCF[6][
                      Sqrt[mq2[3, 3]]/\[Mu]])/tb^2 + ((1 + tb^2)*TCF[6][
                      Sqrt[mu2[3, 3]]/\[Mu]])/(2*tb^2)) - 
                 (4*g3^2*(Log[M3^2/Q^2] + TCF[6][Sqrt[mq2[3, 3]]/M3] + 
                    TCF[6][Sqrt[mu2[3, 3]]/M3] - ((At - \[Mu]/tb)*TCF[9][
                       Sqrt[mq2[3, 3]]/M3, Sqrt[mu2[3, 3]]/M3])/M3))/3))/tb^
                2 - (-((1 + tb^2)*(-45*gt^4 + 32*g3^2*gt^2*tb^2 - 45*gt^4*
                     tb^2)*\[Mu]*Log[MS/Q]^2)/(2*tb^4) + (6*gt^2*(1 + tb^2)*
                  \[Mu]*Log[MS/Q]*((-4*g3^2)/3 - gt^2*
                    ((3*(-1 + 2*Log[mA^2/Q^2]))/(8*tb^2) + (3*(1 + tb^2)*
                       Log[\[Mu]^2/Q^2])/(4*tb^2) - ((At - \[Mu]/tb)^2*
                       TCF[5][Sqrt[mq2[3, 3]]/Sqrt[mu2[3, 3]]])/
                      (4*Sqrt[mq2[3, 3]*mu2[3, 3]]) + ((1 + tb^2)*TCF[6][
                        Sqrt[mq2[3, 3]]/\[Mu]])/tb^2 + ((1 + tb^2)*TCF[6][
                        Sqrt[mu2[3, 3]]/\[Mu]])/(2*tb^2)) - 
                   (4*g3^2*(Log[M3^2/Q^2] + TCF[6][Sqrt[mq2[3, 3]]/M3] + 
                      TCF[6][Sqrt[mu2[3, 3]]/M3] - ((At - \[Mu]/tb)*TCF[9][
                         Sqrt[mq2[3, 3]]/M3, Sqrt[mu2[3, 3]]/M3])/M3))/3))/
                 tb^2)/tb - (\[Mu]*((-3*gt^2*(1 + tb^2)*Log[MS/Q]*
                   (-3*gt^2*Log[MS/Q] - (3*gt^2*Log[MS/Q])/tb^2))/tb^2 - 
                 (((1 + tb^2)*(-27*gt^4 + 32*g3^2*gt^2*tb^2 - 27*gt^4*tb^2)*
                     Log[MS/Q]^2)/(2*tb^3) - (6*gt^2*(1 + tb^2)*Log[MS/Q]*
                     ((-4*g3^2)/3 - gt^2*((3*(-1 + 2*Log[mA^2/Q^2]))/
                         (8*tb^2) + (3*(1 + tb^2)*Log[\[Mu]^2/Q^2])/
                         (4*tb^2) - ((At - \[Mu]/tb)^2*TCF[5][Sqrt[mq2[3, 3]]/
                          Sqrt[mu2[3, 3]]])/(4*Sqrt[mq2[3, 3]*mu2[3, 3]]) + 
                        ((1 + tb^2)*TCF[6][Sqrt[mq2[3, 3]]/\[Mu]])/tb^2 + 
                        ((1 + tb^2)*TCF[6][Sqrt[mu2[3, 3]]/\[Mu]])/
                         (2*tb^2)) - (4*g3^2*(Log[M3^2/Q^2] + TCF[6][
                          Sqrt[mq2[3, 3]]/M3] + TCF[6][Sqrt[mu2[3, 3]]/M3] - 
                         ((At - \[Mu]/tb)*TCF[9][Sqrt[mq2[3, 3]]/M3, 
                          Sqrt[mu2[3, 3]]/M3])/M3))/3))/tb)/tb))/tb)))/
          Sqrt[mq2[3, 3]*mu2[3, 3]]) - 2*(At - \[Mu]/tb)*
         ((32*g3^2*M3*Log[MS/Q])/3 + (12*At*gt^2*(1 + tb^2)*Log[MS/Q])/tb^2 - 
          (3*(10*gt^2*\[Mu]*Log[MS/Q] + 10*gt^2*tb^2*\[Mu]*Log[MS/Q]))/
           (5*tb^3))*(-((mu2[3, 3]*((-32*g3^2*M3^2*Log[MS/Q])/3 + 
                (2*gt^2*mA^2*Log[MS/Q])/tb^2 + (2*At^2*gt^2*(1 + tb^2)*
                  Log[MS/Q])/tb^2 - (2*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/
                 tb^2 + (2*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3])/tb^2 + 
                (2*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^2) + 
              mq2[3, 3]*((-32*g3^2*M3^2*Log[MS/Q])/3 + (4*gt^2*mA^2*
                  Log[MS/Q])/tb^2 + (4*At^2*gt^2*(1 + tb^2)*Log[MS/Q])/tb^2 - 
                (4*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/tb^2 + 
                (4*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3])/tb^2 + 
                (4*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^2))*
             TCF[2][Sqrt[mq2[3, 3]/mu2[3, 3]]])/(2*mq2[3, 3]*mu2[3, 3]*
            Sqrt[mq2[3, 3]*mu2[3, 3]]) + (Sqrt[mq2[3, 3]/mu2[3, 3]]*mu2[3, 3]*
            ((mq2[3, 3]*(-4*gt^2*Log[MS/Q] - (4*gt^2*Log[MS/Q])/tb^2 - 
                (4*At^2*gt^2*Log[MS/Q])/mu2[3, 3] + (32*g3^2*M3^2*Log[MS/Q])/
                 (3*mu2[3, 3]) - (4*At^2*gt^2*Log[MS/Q])/(tb^2*mu2[3, 3]) - 
                (4*gt^2*mA^2*Log[MS/Q])/(tb^2*mu2[3, 3]) + (4*gt^2*\[Mu]^2*
                  Log[MS/Q])/mu2[3, 3] + (4*gt^2*\[Mu]^2*Log[MS/Q])/
                 (tb^2*mu2[3, 3]) - (4*gt^2*Log[MS/Q]*mq2[3, 3])/mu2[3, 3] - 
                (4*gt^2*Log[MS/Q]*mq2[3, 3])/(tb^2*mu2[3, 3])))/mu2[3, 3] + 
             ((-32*g3^2*M3^2*Log[MS/Q])/3 + (2*gt^2*mA^2*Log[MS/Q])/tb^2 + 
               (2*At^2*gt^2*(1 + tb^2)*Log[MS/Q])/tb^2 - (2*gt^2*(1 + tb^2)*
                 \[Mu]^2*Log[MS/Q])/tb^2 + (2*gt^2*(1 + tb^2)*Log[MS/Q]*
                 mq2[3, 3])/tb^2 + (2*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/
                tb^2)/mu2[3, 3])*Derivative[1][TCF[2]][
             Sqrt[mq2[3, 3]/mu2[3, 3]]])/(2*mq2[3, 3]*
            Sqrt[mq2[3, 3]*mu2[3, 3]])) - (At - \[Mu]/tb)^2*
         ((TCF[2][Sqrt[mq2[3, 3]/mu2[3, 3]]]*
            ((3*(mu2[3, 3]*((-32*g3^2*M3^2*Log[MS/Q])/3 + (2*gt^2*mA^2*
                     Log[MS/Q])/tb^2 + (2*At^2*gt^2*(1 + tb^2)*Log[MS/Q])/
                    tb^2 - (2*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/tb^2 + 
                   (2*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3])/tb^2 + 
                   (2*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^2) + 
                 mq2[3, 3]*((-32*g3^2*M3^2*Log[MS/Q])/3 + (4*gt^2*mA^2*
                     Log[MS/Q])/tb^2 + (4*At^2*gt^2*(1 + tb^2)*Log[MS/Q])/
                    tb^2 - (4*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/tb^2 + 
                   (4*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3])/tb^2 + 
                   (4*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^2))^2)/
              (4*mq2[3, 3]^2*mu2[3, 3]^2) - (((-32*g3^2*M3^2*Log[MS/Q])/3 + 
                 (2*gt^2*mA^2*Log[MS/Q])/tb^2 + (2*At^2*gt^2*(1 + tb^2)*
                   Log[MS/Q])/tb^2 - (2*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/
                  tb^2 + (2*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3])/tb^2 + 
                 (2*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^2)*
                ((-32*g3^2*M3^2*Log[MS/Q])/3 + (4*gt^2*mA^2*Log[MS/Q])/tb^2 + 
                 (4*At^2*gt^2*(1 + tb^2)*Log[MS/Q])/tb^2 - (4*gt^2*(1 + tb^2)*
                   \[Mu]^2*Log[MS/Q])/tb^2 + (4*gt^2*(1 + tb^2)*Log[MS/Q]*
                   mq2[3, 3])/tb^2 + (4*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/
                  tb^2) + mu2[3, 3]*(96*g3^4*M3^2*Log[MS/Q]^2 - 
                 (32*g3^2*gt^2*mA^2*Log[MS/Q]^2)/(3*tb^2) + (6*gt^4*mA^2*
                   Log[MS/Q]^2)/tb^2 + (18*gt^4*mA^2*(1 + tb^2)*Log[MS/Q]^2)/
                  tb^4 - (32*At^2*g3^2*gt^2*(1 + tb^2)*Log[MS/Q]^2)/
                  (3*tb^2) + (64*At*g3^2*gt^2*M3*(1 + tb^2)*Log[MS/Q]^2)/
                  (3*tb^2) - (64*g3^2*gt^2*M3^2*(1 + tb^2)*Log[MS/Q]^2)/
                  (3*tb^2) + (42*At^2*gt^4*(1 + tb^2)^2*Log[MS/Q]^2)/tb^4 + 
                 (32*g3^2*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q]^2)/(3*tb^2) - 
                 (24*gt^4*(1 + tb^2)^2*\[Mu]^2*Log[MS/Q]^2)/tb^4 + 
                 (g3^4*M3^2*Log[MS/Q]*(-6 + 12*Log[M3^2/Q^2] + Log[md2[1, 1]/
                      Q^2] + Log[md2[2, 2]/Q^2] + Log[md2[3, 3]/Q^2] + 
                    2*Log[mq2[1, 1]/Q^2] + 2*Log[mq2[2, 2]/Q^2] + 
                    2*Log[mq2[3, 3]/Q^2] + Log[mu2[1, 1]/Q^2] + 
                    Log[mu2[2, 2]/Q^2] + Log[mu2[3, 3]/Q^2]))/(9*Pi^2) - 
                 (32*g3^2*gt^2*(1 + tb^2)*Log[MS/Q]^2*mq2[3, 3])/(3*tb^2) + 
                 (18*gt^4*(1 + tb^2)^2*Log[MS/Q]^2*mq2[3, 3])/tb^4 - 
                 (32*g3^2*gt^2*(1 + tb^2)*Log[MS/Q]^2*mu2[3, 3])/(3*tb^2) + 
                 (18*gt^4*(1 + tb^2)^2*Log[MS/Q]^2*mu2[3, 3])/tb^4 + 
                 (4*gt^2*mA^2*Log[MS/Q]*((-4*g3^2)/3 - gt^2*
                     ((3*(-1 + 2*Log[mA^2/Q^2]))/(8*tb^2) + (3*(1 + tb^2)*
                        Log[\[Mu]^2/Q^2])/(4*tb^2) - ((At - \[Mu]/tb)^2*
                        TCF[5][Sqrt[mq2[3, 3]]/Sqrt[mu2[3, 3]]])/
                       (4*Sqrt[mq2[3, 3]*mu2[3, 3]]) + ((1 + tb^2)*TCF[6][
                         Sqrt[mq2[3, 3]]/\[Mu]])/tb^2 + ((1 + tb^2)*TCF[6][
                         Sqrt[mu2[3, 3]]/\[Mu]])/(2*tb^2)) - 
                    (4*g3^2*(Log[M3^2/Q^2] + TCF[6][Sqrt[mq2[3, 3]]/M3] + 
                       TCF[6][Sqrt[mu2[3, 3]]/M3] - ((At - \[Mu]/tb)*TCF[9][
                          Sqrt[mq2[3, 3]]/M3, Sqrt[mu2[3, 3]]/M3])/M3))/3))/
                  tb^2 + (4*At^2*gt^2*(1 + tb^2)*Log[MS/Q]*((-4*g3^2)/3 - 
                    gt^2*((3*(-1 + 2*Log[mA^2/Q^2]))/(8*tb^2) + (3*(1 + tb^2)*
                        Log[\[Mu]^2/Q^2])/(4*tb^2) - ((At - \[Mu]/tb)^2*
                        TCF[5][Sqrt[mq2[3, 3]]/Sqrt[mu2[3, 3]]])/
                       (4*Sqrt[mq2[3, 3]*mu2[3, 3]]) + ((1 + tb^2)*TCF[6][
                         Sqrt[mq2[3, 3]]/\[Mu]])/tb^2 + ((1 + tb^2)*TCF[6][
                         Sqrt[mu2[3, 3]]/\[Mu]])/(2*tb^2)) - 
                    (4*g3^2*(Log[M3^2/Q^2] + TCF[6][Sqrt[mq2[3, 3]]/M3] + 
                       TCF[6][Sqrt[mu2[3, 3]]/M3] - ((At - \[Mu]/tb)*TCF[9][
                          Sqrt[mq2[3, 3]]/M3, Sqrt[mu2[3, 3]]/M3])/M3))/3))/
                  tb^2 - (4*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q]*((-4*g3^2)/3 - 
                    gt^2*((3*(-1 + 2*Log[mA^2/Q^2]))/(8*tb^2) + (3*(1 + tb^2)*
                        Log[\[Mu]^2/Q^2])/(4*tb^2) - ((At - \[Mu]/tb)^2*
                        TCF[5][Sqrt[mq2[3, 3]]/Sqrt[mu2[3, 3]]])/
                       (4*Sqrt[mq2[3, 3]*mu2[3, 3]]) + ((1 + tb^2)*TCF[6][
                         Sqrt[mq2[3, 3]]/\[Mu]])/tb^2 + ((1 + tb^2)*TCF[6][
                         Sqrt[mu2[3, 3]]/\[Mu]])/(2*tb^2)) - 
                    (4*g3^2*(Log[M3^2/Q^2] + TCF[6][Sqrt[mq2[3, 3]]/M3] + 
                       TCF[6][Sqrt[mu2[3, 3]]/M3] - ((At - \[Mu]/tb)*TCF[9][
                          Sqrt[mq2[3, 3]]/M3, Sqrt[mu2[3, 3]]/M3])/M3))/3))/
                  tb^2 + (4*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3]*
                   ((-4*g3^2)/3 - gt^2*((3*(-1 + 2*Log[mA^2/Q^2]))/(8*tb^2) + 
                      (3*(1 + tb^2)*Log[\[Mu]^2/Q^2])/(4*tb^2) - 
                      ((At - \[Mu]/tb)^2*TCF[5][Sqrt[mq2[3, 3]]/Sqrt[mu2[3, 
                          3]]])/(4*Sqrt[mq2[3, 3]*mu2[3, 3]]) + ((1 + tb^2)*
                        TCF[6][Sqrt[mq2[3, 3]]/\[Mu]])/tb^2 + ((1 + tb^2)*
                        TCF[6][Sqrt[mu2[3, 3]]/\[Mu]])/(2*tb^2)) - 
                    (4*g3^2*(Log[M3^2/Q^2] + TCF[6][Sqrt[mq2[3, 3]]/M3] + 
                       TCF[6][Sqrt[mu2[3, 3]]/M3] - ((At - \[Mu]/tb)*TCF[9][
                          Sqrt[mq2[3, 3]]/M3, Sqrt[mu2[3, 3]]/M3])/M3))/3))/
                  tb^2 + (4*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3]*
                   ((-4*g3^2)/3 - gt^2*((3*(-1 + 2*Log[mA^2/Q^2]))/(8*tb^2) + 
                      (3*(1 + tb^2)*Log[\[Mu]^2/Q^2])/(4*tb^2) - 
                      ((At - \[Mu]/tb)^2*TCF[5][Sqrt[mq2[3, 3]]/Sqrt[mu2[3, 
                          3]]])/(4*Sqrt[mq2[3, 3]*mu2[3, 3]]) + ((1 + tb^2)*
                        TCF[6][Sqrt[mq2[3, 3]]/\[Mu]])/tb^2 + ((1 + tb^2)*
                        TCF[6][Sqrt[mu2[3, 3]]/\[Mu]])/(2*tb^2)) - 
                    (4*g3^2*(Log[M3^2/Q^2] + TCF[6][Sqrt[mq2[3, 3]]/M3] + 
                       TCF[6][Sqrt[mu2[3, 3]]/M3] - ((At - \[Mu]/tb)*TCF[9][
                          Sqrt[mq2[3, 3]]/M3, Sqrt[mu2[3, 3]]/M3])/M3))/3))/
                  tb^2) + mq2[3, 3]*(96*g3^4*M3^2*Log[MS/Q]^2 - 
                 (64*g3^2*gt^2*mA^2*Log[MS/Q]^2)/(3*tb^2) + (12*gt^4*mA^2*
                   Log[MS/Q]^2)/tb^2 + (36*gt^4*mA^2*(1 + tb^2)*Log[MS/Q]^2)/
                  tb^4 - (64*At^2*g3^2*gt^2*(1 + tb^2)*Log[MS/Q]^2)/
                  (3*tb^2) + (128*At*g3^2*gt^2*M3*(1 + tb^2)*Log[MS/Q]^2)/
                  (3*tb^2) - (128*g3^2*gt^2*M3^2*(1 + tb^2)*Log[MS/Q]^2)/
                  (3*tb^2) + (84*At^2*gt^4*(1 + tb^2)^2*Log[MS/Q]^2)/tb^4 + 
                 (64*g3^2*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q]^2)/(3*tb^2) - 
                 (48*gt^4*(1 + tb^2)^2*\[Mu]^2*Log[MS/Q]^2)/tb^4 + 
                 (g3^4*M3^2*Log[MS/Q]*(-6 + 12*Log[M3^2/Q^2] + Log[md2[1, 1]/
                      Q^2] + Log[md2[2, 2]/Q^2] + Log[md2[3, 3]/Q^2] + 
                    2*Log[mq2[1, 1]/Q^2] + 2*Log[mq2[2, 2]/Q^2] + 
                    2*Log[mq2[3, 3]/Q^2] + Log[mu2[1, 1]/Q^2] + 
                    Log[mu2[2, 2]/Q^2] + Log[mu2[3, 3]/Q^2]))/(9*Pi^2) - 
                 (64*g3^2*gt^2*(1 + tb^2)*Log[MS/Q]^2*mq2[3, 3])/(3*tb^2) + 
                 (36*gt^4*(1 + tb^2)^2*Log[MS/Q]^2*mq2[3, 3])/tb^4 - 
                 (64*g3^2*gt^2*(1 + tb^2)*Log[MS/Q]^2*mu2[3, 3])/(3*tb^2) + 
                 (36*gt^4*(1 + tb^2)^2*Log[MS/Q]^2*mu2[3, 3])/tb^4 + 
                 (8*gt^2*mA^2*Log[MS/Q]*((-4*g3^2)/3 - gt^2*
                     ((3*(-1 + 2*Log[mA^2/Q^2]))/(8*tb^2) + (3*(1 + tb^2)*
                        Log[\[Mu]^2/Q^2])/(4*tb^2) - ((At - \[Mu]/tb)^2*
                        TCF[5][Sqrt[mq2[3, 3]]/Sqrt[mu2[3, 3]]])/
                       (4*Sqrt[mq2[3, 3]*mu2[3, 3]]) + ((1 + tb^2)*TCF[6][
                         Sqrt[mq2[3, 3]]/\[Mu]])/tb^2 + ((1 + tb^2)*TCF[6][
                         Sqrt[mu2[3, 3]]/\[Mu]])/(2*tb^2)) - 
                    (4*g3^2*(Log[M3^2/Q^2] + TCF[6][Sqrt[mq2[3, 3]]/M3] + 
                       TCF[6][Sqrt[mu2[3, 3]]/M3] - ((At - \[Mu]/tb)*TCF[9][
                          Sqrt[mq2[3, 3]]/M3, Sqrt[mu2[3, 3]]/M3])/M3))/3))/
                  tb^2 + (8*At^2*gt^2*(1 + tb^2)*Log[MS/Q]*((-4*g3^2)/3 - 
                    gt^2*((3*(-1 + 2*Log[mA^2/Q^2]))/(8*tb^2) + (3*(1 + tb^2)*
                        Log[\[Mu]^2/Q^2])/(4*tb^2) - ((At - \[Mu]/tb)^2*
                        TCF[5][Sqrt[mq2[3, 3]]/Sqrt[mu2[3, 3]]])/
                       (4*Sqrt[mq2[3, 3]*mu2[3, 3]]) + ((1 + tb^2)*TCF[6][
                         Sqrt[mq2[3, 3]]/\[Mu]])/tb^2 + ((1 + tb^2)*TCF[6][
                         Sqrt[mu2[3, 3]]/\[Mu]])/(2*tb^2)) - 
                    (4*g3^2*(Log[M3^2/Q^2] + TCF[6][Sqrt[mq2[3, 3]]/M3] + 
                       TCF[6][Sqrt[mu2[3, 3]]/M3] - ((At - \[Mu]/tb)*TCF[9][
                          Sqrt[mq2[3, 3]]/M3, Sqrt[mu2[3, 3]]/M3])/M3))/3))/
                  tb^2 - (8*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q]*((-4*g3^2)/3 - 
                    gt^2*((3*(-1 + 2*Log[mA^2/Q^2]))/(8*tb^2) + (3*(1 + tb^2)*
                        Log[\[Mu]^2/Q^2])/(4*tb^2) - ((At - \[Mu]/tb)^2*
                        TCF[5][Sqrt[mq2[3, 3]]/Sqrt[mu2[3, 3]]])/
                       (4*Sqrt[mq2[3, 3]*mu2[3, 3]]) + ((1 + tb^2)*TCF[6][
                         Sqrt[mq2[3, 3]]/\[Mu]])/tb^2 + ((1 + tb^2)*TCF[6][
                         Sqrt[mu2[3, 3]]/\[Mu]])/(2*tb^2)) - 
                    (4*g3^2*(Log[M3^2/Q^2] + TCF[6][Sqrt[mq2[3, 3]]/M3] + 
                       TCF[6][Sqrt[mu2[3, 3]]/M3] - ((At - \[Mu]/tb)*TCF[9][
                          Sqrt[mq2[3, 3]]/M3, Sqrt[mu2[3, 3]]/M3])/M3))/3))/
                  tb^2 + (8*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3]*
                   ((-4*g3^2)/3 - gt^2*((3*(-1 + 2*Log[mA^2/Q^2]))/(8*tb^2) + 
                      (3*(1 + tb^2)*Log[\[Mu]^2/Q^2])/(4*tb^2) - 
                      ((At - \[Mu]/tb)^2*TCF[5][Sqrt[mq2[3, 3]]/Sqrt[mu2[3, 
                          3]]])/(4*Sqrt[mq2[3, 3]*mu2[3, 3]]) + ((1 + tb^2)*
                        TCF[6][Sqrt[mq2[3, 3]]/\[Mu]])/tb^2 + ((1 + tb^2)*
                        TCF[6][Sqrt[mu2[3, 3]]/\[Mu]])/(2*tb^2)) - 
                    (4*g3^2*(Log[M3^2/Q^2] + TCF[6][Sqrt[mq2[3, 3]]/M3] + 
                       TCF[6][Sqrt[mu2[3, 3]]/M3] - ((At - \[Mu]/tb)*TCF[9][
                          Sqrt[mq2[3, 3]]/M3, Sqrt[mu2[3, 3]]/M3])/M3))/3))/
                  tb^2 + (8*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3]*
                   ((-4*g3^2)/3 - gt^2*((3*(-1 + 2*Log[mA^2/Q^2]))/(8*tb^2) + 
                      (3*(1 + tb^2)*Log[\[Mu]^2/Q^2])/(4*tb^2) - 
                      ((At - \[Mu]/tb)^2*TCF[5][Sqrt[mq2[3, 3]]/Sqrt[mu2[3, 
                          3]]])/(4*Sqrt[mq2[3, 3]*mu2[3, 3]]) + ((1 + tb^2)*
                        TCF[6][Sqrt[mq2[3, 3]]/\[Mu]])/tb^2 + ((1 + tb^2)*
                        TCF[6][Sqrt[mu2[3, 3]]/\[Mu]])/(2*tb^2)) - 
                    (4*g3^2*(Log[M3^2/Q^2] + TCF[6][Sqrt[mq2[3, 3]]/M3] + 
                       TCF[6][Sqrt[mu2[3, 3]]/M3] - ((At - \[Mu]/tb)*TCF[9][
                          Sqrt[mq2[3, 3]]/M3, Sqrt[mu2[3, 3]]/M3])/M3))/3))/
                  tb^2))/(mq2[3, 3]*mu2[3, 3])))/
           (2*Sqrt[mq2[3, 3]*mu2[3, 3]]) - (Sqrt[mq2[3, 3]/mu2[3, 3]]*
            ((mq2[3, 3]*(-4*gt^2*Log[MS/Q] - (4*gt^2*Log[MS/Q])/tb^2 - 
                (4*At^2*gt^2*Log[MS/Q])/mu2[3, 3] + (32*g3^2*M3^2*Log[MS/Q])/
                 (3*mu2[3, 3]) - (4*At^2*gt^2*Log[MS/Q])/(tb^2*mu2[3, 3]) - 
                (4*gt^2*mA^2*Log[MS/Q])/(tb^2*mu2[3, 3]) + (4*gt^2*\[Mu]^2*
                  Log[MS/Q])/mu2[3, 3] + (4*gt^2*\[Mu]^2*Log[MS/Q])/
                 (tb^2*mu2[3, 3]) - (4*gt^2*Log[MS/Q]*mq2[3, 3])/mu2[3, 3] - 
                (4*gt^2*Log[MS/Q]*mq2[3, 3])/(tb^2*mu2[3, 3])))/mu2[3, 3] + 
             ((-32*g3^2*M3^2*Log[MS/Q])/3 + (2*gt^2*mA^2*Log[MS/Q])/tb^2 + 
               (2*At^2*gt^2*(1 + tb^2)*Log[MS/Q])/tb^2 - (2*gt^2*(1 + tb^2)*
                 \[Mu]^2*Log[MS/Q])/tb^2 + (2*gt^2*(1 + tb^2)*Log[MS/Q]*
                 mq2[3, 3])/tb^2 + (2*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/
                tb^2)/mu2[3, 3])*(mu2[3, 3]*((-32*g3^2*M3^2*Log[MS/Q])/3 + 
               (2*gt^2*mA^2*Log[MS/Q])/tb^2 + (2*At^2*gt^2*(1 + tb^2)*
                 Log[MS/Q])/tb^2 - (2*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/
                tb^2 + (2*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3])/tb^2 + 
               (2*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^2) + 
             mq2[3, 3]*((-32*g3^2*M3^2*Log[MS/Q])/3 + (4*gt^2*mA^2*Log[MS/Q])/
                tb^2 + (4*At^2*gt^2*(1 + tb^2)*Log[MS/Q])/tb^2 - 
               (4*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/tb^2 + (4*gt^2*
                 (1 + tb^2)*Log[MS/Q]*mq2[3, 3])/tb^2 + (4*gt^2*(1 + tb^2)*
                 Log[MS/Q]*mu2[3, 3])/tb^2))*Derivative[1][TCF[2]][
             Sqrt[mq2[3, 3]/mu2[3, 3]]])/(4*mq2[3, 3]^2*
            Sqrt[mq2[3, 3]*mu2[3, 3]]) + 
          ((Sqrt[mq2[3, 3]/mu2[3, 3]]*(-(mu2[3, 3]^2*
                  ((mq2[3, 3]*(-4*gt^2*Log[MS/Q] - (4*gt^2*Log[MS/Q])/tb^2 - 
                       (4*At^2*gt^2*Log[MS/Q])/mu2[3, 3] + (32*g3^2*M3^2*
                         Log[MS/Q])/(3*mu2[3, 3]) - (4*At^2*gt^2*Log[MS/Q])/
                        (tb^2*mu2[3, 3]) - (4*gt^2*mA^2*Log[MS/Q])/(tb^2*
                         mu2[3, 3]) + (4*gt^2*\[Mu]^2*Log[MS/Q])/mu2[3, 3] + 
                       (4*gt^2*\[Mu]^2*Log[MS/Q])/(tb^2*mu2[3, 3]) - 
                       (4*gt^2*Log[MS/Q]*mq2[3, 3])/mu2[3, 3] - 
                       (4*gt^2*Log[MS/Q]*mq2[3, 3])/(tb^2*mu2[3, 3])))/
                     mu2[3, 3] + ((-32*g3^2*M3^2*Log[MS/Q])/3 + (2*gt^2*mA^2*
                        Log[MS/Q])/tb^2 + (2*At^2*gt^2*(1 + tb^2)*Log[MS/Q])/
                       tb^2 - (2*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/tb^2 + 
                      (2*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3])/tb^2 + 
                      (2*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^2)/
                     mu2[3, 3])^2)/(4*mq2[3, 3]^2) + (mu2[3, 3]*
                 (((-4*gt^2*Log[MS/Q] - (4*gt^2*Log[MS/Q])/tb^2 - 
                     (4*At^2*gt^2*Log[MS/Q])/mu2[3, 3] + (32*g3^2*M3^2*
                       Log[MS/Q])/(3*mu2[3, 3]) - (4*At^2*gt^2*Log[MS/Q])/
                      (tb^2*mu2[3, 3]) - (4*gt^2*mA^2*Log[MS/Q])/(tb^2*
                       mu2[3, 3]) + (4*gt^2*\[Mu]^2*Log[MS/Q])/mu2[3, 3] + 
                     (4*gt^2*\[Mu]^2*Log[MS/Q])/(tb^2*mu2[3, 3]) - 
                     (4*gt^2*Log[MS/Q]*mq2[3, 3])/mu2[3, 3] - 
                     (4*gt^2*Log[MS/Q]*mq2[3, 3])/(tb^2*mu2[3, 3]))*
                    ((-32*g3^2*M3^2*Log[MS/Q])/3 + (2*gt^2*mA^2*Log[MS/Q])/
                      tb^2 + (2*At^2*gt^2*(1 + tb^2)*Log[MS/Q])/tb^2 - 
                     (2*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/tb^2 + 
                     (2*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3])/tb^2 + 
                     (2*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^2))/
                   mu2[3, 3] + (96*g3^4*M3^2*Log[MS/Q]^2 - (32*g3^2*gt^2*mA^2*
                      Log[MS/Q]^2)/(3*tb^2) + (6*gt^4*mA^2*Log[MS/Q]^2)/
                     tb^2 + (18*gt^4*mA^2*(1 + tb^2)*Log[MS/Q]^2)/tb^4 - 
                    (32*At^2*g3^2*gt^2*(1 + tb^2)*Log[MS/Q]^2)/(3*tb^2) + 
                    (64*At*g3^2*gt^2*M3*(1 + tb^2)*Log[MS/Q]^2)/(3*tb^2) - 
                    (64*g3^2*gt^2*M3^2*(1 + tb^2)*Log[MS/Q]^2)/(3*tb^2) + 
                    (42*At^2*gt^4*(1 + tb^2)^2*Log[MS/Q]^2)/tb^4 + 
                    (32*g3^2*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q]^2)/(3*tb^2) - 
                    (24*gt^4*(1 + tb^2)^2*\[Mu]^2*Log[MS/Q]^2)/tb^4 + 
                    (g3^4*M3^2*Log[MS/Q]*(-6 + 12*Log[M3^2/Q^2] + 
                       Log[md2[1, 1]/Q^2] + Log[md2[2, 2]/Q^2] + Log[
                        md2[3, 3]/Q^2] + 2*Log[mq2[1, 1]/Q^2] + 
                       2*Log[mq2[2, 2]/Q^2] + 2*Log[mq2[3, 3]/Q^2] + 
                       Log[mu2[1, 1]/Q^2] + Log[mu2[2, 2]/Q^2] + Log[
                        mu2[3, 3]/Q^2]))/(9*Pi^2) - (32*g3^2*gt^2*(1 + tb^2)*
                      Log[MS/Q]^2*mq2[3, 3])/(3*tb^2) + (18*gt^4*(1 + tb^2)^2*
                      Log[MS/Q]^2*mq2[3, 3])/tb^4 - (32*g3^2*gt^2*(1 + tb^2)*
                      Log[MS/Q]^2*mu2[3, 3])/(3*tb^2) + (18*gt^4*(1 + tb^2)^2*
                      Log[MS/Q]^2*mu2[3, 3])/tb^4 + (4*gt^2*mA^2*Log[MS/Q]*
                      ((-4*g3^2)/3 - gt^2*((3*(-1 + 2*Log[mA^2/Q^2]))/
                          (8*tb^2) + (3*(1 + tb^2)*Log[\[Mu]^2/Q^2])/
                          (4*tb^2) - ((At - \[Mu]/tb)^2*TCF[5][Sqrt[mq2[3, 
                          3]]/Sqrt[mu2[3, 3]]])/(4*Sqrt[mq2[3, 3]*mu2[3, 
                          3]]) + ((1 + tb^2)*TCF[6][Sqrt[mq2[3, 3]]/\[Mu]])/
                          tb^2 + ((1 + tb^2)*TCF[6][Sqrt[mu2[3, 3]]/\[Mu]])/
                          (2*tb^2)) - (4*g3^2*(Log[M3^2/Q^2] + TCF[6][
                          Sqrt[mq2[3, 3]]/M3] + TCF[6][Sqrt[mu2[3, 3]]/M3] - 
                          ((At - \[Mu]/tb)*TCF[9][Sqrt[mq2[3, 3]]/M3, 
                          Sqrt[mu2[3, 3]]/M3])/M3))/3))/tb^2 + (4*At^2*gt^2*
                      (1 + tb^2)*Log[MS/Q]*((-4*g3^2)/3 - gt^2*
                        ((3*(-1 + 2*Log[mA^2/Q^2]))/(8*tb^2) + (3*(1 + tb^2)*
                          Log[\[Mu]^2/Q^2])/(4*tb^2) - ((At - \[Mu]/tb)^2*
                          TCF[5][Sqrt[mq2[3, 3]]/Sqrt[mu2[3, 3]]])/
                          (4*Sqrt[mq2[3, 3]*mu2[3, 3]]) + ((1 + tb^2)*TCF[6][
                          Sqrt[mq2[3, 3]]/\[Mu]])/tb^2 + ((1 + tb^2)*TCF[6][
                          Sqrt[mu2[3, 3]]/\[Mu]])/(2*tb^2)) - (4*g3^2*
                         (Log[M3^2/Q^2] + TCF[6][Sqrt[mq2[3, 3]]/M3] + 
                          TCF[6][Sqrt[mu2[3, 3]]/M3] - ((At - \[Mu]/tb)*
                          TCF[9][Sqrt[mq2[3, 3]]/M3, Sqrt[mu2[3, 3]]/M3])/
                          M3))/3))/tb^2 - (4*gt^2*(1 + tb^2)*\[Mu]^2*
                      Log[MS/Q]*((-4*g3^2)/3 - gt^2*((3*(-1 + 2*Log[mA^2/
                          Q^2]))/(8*tb^2) + (3*(1 + tb^2)*Log[\[Mu]^2/Q^2])/
                          (4*tb^2) - ((At - \[Mu]/tb)^2*TCF[5][Sqrt[mq2[3, 
                          3]]/Sqrt[mu2[3, 3]]])/(4*Sqrt[mq2[3, 3]*mu2[3, 
                          3]]) + ((1 + tb^2)*TCF[6][Sqrt[mq2[3, 3]]/\[Mu]])/
                          tb^2 + ((1 + tb^2)*TCF[6][Sqrt[mu2[3, 3]]/\[Mu]])/
                          (2*tb^2)) - (4*g3^2*(Log[M3^2/Q^2] + TCF[6][
                          Sqrt[mq2[3, 3]]/M3] + TCF[6][Sqrt[mu2[3, 3]]/M3] - 
                          ((At - \[Mu]/tb)*TCF[9][Sqrt[mq2[3, 3]]/M3, 
                          Sqrt[mu2[3, 3]]/M3])/M3))/3))/tb^2 + 
                    (4*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3]*((-4*g3^2)/3 - 
                       gt^2*((3*(-1 + 2*Log[mA^2/Q^2]))/(8*tb^2) + 
                         (3*(1 + tb^2)*Log[\[Mu]^2/Q^2])/(4*tb^2) - 
                         ((At - \[Mu]/tb)^2*TCF[5][Sqrt[mq2[3, 3]]/Sqrt[
                          mu2[3, 3]]])/(4*Sqrt[mq2[3, 3]*mu2[3, 3]]) + 
                         ((1 + tb^2)*TCF[6][Sqrt[mq2[3, 3]]/\[Mu]])/tb^2 + 
                         ((1 + tb^2)*TCF[6][Sqrt[mu2[3, 3]]/\[Mu]])/
                          (2*tb^2)) - (4*g3^2*(Log[M3^2/Q^2] + TCF[6][
                          Sqrt[mq2[3, 3]]/M3] + TCF[6][Sqrt[mu2[3, 3]]/M3] - 
                          ((At - \[Mu]/tb)*TCF[9][Sqrt[mq2[3, 3]]/M3, 
                          Sqrt[mu2[3, 3]]/M3])/M3))/3))/tb^2 + 
                    (4*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3]*((-4*g3^2)/3 - 
                       gt^2*((3*(-1 + 2*Log[mA^2/Q^2]))/(8*tb^2) + 
                         (3*(1 + tb^2)*Log[\[Mu]^2/Q^2])/(4*tb^2) - 
                         ((At - \[Mu]/tb)^2*TCF[5][Sqrt[mq2[3, 3]]/Sqrt[
                          mu2[3, 3]]])/(4*Sqrt[mq2[3, 3]*mu2[3, 3]]) + 
                         ((1 + tb^2)*TCF[6][Sqrt[mq2[3, 3]]/\[Mu]])/tb^2 + 
                         ((1 + tb^2)*TCF[6][Sqrt[mu2[3, 3]]/\[Mu]])/
                          (2*tb^2)) - (4*g3^2*(Log[M3^2/Q^2] + TCF[6][
                          Sqrt[mq2[3, 3]]/M3] + TCF[6][Sqrt[mu2[3, 3]]/M3] - 
                          ((At - \[Mu]/tb)*TCF[9][Sqrt[mq2[3, 3]]/M3, 
                          Sqrt[mu2[3, 3]]/M3])/M3))/3))/tb^2)/mu2[3, 3] + 
                  (mq2[3, 3]*(((4*gt^2*Log[MS/Q] + (4*gt^2*Log[MS/Q])/tb^2 + 
                        (4*At^2*gt^2*Log[MS/Q])/mu2[3, 3] - (32*g3^2*M3^2*
                          Log[MS/Q])/(3*mu2[3, 3]) + (4*At^2*gt^2*Log[MS/Q])/
                         (tb^2*mu2[3, 3]) + (4*gt^2*mA^2*Log[MS/Q])/(tb^2*
                          mu2[3, 3]) - (4*gt^2*\[Mu]^2*Log[MS/Q])/mu2[3, 3] - 
                        (4*gt^2*\[Mu]^2*Log[MS/Q])/(tb^2*mu2[3, 3]) + 
                        (4*gt^2*Log[MS/Q]*mq2[3, 3])/mu2[3, 3] + 
                        (4*gt^2*Log[MS/Q]*mq2[3, 3])/(tb^2*mu2[3, 3]))*
                       ((-32*g3^2*M3^2*Log[MS/Q])/3 + (4*gt^2*mA^2*Log[MS/Q])/
                         tb^2 + (4*At^2*gt^2*(1 + tb^2)*Log[MS/Q])/tb^2 - 
                        (4*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/tb^2 + 
                        (4*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3])/tb^2 + 
                        (4*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^2))/
                      mu2[3, 3] - (96*g3^4*M3^2*Log[MS/Q]^2 - (64*g3^2*gt^2*
                         mA^2*Log[MS/Q]^2)/(3*tb^2) + (12*gt^4*mA^2*Log[MS/Q]^
                          2)/tb^2 + (36*gt^4*mA^2*(1 + tb^2)*Log[MS/Q]^2)/
                        tb^4 - (64*At^2*g3^2*gt^2*(1 + tb^2)*Log[MS/Q]^2)/
                        (3*tb^2) + (128*At*g3^2*gt^2*M3*(1 + tb^2)*Log[MS/Q]^
                          2)/(3*tb^2) - (128*g3^2*gt^2*M3^2*(1 + tb^2)*
                         Log[MS/Q]^2)/(3*tb^2) + (84*At^2*gt^4*(1 + tb^2)^2*
                         Log[MS/Q]^2)/tb^4 + (64*g3^2*gt^2*(1 + tb^2)*\[Mu]^2*
                         Log[MS/Q]^2)/(3*tb^2) - (48*gt^4*(1 + tb^2)^2*
                         \[Mu]^2*Log[MS/Q]^2)/tb^4 + (g3^4*M3^2*Log[MS/Q]*
                         (-6 + 12*Log[M3^2/Q^2] + Log[md2[1, 1]/Q^2] + 
                          Log[md2[2, 2]/Q^2] + Log[md2[3, 3]/Q^2] + 
                          2*Log[mq2[1, 1]/Q^2] + 2*Log[mq2[2, 2]/Q^2] + 
                          2*Log[mq2[3, 3]/Q^2] + Log[mu2[1, 1]/Q^2] + 
                          Log[mu2[2, 2]/Q^2] + Log[mu2[3, 3]/Q^2]))/
                        (9*Pi^2) - (64*g3^2*gt^2*(1 + tb^2)*Log[MS/Q]^2*
                         mq2[3, 3])/(3*tb^2) + (36*gt^4*(1 + tb^2)^2*
                         Log[MS/Q]^2*mq2[3, 3])/tb^4 - (64*g3^2*gt^2*
                         (1 + tb^2)*Log[MS/Q]^2*mu2[3, 3])/(3*tb^2) + 
                       (36*gt^4*(1 + tb^2)^2*Log[MS/Q]^2*mu2[3, 3])/tb^4 + 
                       (8*gt^2*mA^2*Log[MS/Q]*((-4*g3^2)/3 - gt^2*
                          ((3*(-1 + 2*Log[mA^2/Q^2]))/(8*tb^2) + 
                          (3*(1 + tb^2)*Log[\[Mu]^2/Q^2])/(4*tb^2) - 
                          ((At - \[Mu]/tb)^2*TCF[5][Sqrt[mq2[3, 3]]/Sqrt[
                          mu2[3, 3]]])/(4*Sqrt[mq2[3, 3]*mu2[3, 3]]) + 
                          ((1 + tb^2)*TCF[6][Sqrt[mq2[3, 3]]/\[Mu]])/tb^2 + 
                          ((1 + tb^2)*TCF[6][Sqrt[mu2[3, 3]]/\[Mu]])/
                          (2*tb^2)) - (4*g3^2*(Log[M3^2/Q^2] + TCF[6][
                          Sqrt[mq2[3, 3]]/M3] + TCF[6][Sqrt[mu2[3, 3]]/M3] - 
                          ((At - \[Mu]/tb)*TCF[9][Sqrt[mq2[3, 3]]/M3, 
                          Sqrt[mu2[3, 3]]/M3])/M3))/3))/tb^2 + (8*At^2*gt^2*
                         (1 + tb^2)*Log[MS/Q]*((-4*g3^2)/3 - gt^2*
                          ((3*(-1 + 2*Log[mA^2/Q^2]))/(8*tb^2) + 
                          (3*(1 + tb^2)*Log[\[Mu]^2/Q^2])/(4*tb^2) - 
                          ((At - \[Mu]/tb)^2*TCF[5][Sqrt[mq2[3, 3]]/Sqrt[
                          mu2[3, 3]]])/(4*Sqrt[mq2[3, 3]*mu2[3, 3]]) + 
                          ((1 + tb^2)*TCF[6][Sqrt[mq2[3, 3]]/\[Mu]])/tb^2 + 
                          ((1 + tb^2)*TCF[6][Sqrt[mu2[3, 3]]/\[Mu]])/
                          (2*tb^2)) - (4*g3^2*(Log[M3^2/Q^2] + TCF[6][
                          Sqrt[mq2[3, 3]]/M3] + TCF[6][Sqrt[mu2[3, 3]]/M3] - 
                          ((At - \[Mu]/tb)*TCF[9][Sqrt[mq2[3, 3]]/M3, 
                          Sqrt[mu2[3, 3]]/M3])/M3))/3))/tb^2 - (8*gt^2*
                         (1 + tb^2)*\[Mu]^2*Log[MS/Q]*((-4*g3^2)/3 - 
                          gt^2*((3*(-1 + 2*Log[mA^2/Q^2]))/(8*tb^2) + 
                          (3*(1 + tb^2)*Log[\[Mu]^2/Q^2])/(4*tb^2) - 
                          ((At - \[Mu]/tb)^2*TCF[5][Sqrt[mq2[3, 3]]/Sqrt[
                          mu2[3, 3]]])/(4*Sqrt[mq2[3, 3]*mu2[3, 3]]) + 
                          ((1 + tb^2)*TCF[6][Sqrt[mq2[3, 3]]/\[Mu]])/tb^2 + 
                          ((1 + tb^2)*TCF[6][Sqrt[mu2[3, 3]]/\[Mu]])/
                          (2*tb^2)) - (4*g3^2*(Log[M3^2/Q^2] + TCF[6][
                          Sqrt[mq2[3, 3]]/M3] + TCF[6][Sqrt[mu2[3, 3]]/M3] - 
                          ((At - \[Mu]/tb)*TCF[9][Sqrt[mq2[3, 3]]/M3, 
                          Sqrt[mu2[3, 3]]/M3])/M3))/3))/tb^2 + (8*gt^2*
                         (1 + tb^2)*Log[MS/Q]*mq2[3, 3]*((-4*g3^2)/3 - 
                          gt^2*((3*(-1 + 2*Log[mA^2/Q^2]))/(8*tb^2) + 
                          (3*(1 + tb^2)*Log[\[Mu]^2/Q^2])/(4*tb^2) - 
                          ((At - \[Mu]/tb)^2*TCF[5][Sqrt[mq2[3, 3]]/Sqrt[
                          mu2[3, 3]]])/(4*Sqrt[mq2[3, 3]*mu2[3, 3]]) + 
                          ((1 + tb^2)*TCF[6][Sqrt[mq2[3, 3]]/\[Mu]])/tb^2 + 
                          ((1 + tb^2)*TCF[6][Sqrt[mu2[3, 3]]/\[Mu]])/
                          (2*tb^2)) - (4*g3^2*(Log[M3^2/Q^2] + TCF[6][
                          Sqrt[mq2[3, 3]]/M3] + TCF[6][Sqrt[mu2[3, 3]]/M3] - 
                          ((At - \[Mu]/tb)*TCF[9][Sqrt[mq2[3, 3]]/M3, 
                          Sqrt[mu2[3, 3]]/M3])/M3))/3))/tb^2 + (8*gt^2*
                         (1 + tb^2)*Log[MS/Q]*mu2[3, 3]*((-4*g3^2)/3 - 
                          gt^2*((3*(-1 + 2*Log[mA^2/Q^2]))/(8*tb^2) + 
                          (3*(1 + tb^2)*Log[\[Mu]^2/Q^2])/(4*tb^2) - 
                          ((At - \[Mu]/tb)^2*TCF[5][Sqrt[mq2[3, 3]]/Sqrt[
                          mu2[3, 3]]])/(4*Sqrt[mq2[3, 3]*mu2[3, 3]]) + 
                          ((1 + tb^2)*TCF[6][Sqrt[mq2[3, 3]]/\[Mu]])/tb^2 + 
                          ((1 + tb^2)*TCF[6][Sqrt[mu2[3, 3]]/\[Mu]])/
                          (2*tb^2)) - (4*g3^2*(Log[M3^2/Q^2] + TCF[6][
                          Sqrt[mq2[3, 3]]/M3] + TCF[6][Sqrt[mu2[3, 3]]/M3] - 
                          ((At - \[Mu]/tb)*TCF[9][Sqrt[mq2[3, 3]]/M3, 
                          Sqrt[mu2[3, 3]]/M3])/M3))/3))/tb^2)/mu2[3, 3]))/
                   mu2[3, 3]))/mq2[3, 3])*Derivative[1][TCF[2]][Sqrt[
                mq2[3, 3]/mu2[3, 3]]])/2 + 
            (mu2[3, 3]*((mq2[3, 3]*(-4*gt^2*Log[MS/Q] - (4*gt^2*Log[MS/Q])/
                    tb^2 - (4*At^2*gt^2*Log[MS/Q])/mu2[3, 3] + 
                   (32*g3^2*M3^2*Log[MS/Q])/(3*mu2[3, 3]) - (4*At^2*gt^2*
                     Log[MS/Q])/(tb^2*mu2[3, 3]) - (4*gt^2*mA^2*Log[MS/Q])/
                    (tb^2*mu2[3, 3]) + (4*gt^2*\[Mu]^2*Log[MS/Q])/mu2[3, 3] + 
                   (4*gt^2*\[Mu]^2*Log[MS/Q])/(tb^2*mu2[3, 3]) - 
                   (4*gt^2*Log[MS/Q]*mq2[3, 3])/mu2[3, 3] - (4*gt^2*Log[MS/Q]*
                     mq2[3, 3])/(tb^2*mu2[3, 3])))/mu2[3, 3] + 
                ((-32*g3^2*M3^2*Log[MS/Q])/3 + (2*gt^2*mA^2*Log[MS/Q])/tb^2 + 
                  (2*At^2*gt^2*(1 + tb^2)*Log[MS/Q])/tb^2 - 
                  (2*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/tb^2 + 
                  (2*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3])/tb^2 + 
                  (2*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^2)/mu2[3, 3])^2*
              Derivative[2][TCF[2]][Sqrt[mq2[3, 3]/mu2[3, 3]]])/
             (8*mq2[3, 3]))/Sqrt[mq2[3, 3]*mu2[3, 3]]))/12))/
    Sqrt[mq2[3, 3]*mu2[3, 3]])
