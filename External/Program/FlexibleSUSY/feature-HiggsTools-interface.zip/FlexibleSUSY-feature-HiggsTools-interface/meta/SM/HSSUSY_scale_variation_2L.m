(* Created by Wolfram Mathematica 9.0 : www.wolfram.com *)
(1971*g1^6*Log[MS/Q]^2)/1000 + (333*g1^4*g2^2*Log[MS/Q]^2)/200 - 
 (357*g1^2*g2^4*Log[MS/Q]^2)/40 - (195*g2^6*Log[MS/Q]^2)/8 + 
 (81*g1^4*gb^2*Log[MS/Q]^2)/50 + (27*g1^2*g2^2*gb^2*Log[MS/Q]^2)/5 + 
 (27*g2^4*gb^2*Log[MS/Q]^2)/2 + (84*g1^2*gb^4*Log[MS/Q]^2)/5 + 
 108*g2^2*gb^4*Log[MS/Q]^2 + 192*g3^2*gb^4*Log[MS/Q]^2 - 
 180*gb^6*Log[MS/Q]^2 + (81*g1^4*gt^2*Log[MS/Q]^2)/50 + 
 (27*g1^2*g2^2*gt^2*Log[MS/Q]^2)/5 + (27*g2^4*gt^2*Log[MS/Q]^2)/2 - 
 108*gb^4*gt^2*Log[MS/Q]^2 + (156*g1^2*gt^4*Log[MS/Q]^2)/5 + 
 108*g2^2*gt^4*Log[MS/Q]^2 + 192*g3^2*gt^4*Log[MS/Q]^2 - 
 108*gb^2*gt^4*Log[MS/Q]^2 - 180*gt^6*Log[MS/Q]^2 + 
 (27*g1^4*gtau^2*Log[MS/Q]^2)/50 + (9*g1^2*g2^2*gtau^2*Log[MS/Q]^2)/5 + 
 (9*g2^4*gtau^2*Log[MS/Q]^2)/2 - 48*gb^4*gtau^2*Log[MS/Q]^2 - 
 48*gt^4*gtau^2*Log[MS/Q]^2 + (108*g1^2*gtau^4*Log[MS/Q]^2)/5 + 
 36*g2^2*gtau^4*Log[MS/Q]^2 - 48*gb^2*gtau^4*Log[MS/Q]^2 - 
 48*gt^2*gtau^4*Log[MS/Q]^2 - 28*gtau^6*Log[MS/Q]^2 - 
 (63*g1^4*((3*g1^2)/5 + g2^2)*Cos[2*ArcTan[tb]]^2*Log[MS/Q]^2)/100 + 
 (27*g1^2*g2^2*((3*g1^2)/5 + g2^2)*Cos[2*ArcTan[tb]]^2*Log[MS/Q]^2)/4 + 
 24*g2^4*((3*g1^2)/5 + g2^2)*Cos[2*ArcTan[tb]]^2*Log[MS/Q]^2 - 
 (123*g1^2*((3*g1^2)/5 + g2^2)*gb^2*Cos[2*ArcTan[tb]]^2*Log[MS/Q]^2)/20 - 
 (135*g2^2*((3*g1^2)/5 + g2^2)*gb^2*Cos[2*ArcTan[tb]]^2*Log[MS/Q]^2)/4 - 
 24*((3*g1^2)/5 + g2^2)*g3^2*gb^2*Cos[2*ArcTan[tb]]^2*Log[MS/Q]^2 - 
 (9*((3*g1^2)/5 + g2^2)*gb^4*Cos[2*ArcTan[tb]]^2*Log[MS/Q]^2)/2 - 
 (159*g1^2*((3*g1^2)/5 + g2^2)*gt^2*Cos[2*ArcTan[tb]]^2*Log[MS/Q]^2)/20 - 
 (135*g2^2*((3*g1^2)/5 + g2^2)*gt^2*Cos[2*ArcTan[tb]]^2*Log[MS/Q]^2)/4 - 
 24*((3*g1^2)/5 + g2^2)*g3^2*gt^2*Cos[2*ArcTan[tb]]^2*Log[MS/Q]^2 + 
 45*((3*g1^2)/5 + g2^2)*gb^2*gt^2*Cos[2*ArcTan[tb]]^2*Log[MS/Q]^2 - 
 (9*((3*g1^2)/5 + g2^2)*gt^4*Cos[2*ArcTan[tb]]^2*Log[MS/Q]^2)/2 - 
 (81*g1^2*((3*g1^2)/5 + g2^2)*gtau^2*Cos[2*ArcTan[tb]]^2*Log[MS/Q]^2)/20 - 
 (45*g2^2*((3*g1^2)/5 + g2^2)*gtau^2*Cos[2*ArcTan[tb]]^2*Log[MS/Q]^2)/4 + 
 18*((3*g1^2)/5 + g2^2)*gb^2*gtau^2*Cos[2*ArcTan[tb]]^2*Log[MS/Q]^2 + 
 18*((3*g1^2)/5 + g2^2)*gt^2*gtau^2*Cos[2*ArcTan[tb]]^2*Log[MS/Q]^2 - 
 (15*((3*g1^2)/5 + g2^2)*gtau^4*Cos[2*ArcTan[tb]]^2*Log[MS/Q]^2)/2 - 
 (81*g1^2*((3*g1^2)/5 + g2^2)^2*Cos[2*ArcTan[tb]]^4*Log[MS/Q]^2)/40 - 
 (81*g2^2*((3*g1^2)/5 + g2^2)^2*Cos[2*ArcTan[tb]]^4*Log[MS/Q]^2)/8 + 
 (27*((3*g1^2)/5 + g2^2)^2*gb^2*Cos[2*ArcTan[tb]]^4*Log[MS/Q]^2)/2 + 
 (27*((3*g1^2)/5 + g2^2)^2*gt^2*Cos[2*ArcTan[tb]]^4*Log[MS/Q]^2)/2 + 
 (9*((3*g1^2)/5 + g2^2)^2*gtau^2*Cos[2*ArcTan[tb]]^4*Log[MS/Q]^2)/2 + 
 (9*((3*g1^2)/5 + g2^2)^3*Cos[2*ArcTan[tb]]^6*Log[MS/Q]^2)/4 + 
 (-(Cos[2*ArcTan[tb]]^2*((5043*g1^6*Log[MS/Q]^2)/125 + 
      (361*g2^6*Log[MS/Q]^2)/9)) + 
   (4*Cos[2*ArcTan[tb]]*((123*g1^4*Log[MS/Q])/25 - (19*g2^4*Log[MS/Q])/3)*
     (-3*gt^2*Log[MS/Q] + 3*gb^2*tb^2*Log[MS/Q] + gtau^2*tb^2*Log[MS/Q])*
     Sin[2*ArcTan[tb]])/tb - ((3*g1^2)/5 + g2^2)*
    ((4*(-3*gt^2*Log[MS/Q] + 3*gb^2*tb^2*Log[MS/Q] + gtau^2*tb^2*Log[MS/Q])^2*
       Sin[2*ArcTan[tb]]^2)/tb^2 + 2*Cos[2*ArcTan[tb]]*
      ((-2*Cos[2*ArcTan[tb]]*(-3*gt^2*Log[MS/Q] + 3*gb^2*tb^2*Log[MS/Q] + 
           gtau^2*tb^2*Log[MS/Q])^2)/tb^2 + Sin[2*ArcTan[tb]]*
        (-((((6*gt^2*Log[MS/Q])/(1 + tb^2) - (6*gb^2*tb^2*Log[MS/Q])/
              (1 + tb^2) + (6*gt^2*tb^2*Log[MS/Q])/(1 + tb^2) - 
             (2*gtau^2*tb^2*Log[MS/Q])/(1 + tb^2) - (6*gb^2*tb^4*Log[MS/Q])/
              (1 + tb^2) - (2*gtau^2*tb^4*Log[MS/Q])/(1 + tb^2))*
            ((-3*gt^2*(1 + tb^2)*Log[MS/Q])/tb + 3*gb^2*tb*(1 + tb^2)*
              Log[MS/Q] + gtau^2*tb*(1 + tb^2)*Log[MS/Q]))/(1 + tb^2)) - 
         (2*((13*g1^2*gt^2*(1 + tb^2)*Log[MS/Q]^2)/(5*tb) + 
            (9*g2^2*gt^2*(1 + tb^2)*Log[MS/Q]^2)/tb + 
            (16*g3^2*gt^2*(1 + tb^2)*Log[MS/Q]^2)/tb - 
            (7*g1^2*gb^2*tb*(1 + tb^2)*Log[MS/Q]^2)/5 - 9*g2^2*gb^2*tb*
             (1 + tb^2)*Log[MS/Q]^2 - 16*g3^2*gb^2*tb*(1 + tb^2)*
             Log[MS/Q]^2 - (9*g1^2*gtau^2*tb*(1 + tb^2)*Log[MS/Q]^2)/5 - 
            3*g2^2*gtau^2*tb*(1 + tb^2)*Log[MS/Q]^2 - 
            (27*gt^4*(1 + tb^2)^2*Log[MS/Q]^2)/(2*tb^3) - 
            (9*gb^2*gt^2*(1 + tb^2)^2*Log[MS/Q]^2)/tb - 
            (3*gt^2*gtau^2*(1 + tb^2)^2*Log[MS/Q]^2)/tb + 
            (45*gb^4*tb*(1 + tb^2)^2*Log[MS/Q]^2)/2 + 9*gb^2*gtau^2*tb*
             (1 + tb^2)^2*Log[MS/Q]^2 + (9*gtau^4*tb*(1 + tb^2)^2*
              Log[MS/Q]^2)/2 - (6*gt^2*(1 + tb^2)*Log[MS/Q]*
              (g1^2/120 + (3*g2^2)/8 - (4*g3^2)/3 - gt^2*
                ((3*(-1 + 2*Log[mA^2/Q^2]))/(8*tb^2) + (3*(1 + tb^2)*
                   Log[\[Mu]^2/Q^2])/(4*tb^2) - ((At - \[Mu]/tb)^2*
                   TCF[5][Sqrt[mq2[3, 3]]/Sqrt[mu2[3, 3]]])/
                  (4*Sqrt[mq2[3, 3]*mu2[3, 3]]) + ((1 + tb^2)*TCF[6][
                    Sqrt[mq2[3, 3]]/\[Mu]])/tb^2 + ((1 + tb^2)*TCF[6][
                    Sqrt[mu2[3, 3]]/\[Mu]])/(2*tb^2)) - (4*g3^2*
                 (Log[M3^2/Q^2] + TCF[6][Sqrt[mq2[3, 3]]/M3] + TCF[6][
                   Sqrt[mu2[3, 3]]/M3] - ((At - \[Mu]/tb)*TCF[9][
                     Sqrt[mq2[3, 3]]/M3, Sqrt[mu2[3, 3]]/M3])/M3))/3))/tb))/
          (1 + tb^2)))))/4 - 
 16*Pi^2*(((-369*g1^6*Log[MS/Q])/250 - (123*g1^4*g2^2*Log[MS/Q])/50 + 
     (19*g1^2*g2^4*Log[MS/Q])/10 + (38*g2^6*(3/4 - Cos[2*ArcTan[tb]]^2/6)*
       Log[MS/Q])/3 - (2*g2^4*Cos[2*ArcTan[tb]]*(-3*gt^2*Log[MS/Q] + 
        3*gb^2*tb^2*Log[MS/Q] + gtau^2*tb^2*Log[MS/Q])*Sin[2*ArcTan[tb]])/
      (3*tb))/(16*Pi^2) + 
   (-(Cos[2*ArcTan[tb]]^2*((-76*g2^6*Log[M2^2/Q^2]*Log[MS/Q])/3 + 
        ((9*g1^4)/25 + g2^4)*((-6*g1^2*Log[MS/Q])/5 - 6*g2^2*Log[MS/Q] + 
          6*gb^2*Log[MS/Q] + 6*gt^2*Log[MS/Q] + 2*gtau^2*Log[MS/Q] + 
          (6*gt^2*Log[MS/Q])/tb^2 + 6*gb^2*tb^2*Log[MS/Q] + 
          2*gtau^2*tb^2*Log[MS/Q]) + ((738*g1^6*Log[MS/Q])/125 - 
          (38*g2^6*Log[MS/Q])/3)*Log[\[Mu]^2/Q^2])) + 
     (4*Cos[2*ArcTan[tb]]*(-3*gt^2*Log[MS/Q] + 3*gb^2*tb^2*Log[MS/Q] + 
        gtau^2*tb^2*Log[MS/Q])*(2*g2^4*Log[M2^2/Q^2] + ((9*g1^4)/25 + g2^4)*
         Log[\[Mu]^2/Q^2])*Sin[2*ArcTan[tb]])/tb)/(96*Pi^2) + 
   (Log[me2[3, 3]/Q^2]*((gtau*(gtau^2 - (3*g1^2*Cos[2*ArcTan[tb]])/5)*
         (-9*g1^2*gtau*Log[MS/Q] - 9*g2^2*gtau*Log[MS/Q] + 
          12*gb^2*gtau*Log[MS/Q] + 12*gt^2*gtau*Log[MS/Q] + 
          10*gtau^3*Log[MS/Q]))/2 + 
       gtau^2*((gtau*(-9*g1^2*gtau*Log[MS/Q] - 9*g2^2*gtau*Log[MS/Q] + 
            12*gb^2*gtau*Log[MS/Q] + 12*gt^2*gtau*Log[MS/Q] + 
            10*gtau^3*Log[MS/Q]))/2 - 
         (3*((41*g1^4*Cos[2*ArcTan[tb]]*Log[MS/Q])/5 - 
            (2*g1^2*(-3*gt^2*Log[MS/Q] + 3*gb^2*tb^2*Log[MS/Q] + gtau^2*tb^2*
                Log[MS/Q])*Sin[2*ArcTan[tb]])/tb))/5)) + 
     Log[ml2[3, 3]/Q^2]*
      ((gtau*(gtau^2 - (((-3*g1^2)/5 + g2^2)*Cos[2*ArcTan[tb]])/2)*
         (-9*g1^2*gtau*Log[MS/Q] - 9*g2^2*gtau*Log[MS/Q] + 
          12*gb^2*gtau*Log[MS/Q] + 12*gt^2*gtau*Log[MS/Q] + 
          10*gtau^3*Log[MS/Q]))/2 + 
       gtau^2*((gtau*(-9*g1^2*gtau*Log[MS/Q] - 9*g2^2*gtau*Log[MS/Q] + 
            12*gb^2*gtau*Log[MS/Q] + 12*gt^2*gtau*Log[MS/Q] + 
            10*gtau^3*Log[MS/Q]))/2 + 
         (-(Cos[2*ArcTan[tb]]*((-123*g1^4*Log[MS/Q])/25 - (19*g2^4*Log[MS/Q])/
               3)) + (2*((-3*g1^2)/5 + g2^2)*(-3*gt^2*Log[MS/Q] + 
              3*gb^2*tb^2*Log[MS/Q] + gtau^2*tb^2*Log[MS/Q])*
             Sin[2*ArcTan[tb]])/tb)/2)) + 
     (2*((gtau^4*tb*(Atau - tb*\[Mu])^3*(-3*g1^2*\[Mu]*Log[MS/Q] - 
           15*g2^2*\[Mu]*Log[MS/Q] + 30*gb^2*\[Mu]*Log[MS/Q] + 
           10*gtau^2*\[Mu]*Log[MS/Q] + 30*gb^2*tb^2*\[Mu]*Log[MS/Q] + 
           10*gtau^2*tb^2*\[Mu]*Log[MS/Q])*TCF[2][Sqrt[ml2[3, 3]/me2[3, 3]]])/
         (30*Sqrt[me2[3, 3]*ml2[3, 3]]) + 
        (gtau^3*(Atau - tb*\[Mu])^2*(-9*g1^2*gtau*Log[MS/Q] - 
            9*g2^2*gtau*Log[MS/Q] + 12*gb^2*gtau*Log[MS/Q] + 
            12*gt^2*gtau*Log[MS/Q] + 10*gtau^3*Log[MS/Q]) - 
          (2*gtau^4*tb*(Atau - tb*\[Mu])*(-3*g1^2*\[Mu]*Log[MS/Q] - 
             15*g2^2*\[Mu]*Log[MS/Q] + 30*gb^2*\[Mu]*Log[MS/Q] + 
             10*gtau^2*\[Mu]*Log[MS/Q] + 30*gb^2*tb^2*\[Mu]*Log[MS/Q] + 
             10*gtau^2*tb^2*\[Mu]*Log[MS/Q]))/5)*
         (TCF[1][Sqrt[ml2[3, 3]/me2[3, 3]]] - ((Atau - tb*\[Mu])^2*
            TCF[2][Sqrt[ml2[3, 3]/me2[3, 3]]])/
           (12*Sqrt[me2[3, 3]*ml2[3, 3]]))))/Sqrt[me2[3, 3]*ml2[3, 3]] + 
     ((-2*gtau^2*tb*(Atau - tb*\[Mu])*Cos[2*ArcTan[tb]]*
         (-3*g1^2*\[Mu]*Log[MS/Q] - 15*g2^2*\[Mu]*Log[MS/Q] + 
          30*gb^2*\[Mu]*Log[MS/Q] + 10*gtau^2*\[Mu]*Log[MS/Q] + 
          30*gb^2*tb^2*\[Mu]*Log[MS/Q] + 10*gtau^2*tb^2*\[Mu]*Log[MS/Q])*
         ((-9*g1^2*TCF[3][Sqrt[ml2[3, 3]/me2[3, 3]]])/10 + 
          (3*g1^2*TCF[4][Sqrt[ml2[3, 3]/me2[3, 3]]])/10 - 
          g2^2*TCF[4][Sqrt[ml2[3, 3]/me2[3, 3]]]))/5 + 
       (Atau - tb*\[Mu])^2*
        (((gtau*Cos[2*ArcTan[tb]]*(-9*g1^2*gtau*Log[MS/Q] - 9*g2^2*gtau*Log[
                MS/Q] + 12*gb^2*gtau*Log[MS/Q] + 12*gt^2*gtau*Log[MS/Q] + 
              10*gtau^3*Log[MS/Q]))/2 - (2*gtau^2*(-3*gt^2*Log[MS/Q] + 
              3*gb^2*tb^2*Log[MS/Q] + gtau^2*tb^2*Log[MS/Q])*
             Sin[2*ArcTan[tb]])/tb)*
          ((-9*g1^2*TCF[3][Sqrt[ml2[3, 3]/me2[3, 3]]])/10 + 
           (3*g1^2*TCF[4][Sqrt[ml2[3, 3]/me2[3, 3]]])/10 - 
           g2^2*TCF[4][Sqrt[ml2[3, 3]/me2[3, 3]]]) + 
         (gtau^2*Cos[2*ArcTan[tb]]*(-1107*g1^4*Log[MS/Q]*
             TCF[3][Sqrt[ml2[3, 3]/me2[3, 3]]] + 369*g1^4*Log[MS/Q]*
             TCF[4][Sqrt[ml2[3, 3]/me2[3, 3]]] + 950*g2^4*Log[MS/Q]*
             TCF[4][Sqrt[ml2[3, 3]/me2[3, 3]]]))/150))/
      (4*Sqrt[me2[3, 3]*ml2[3, 3]]) + 
     (((2*((3*g1^2)/5 + g2^2)*gtau^2*tb*(Atau - tb*\[Mu])*Cos[2*ArcTan[tb]]^2*
          (-3*g1^2*\[Mu]*Log[MS/Q] - 15*g2^2*\[Mu]*Log[MS/Q] + 
           30*gb^2*\[Mu]*Log[MS/Q] + 10*gtau^2*\[Mu]*Log[MS/Q] + 
           30*gb^2*tb^2*\[Mu]*Log[MS/Q] + 10*gtau^2*tb^2*\[Mu]*Log[MS/Q]))/
         5 - (Atau - tb*\[Mu])^2*(gtau^2*Cos[2*ArcTan[tb]]^2*
           ((123*g1^4*Log[MS/Q])/25 - (19*g2^4*Log[MS/Q])/3) + 
          ((3*g1^2)/5 + g2^2)*((gtau*Cos[2*ArcTan[tb]]^2*(-9*g1^2*gtau*
                Log[MS/Q] - 9*g2^2*gtau*Log[MS/Q] + 12*gb^2*gtau*Log[MS/Q] + 
               12*gt^2*gtau*Log[MS/Q] + 10*gtau^3*Log[MS/Q]))/2 - 
            (4*gtau^2*Cos[2*ArcTan[tb]]*(-3*gt^2*Log[MS/Q] + 3*gb^2*tb^2*
                Log[MS/Q] + gtau^2*tb^2*Log[MS/Q])*Sin[2*ArcTan[tb]])/tb)))*
       TCF[5][Sqrt[ml2[3, 3]/me2[3, 3]]])/(12*Sqrt[me2[3, 3]*ml2[3, 3]]))/
    (16*Pi^2) + 
   (3*((gb^2*(gb^2 - (g1^2*Cos[2*ArcTan[tb]])/5)*
         ((-8*g1^2*M1^2*Log[MS/Q])/15 - (32*g3^2*M3^2*Log[MS/Q])/3 + 
          4*gb^2*mA^2*Log[MS/Q] + (2*g1^2*mA^2*Log[MS/Q])/(5*(1 + tb^2)) - 
          (2*g1^2*mA^2*tb^2*Log[MS/Q])/(5*(1 + tb^2)) + 
          4*Ab^2*gb^2*(1 + tb^2)*Log[MS/Q] - 4*gb^2*(1 + tb^2)*\[Mu]^2*
           Log[MS/Q] + (2*g1^2*Log[MS/Q]*md2[1, 1])/5 + 
          (2*g1^2*Log[MS/Q]*md2[2, 2])/5 + (2*g1^2*Log[MS/Q]*md2[3, 3])/5 + 
          (2*g1^2*Log[MS/Q]*me2[1, 1])/5 + (2*g1^2*Log[MS/Q]*me2[2, 2])/5 + 
          (2*g1^2*Log[MS/Q]*me2[3, 3])/5 - (2*g1^2*Log[MS/Q]*ml2[1, 1])/5 - 
          (2*g1^2*Log[MS/Q]*ml2[2, 2])/5 - (2*g1^2*Log[MS/Q]*ml2[3, 3])/5 + 
          (2*g1^2*Log[MS/Q]*mq2[1, 1])/5 + (2*g1^2*Log[MS/Q]*mq2[2, 2])/5 + 
          (2*g1^2*Log[MS/Q]*mq2[3, 3])/5 + 4*gb^2*(1 + tb^2)*Log[MS/Q]*
           mq2[3, 3] - (4*g1^2*Log[MS/Q]*mu2[1, 1])/5 - 
          (4*g1^2*Log[MS/Q]*mu2[2, 2])/5 - (4*g1^2*Log[MS/Q]*mu2[3, 3])/5 + 
          4*gb^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3]))/md2[3, 3] + 
       Log[md2[3, 3]/Q^2]*((gb*(gb^2 - (g1^2*Cos[2*ArcTan[tb]])/5)*
           (-(g1^2*gb*Log[MS/Q]) - 9*g2^2*gb*Log[MS/Q] - 
            32*g3^2*gb*Log[MS/Q] + 18*gb^3*Log[MS/Q] + 6*gb*gt^2*Log[MS/Q] + 
            4*gb*gtau^2*Log[MS/Q]))/2 + 
         gb^2*((gb*(-(g1^2*gb*Log[MS/Q]) - 9*g2^2*gb*Log[MS/Q] - 
              32*g3^2*gb*Log[MS/Q] + 18*gb^3*Log[MS/Q] + 6*gb*gt^2*Log[
                MS/Q] + 4*gb*gtau^2*Log[MS/Q]))/2 + 
           ((-41*g1^4*Cos[2*ArcTan[tb]]*Log[MS/Q])/5 + 
             (2*g1^2*(-3*gt^2*Log[MS/Q] + 3*gb^2*tb^2*Log[MS/Q] + 
                gtau^2*tb^2*Log[MS/Q])*Sin[2*ArcTan[tb]])/tb)/5))) + 
     3*((gb^2*(gb^2 - ((g1^2 + 5*g2^2)*Cos[2*ArcTan[tb]])/10)*
         ((-2*g1^2*M1^2*Log[MS/Q])/15 - 6*g2^2*M2^2*Log[MS/Q] - 
          (32*g3^2*M3^2*Log[MS/Q])/3 + (2*gt^2*mA^2*Log[MS/Q])/tb^2 + 
          (g1^2*mA^2*Log[MS/Q])/(5*(1 + tb^2)) - (g1^2*mA^2*tb^2*Log[MS/Q])/
           (5*(1 + tb^2)) + (2*At^2*gt^2*(1 + tb^2)*Log[MS/Q])/tb^2 - 
          (2*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/tb^2 + 
          (g1^2*Log[MS/Q]*md2[1, 1])/5 + (g1^2*Log[MS/Q]*md2[2, 2])/5 + 
          (g1^2*Log[MS/Q]*md2[3, 3])/5 + (g1^2*Log[MS/Q]*me2[1, 1])/5 + 
          (g1^2*Log[MS/Q]*me2[2, 2])/5 + (g1^2*Log[MS/Q]*me2[3, 3])/5 - 
          (g1^2*Log[MS/Q]*ml2[1, 1])/5 - (g1^2*Log[MS/Q]*ml2[2, 2])/5 - 
          (g1^2*Log[MS/Q]*ml2[3, 3])/5 + (g1^2*Log[MS/Q]*mq2[1, 1])/5 + 
          (g1^2*Log[MS/Q]*mq2[2, 2])/5 + (g1^2*Log[MS/Q]*mq2[3, 3])/5 + 
          (2*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3])/tb^2 - 
          (2*g1^2*Log[MS/Q]*mu2[1, 1])/5 - (2*g1^2*Log[MS/Q]*mu2[2, 2])/5 - 
          (2*g1^2*Log[MS/Q]*mu2[3, 3])/5 + (2*gt^2*(1 + tb^2)*Log[MS/Q]*
            mu2[3, 3])/tb^2))/mq2[3, 3] + Log[mq2[3, 3]/Q^2]*
        ((gb*(gb^2 - ((g1^2 + 5*g2^2)*Cos[2*ArcTan[tb]])/10)*
           (-(g1^2*gb*Log[MS/Q]) - 9*g2^2*gb*Log[MS/Q] - 
            32*g3^2*gb*Log[MS/Q] + 18*gb^3*Log[MS/Q] + 6*gb*gt^2*Log[MS/Q] + 
            4*gb*gtau^2*Log[MS/Q]))/2 + 
         gb^2*((gb*(-(g1^2*gb*Log[MS/Q]) - 9*g2^2*gb*Log[MS/Q] - 
              32*g3^2*gb*Log[MS/Q] + 18*gb^3*Log[MS/Q] + 6*gb*gt^2*Log[
                MS/Q] + 4*gb*gtau^2*Log[MS/Q]))/2 + 
           (-(Cos[2*ArcTan[tb]]*((41*g1^4*Log[MS/Q])/25 - (19*g2^4*Log[MS/Q])/
                 3)) + (2*(g1^2/5 + g2^2)*(-3*gt^2*Log[MS/Q] + 3*gb^2*tb^2*
                 Log[MS/Q] + gtau^2*tb^2*Log[MS/Q])*Sin[2*ArcTan[tb]])/tb)/
            2))) + 
     6*(((-2*gb^4*tb*(Ab - tb*\[Mu])*(-3*g1^2*\[Mu]*Log[MS/Q] - 
            15*g2^2*\[Mu]*Log[MS/Q] + 30*gb^2*\[Mu]*Log[MS/Q] + 
            10*gtau^2*\[Mu]*Log[MS/Q] + 30*gb^2*tb^2*\[Mu]*Log[MS/Q] + 
            10*gtau^2*tb^2*\[Mu]*Log[MS/Q]))/(5*Sqrt[md2[3, 3]*mq2[3, 3]]) + 
         (Ab - tb*\[Mu])^2*((gb^3*(-(g1^2*gb*Log[MS/Q]) - 9*g2^2*gb*Log[
                MS/Q] - 32*g3^2*gb*Log[MS/Q] + 18*gb^3*Log[MS/Q] + 
              6*gb*gt^2*Log[MS/Q] + 4*gb*gtau^2*Log[MS/Q]))/
            Sqrt[md2[3, 3]*mq2[3, 3]] - 
           (gb^4*(mq2[3, 3]*((-8*g1^2*M1^2*Log[MS/Q])/15 - (32*g3^2*M3^2*
                  Log[MS/Q])/3 + 4*gb^2*mA^2*Log[MS/Q] + (2*g1^2*mA^2*
                  Log[MS/Q])/(5*(1 + tb^2)) - (2*g1^2*mA^2*tb^2*Log[MS/Q])/
                 (5*(1 + tb^2)) + 4*Ab^2*gb^2*(1 + tb^2)*Log[MS/Q] - 
                4*gb^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q] + (2*g1^2*Log[MS/Q]*
                  md2[1, 1])/5 + (2*g1^2*Log[MS/Q]*md2[2, 2])/5 + 
                (2*g1^2*Log[MS/Q]*md2[3, 3])/5 + (2*g1^2*Log[MS/Q]*me2[1, 1])/
                 5 + (2*g1^2*Log[MS/Q]*me2[2, 2])/5 + (2*g1^2*Log[MS/Q]*
                  me2[3, 3])/5 - (2*g1^2*Log[MS/Q]*ml2[1, 1])/5 - 
                (2*g1^2*Log[MS/Q]*ml2[2, 2])/5 - (2*g1^2*Log[MS/Q]*ml2[3, 3])/
                 5 + (2*g1^2*Log[MS/Q]*mq2[1, 1])/5 + (2*g1^2*Log[MS/Q]*
                  mq2[2, 2])/5 + (2*g1^2*Log[MS/Q]*mq2[3, 3])/5 + 
                4*gb^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3] - (4*g1^2*Log[MS/Q]*
                  mu2[1, 1])/5 - (4*g1^2*Log[MS/Q]*mu2[2, 2])/5 - 
                (4*g1^2*Log[MS/Q]*mu2[3, 3])/5 + 4*gb^2*(1 + tb^2)*Log[MS/Q]*
                 mu2[3, 3]) + md2[3, 3]*((-2*g1^2*M1^2*Log[MS/Q])/15 - 
                6*g2^2*M2^2*Log[MS/Q] - (32*g3^2*M3^2*Log[MS/Q])/3 + 
                (2*gt^2*mA^2*Log[MS/Q])/tb^2 + (g1^2*mA^2*Log[MS/Q])/
                 (5*(1 + tb^2)) - (g1^2*mA^2*tb^2*Log[MS/Q])/(5*(1 + tb^2)) + 
                (2*At^2*gt^2*(1 + tb^2)*Log[MS/Q])/tb^2 - (2*gt^2*(1 + tb^2)*
                  \[Mu]^2*Log[MS/Q])/tb^2 + (g1^2*Log[MS/Q]*md2[1, 1])/5 + 
                (g1^2*Log[MS/Q]*md2[2, 2])/5 + (g1^2*Log[MS/Q]*md2[3, 3])/5 + 
                (g1^2*Log[MS/Q]*me2[1, 1])/5 + (g1^2*Log[MS/Q]*me2[2, 2])/5 + 
                (g1^2*Log[MS/Q]*me2[3, 3])/5 - (g1^2*Log[MS/Q]*ml2[1, 1])/5 - 
                (g1^2*Log[MS/Q]*ml2[2, 2])/5 - (g1^2*Log[MS/Q]*ml2[3, 3])/5 + 
                (g1^2*Log[MS/Q]*mq2[1, 1])/5 + (g1^2*Log[MS/Q]*mq2[2, 2])/5 + 
                (g1^2*Log[MS/Q]*mq2[3, 3])/5 + (2*gt^2*(1 + tb^2)*Log[MS/Q]*
                  mq2[3, 3])/tb^2 - (2*g1^2*Log[MS/Q]*mu2[1, 1])/5 - 
                (2*g1^2*Log[MS/Q]*mu2[2, 2])/5 - (2*g1^2*Log[MS/Q]*mu2[3, 3])/
                 5 + (2*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^2)))/
            (2*md2[3, 3]*mq2[3, 3]*Sqrt[md2[3, 3]*mq2[3, 3]])))*
        (TCF[1][Sqrt[mq2[3, 3]/md2[3, 3]]] - 
         ((Ab - tb*\[Mu])^2*TCF[2][Sqrt[mq2[3, 3]/md2[3, 3]]])/
          (12*Sqrt[md2[3, 3]*mq2[3, 3]])) + 
       (gb^4*(Ab - tb*\[Mu])^2*((md2[3, 3]*Sqrt[mq2[3, 3]/md2[3, 3]]*
            (((-2*g1^2*M1^2*Log[MS/Q])/15 - 6*g2^2*M2^2*Log[MS/Q] - 
               (32*g3^2*M3^2*Log[MS/Q])/3 + (2*gt^2*mA^2*Log[MS/Q])/tb^2 + 
               (g1^2*mA^2*Log[MS/Q])/(5*(1 + tb^2)) - (g1^2*mA^2*tb^2*
                 Log[MS/Q])/(5*(1 + tb^2)) + (2*At^2*gt^2*(1 + tb^2)*
                 Log[MS/Q])/tb^2 - (2*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/
                tb^2 + (g1^2*Log[MS/Q]*md2[1, 1])/5 + (g1^2*Log[MS/Q]*
                 md2[2, 2])/5 + (g1^2*Log[MS/Q]*md2[3, 3])/5 + 
               (g1^2*Log[MS/Q]*me2[1, 1])/5 + (g1^2*Log[MS/Q]*me2[2, 2])/5 + 
               (g1^2*Log[MS/Q]*me2[3, 3])/5 - (g1^2*Log[MS/Q]*ml2[1, 1])/5 - 
               (g1^2*Log[MS/Q]*ml2[2, 2])/5 - (g1^2*Log[MS/Q]*ml2[3, 3])/5 + 
               (g1^2*Log[MS/Q]*mq2[1, 1])/5 + (g1^2*Log[MS/Q]*mq2[2, 2])/5 + 
               (g1^2*Log[MS/Q]*mq2[3, 3])/5 + (2*gt^2*(1 + tb^2)*Log[MS/Q]*
                 mq2[3, 3])/tb^2 - (2*g1^2*Log[MS/Q]*mu2[1, 1])/5 - 
               (2*g1^2*Log[MS/Q]*mu2[2, 2])/5 - (2*g1^2*Log[MS/Q]*mu2[3, 3])/
                5 + (2*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^2)/md2[3, 3] + 
             (mq2[3, 3]*((-2*g1^2*Log[MS/Q])/5 - (4*Ab^2*gb^2*Log[MS/Q])/
                 md2[3, 3] + (8*g1^2*M1^2*Log[MS/Q])/(15*md2[3, 3]) + 
                (32*g3^2*M3^2*Log[MS/Q])/(3*md2[3, 3]) - (4*gb^2*mA^2*
                  Log[MS/Q])/md2[3, 3] - (4*Ab^2*gb^2*tb^2*Log[MS/Q])/
                 md2[3, 3] - (2*g1^2*mA^2*Log[MS/Q])/(5*(1 + tb^2)*
                  md2[3, 3]) + (2*g1^2*mA^2*tb^2*Log[MS/Q])/(5*(1 + tb^2)*
                  md2[3, 3]) + (4*gb^2*\[Mu]^2*Log[MS/Q])/md2[3, 3] + 
                (4*gb^2*tb^2*\[Mu]^2*Log[MS/Q])/md2[3, 3] - 
                (2*g1^2*Log[MS/Q]*md2[1, 1])/(5*md2[3, 3]) - 
                (2*g1^2*Log[MS/Q]*md2[2, 2])/(5*md2[3, 3]) - 
                (2*g1^2*Log[MS/Q]*me2[1, 1])/(5*md2[3, 3]) - 
                (2*g1^2*Log[MS/Q]*me2[2, 2])/(5*md2[3, 3]) - 
                (2*g1^2*Log[MS/Q]*me2[3, 3])/(5*md2[3, 3]) + 
                (2*g1^2*Log[MS/Q]*ml2[1, 1])/(5*md2[3, 3]) + 
                (2*g1^2*Log[MS/Q]*ml2[2, 2])/(5*md2[3, 3]) + 
                (2*g1^2*Log[MS/Q]*ml2[3, 3])/(5*md2[3, 3]) - 
                (2*g1^2*Log[MS/Q]*mq2[1, 1])/(5*md2[3, 3]) - 
                (2*g1^2*Log[MS/Q]*mq2[2, 2])/(5*md2[3, 3]) - 
                (2*g1^2*Log[MS/Q]*mq2[3, 3])/(5*md2[3, 3]) - 
                (4*gb^2*Log[MS/Q]*mq2[3, 3])/md2[3, 3] - (4*gb^2*tb^2*
                  Log[MS/Q]*mq2[3, 3])/md2[3, 3] + (4*g1^2*Log[MS/Q]*
                  mu2[1, 1])/(5*md2[3, 3]) + (4*g1^2*Log[MS/Q]*mu2[2, 2])/
                 (5*md2[3, 3]) + (4*g1^2*Log[MS/Q]*mu2[3, 3])/(5*md2[3, 3]) - 
                (4*gb^2*Log[MS/Q]*mu2[3, 3])/md2[3, 3] - (4*gb^2*tb^2*
                  Log[MS/Q]*mu2[3, 3])/md2[3, 3]))/md2[3, 3])*
            Derivative[1][TCF[1]][Sqrt[mq2[3, 3]/md2[3, 3]]])/(2*mq2[3, 3]) + 
          ((2*tb*(Ab - tb*\[Mu])*(-3*g1^2*\[Mu]*Log[MS/Q] - 15*g2^2*\[Mu]*
                Log[MS/Q] + 30*gb^2*\[Mu]*Log[MS/Q] + 10*gtau^2*\[Mu]*
                Log[MS/Q] + 30*gb^2*tb^2*\[Mu]*Log[MS/Q] + 10*gtau^2*tb^2*
                \[Mu]*Log[MS/Q])*TCF[2][Sqrt[mq2[3, 3]/md2[3, 3]]])/
             (5*Sqrt[md2[3, 3]*mq2[3, 3]]) - (Ab - tb*\[Mu])^2*
             (-((mq2[3, 3]*((-8*g1^2*M1^2*Log[MS/Q])/15 - (32*g3^2*M3^2*
                      Log[MS/Q])/3 + 4*gb^2*mA^2*Log[MS/Q] + (2*g1^2*mA^2*
                      Log[MS/Q])/(5*(1 + tb^2)) - (2*g1^2*mA^2*tb^2*
                      Log[MS/Q])/(5*(1 + tb^2)) + 4*Ab^2*gb^2*(1 + tb^2)*
                     Log[MS/Q] - 4*gb^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q] + 
                    (2*g1^2*Log[MS/Q]*md2[1, 1])/5 + (2*g1^2*Log[MS/Q]*
                      md2[2, 2])/5 + (2*g1^2*Log[MS/Q]*md2[3, 3])/5 + 
                    (2*g1^2*Log[MS/Q]*me2[1, 1])/5 + (2*g1^2*Log[MS/Q]*
                      me2[2, 2])/5 + (2*g1^2*Log[MS/Q]*me2[3, 3])/5 - 
                    (2*g1^2*Log[MS/Q]*ml2[1, 1])/5 - (2*g1^2*Log[MS/Q]*
                      ml2[2, 2])/5 - (2*g1^2*Log[MS/Q]*ml2[3, 3])/5 + 
                    (2*g1^2*Log[MS/Q]*mq2[1, 1])/5 + (2*g1^2*Log[MS/Q]*
                      mq2[2, 2])/5 + (2*g1^2*Log[MS/Q]*mq2[3, 3])/5 + 
                    4*gb^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3] - (4*g1^2*Log[MS/Q]*
                      mu2[1, 1])/5 - (4*g1^2*Log[MS/Q]*mu2[2, 2])/5 - 
                    (4*g1^2*Log[MS/Q]*mu2[3, 3])/5 + 4*gb^2*(1 + tb^2)*
                     Log[MS/Q]*mu2[3, 3]) + md2[3, 3]*((-2*g1^2*M1^2*
                      Log[MS/Q])/15 - 6*g2^2*M2^2*Log[MS/Q] - (32*g3^2*M3^2*
                      Log[MS/Q])/3 + (2*gt^2*mA^2*Log[MS/Q])/tb^2 + 
                    (g1^2*mA^2*Log[MS/Q])/(5*(1 + tb^2)) - (g1^2*mA^2*tb^2*
                      Log[MS/Q])/(5*(1 + tb^2)) + (2*At^2*gt^2*(1 + tb^2)*
                      Log[MS/Q])/tb^2 - (2*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/
                     tb^2 + (g1^2*Log[MS/Q]*md2[1, 1])/5 + (g1^2*Log[MS/Q]*
                      md2[2, 2])/5 + (g1^2*Log[MS/Q]*md2[3, 3])/5 + 
                    (g1^2*Log[MS/Q]*me2[1, 1])/5 + (g1^2*Log[MS/Q]*me2[2, 2])/
                     5 + (g1^2*Log[MS/Q]*me2[3, 3])/5 - (g1^2*Log[MS/Q]*
                      ml2[1, 1])/5 - (g1^2*Log[MS/Q]*ml2[2, 2])/5 - 
                    (g1^2*Log[MS/Q]*ml2[3, 3])/5 + (g1^2*Log[MS/Q]*mq2[1, 1])/
                     5 + (g1^2*Log[MS/Q]*mq2[2, 2])/5 + (g1^2*Log[MS/Q]*
                      mq2[3, 3])/5 + (2*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3])/
                     tb^2 - (2*g1^2*Log[MS/Q]*mu2[1, 1])/5 - 
                    (2*g1^2*Log[MS/Q]*mu2[2, 2])/5 - (2*g1^2*Log[MS/Q]*
                      mu2[3, 3])/5 + (2*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/
                     tb^2))*TCF[2][Sqrt[mq2[3, 3]/md2[3, 3]]])/(2*md2[3, 3]*
                mq2[3, 3]*Sqrt[md2[3, 3]*mq2[3, 3]]) + (md2[3, 3]*
                Sqrt[mq2[3, 3]/md2[3, 3]]*(((-2*g1^2*M1^2*Log[MS/Q])/15 - 
                   6*g2^2*M2^2*Log[MS/Q] - (32*g3^2*M3^2*Log[MS/Q])/3 + 
                   (2*gt^2*mA^2*Log[MS/Q])/tb^2 + (g1^2*mA^2*Log[MS/Q])/
                    (5*(1 + tb^2)) - (g1^2*mA^2*tb^2*Log[MS/Q])/
                    (5*(1 + tb^2)) + (2*At^2*gt^2*(1 + tb^2)*Log[MS/Q])/
                    tb^2 - (2*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/tb^2 + 
                   (g1^2*Log[MS/Q]*md2[1, 1])/5 + (g1^2*Log[MS/Q]*md2[2, 2])/
                    5 + (g1^2*Log[MS/Q]*md2[3, 3])/5 + (g1^2*Log[MS/Q]*
                     me2[1, 1])/5 + (g1^2*Log[MS/Q]*me2[2, 2])/5 + 
                   (g1^2*Log[MS/Q]*me2[3, 3])/5 - (g1^2*Log[MS/Q]*ml2[1, 1])/
                    5 - (g1^2*Log[MS/Q]*ml2[2, 2])/5 - (g1^2*Log[MS/Q]*
                     ml2[3, 3])/5 + (g1^2*Log[MS/Q]*mq2[1, 1])/5 + 
                   (g1^2*Log[MS/Q]*mq2[2, 2])/5 + (g1^2*Log[MS/Q]*mq2[3, 3])/
                    5 + (2*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3])/tb^2 - 
                   (2*g1^2*Log[MS/Q]*mu2[1, 1])/5 - (2*g1^2*Log[MS/Q]*
                     mu2[2, 2])/5 - (2*g1^2*Log[MS/Q]*mu2[3, 3])/5 + 
                   (2*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^2)/md2[3, 3] + 
                 (mq2[3, 3]*((-2*g1^2*Log[MS/Q])/5 - (4*Ab^2*gb^2*Log[MS/Q])/
                     md2[3, 3] + (8*g1^2*M1^2*Log[MS/Q])/(15*md2[3, 3]) + 
                    (32*g3^2*M3^2*Log[MS/Q])/(3*md2[3, 3]) - (4*gb^2*mA^2*
                      Log[MS/Q])/md2[3, 3] - (4*Ab^2*gb^2*tb^2*Log[MS/Q])/
                     md2[3, 3] - (2*g1^2*mA^2*Log[MS/Q])/(5*(1 + tb^2)*
                      md2[3, 3]) + (2*g1^2*mA^2*tb^2*Log[MS/Q])/(5*(1 + tb^2)*
                      md2[3, 3]) + (4*gb^2*\[Mu]^2*Log[MS/Q])/md2[3, 3] + 
                    (4*gb^2*tb^2*\[Mu]^2*Log[MS/Q])/md2[3, 3] - 
                    (2*g1^2*Log[MS/Q]*md2[1, 1])/(5*md2[3, 3]) - 
                    (2*g1^2*Log[MS/Q]*md2[2, 2])/(5*md2[3, 3]) - 
                    (2*g1^2*Log[MS/Q]*me2[1, 1])/(5*md2[3, 3]) - 
                    (2*g1^2*Log[MS/Q]*me2[2, 2])/(5*md2[3, 3]) - 
                    (2*g1^2*Log[MS/Q]*me2[3, 3])/(5*md2[3, 3]) + 
                    (2*g1^2*Log[MS/Q]*ml2[1, 1])/(5*md2[3, 3]) + 
                    (2*g1^2*Log[MS/Q]*ml2[2, 2])/(5*md2[3, 3]) + 
                    (2*g1^2*Log[MS/Q]*ml2[3, 3])/(5*md2[3, 3]) - 
                    (2*g1^2*Log[MS/Q]*mq2[1, 1])/(5*md2[3, 3]) - 
                    (2*g1^2*Log[MS/Q]*mq2[2, 2])/(5*md2[3, 3]) - 
                    (2*g1^2*Log[MS/Q]*mq2[3, 3])/(5*md2[3, 3]) - 
                    (4*gb^2*Log[MS/Q]*mq2[3, 3])/md2[3, 3] - (4*gb^2*tb^2*
                      Log[MS/Q]*mq2[3, 3])/md2[3, 3] + (4*g1^2*Log[MS/Q]*
                      mu2[1, 1])/(5*md2[3, 3]) + (4*g1^2*Log[MS/Q]*mu2[2, 2])/
                     (5*md2[3, 3]) + (4*g1^2*Log[MS/Q]*mu2[3, 3])/
                     (5*md2[3, 3]) - (4*gb^2*Log[MS/Q]*mu2[3, 3])/md2[3, 3] - 
                    (4*gb^2*tb^2*Log[MS/Q]*mu2[3, 3])/md2[3, 3]))/md2[3, 3])*
                Derivative[1][TCF[2]][Sqrt[mq2[3, 3]/md2[3, 3]]])/(2*
                mq2[3, 3]*Sqrt[md2[3, 3]*mq2[3, 3]])))/12))/
        Sqrt[md2[3, 3]*mq2[3, 3]]) + 
     (3*((-2*gb^2*tb*(Ab - tb*\[Mu])*Cos[2*ArcTan[tb]]*
          (-3*g1^2*\[Mu]*Log[MS/Q] - 15*g2^2*\[Mu]*Log[MS/Q] + 
           30*gb^2*\[Mu]*Log[MS/Q] + 10*gtau^2*\[Mu]*Log[MS/Q] + 
           30*gb^2*tb^2*\[Mu]*Log[MS/Q] + 10*gtau^2*tb^2*\[Mu]*Log[MS/Q])*
          ((-3*g1^2*TCF[3][Sqrt[mq2[3, 3]/md2[3, 3]]])/10 + 
           ((-3*g1^2)/10 - g2^2)*TCF[4][Sqrt[mq2[3, 3]/md2[3, 3]]]))/
         (5*Sqrt[md2[3, 3]*mq2[3, 3]]) + (Ab - tb*\[Mu])^2*
         (-(gb^2*Cos[2*ArcTan[tb]]*(mq2[3, 3]*((-8*g1^2*M1^2*Log[MS/Q])/15 - 
                (32*g3^2*M3^2*Log[MS/Q])/3 + 4*gb^2*mA^2*Log[MS/Q] + 
                (2*g1^2*mA^2*Log[MS/Q])/(5*(1 + tb^2)) - (2*g1^2*mA^2*tb^2*
                  Log[MS/Q])/(5*(1 + tb^2)) + 4*Ab^2*gb^2*(1 + tb^2)*
                 Log[MS/Q] - 4*gb^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q] + 
                (2*g1^2*Log[MS/Q]*md2[1, 1])/5 + (2*g1^2*Log[MS/Q]*md2[2, 2])/
                 5 + (2*g1^2*Log[MS/Q]*md2[3, 3])/5 + (2*g1^2*Log[MS/Q]*
                  me2[1, 1])/5 + (2*g1^2*Log[MS/Q]*me2[2, 2])/5 + 
                (2*g1^2*Log[MS/Q]*me2[3, 3])/5 - (2*g1^2*Log[MS/Q]*ml2[1, 1])/
                 5 - (2*g1^2*Log[MS/Q]*ml2[2, 2])/5 - (2*g1^2*Log[MS/Q]*
                  ml2[3, 3])/5 + (2*g1^2*Log[MS/Q]*mq2[1, 1])/5 + 
                (2*g1^2*Log[MS/Q]*mq2[2, 2])/5 + (2*g1^2*Log[MS/Q]*mq2[3, 3])/
                 5 + 4*gb^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3] - 
                (4*g1^2*Log[MS/Q]*mu2[1, 1])/5 - (4*g1^2*Log[MS/Q]*mu2[2, 2])/
                 5 - (4*g1^2*Log[MS/Q]*mu2[3, 3])/5 + 4*gb^2*(1 + tb^2)*
                 Log[MS/Q]*mu2[3, 3]) + md2[3, 3]*((-2*g1^2*M1^2*Log[MS/Q])/
                 15 - 6*g2^2*M2^2*Log[MS/Q] - (32*g3^2*M3^2*Log[MS/Q])/3 + 
                (2*gt^2*mA^2*Log[MS/Q])/tb^2 + (g1^2*mA^2*Log[MS/Q])/
                 (5*(1 + tb^2)) - (g1^2*mA^2*tb^2*Log[MS/Q])/(5*(1 + tb^2)) + 
                (2*At^2*gt^2*(1 + tb^2)*Log[MS/Q])/tb^2 - (2*gt^2*(1 + tb^2)*
                  \[Mu]^2*Log[MS/Q])/tb^2 + (g1^2*Log[MS/Q]*md2[1, 1])/5 + 
                (g1^2*Log[MS/Q]*md2[2, 2])/5 + (g1^2*Log[MS/Q]*md2[3, 3])/5 + 
                (g1^2*Log[MS/Q]*me2[1, 1])/5 + (g1^2*Log[MS/Q]*me2[2, 2])/5 + 
                (g1^2*Log[MS/Q]*me2[3, 3])/5 - (g1^2*Log[MS/Q]*ml2[1, 1])/5 - 
                (g1^2*Log[MS/Q]*ml2[2, 2])/5 - (g1^2*Log[MS/Q]*ml2[3, 3])/5 + 
                (g1^2*Log[MS/Q]*mq2[1, 1])/5 + (g1^2*Log[MS/Q]*mq2[2, 2])/5 + 
                (g1^2*Log[MS/Q]*mq2[3, 3])/5 + (2*gt^2*(1 + tb^2)*Log[MS/Q]*
                  mq2[3, 3])/tb^2 - (2*g1^2*Log[MS/Q]*mu2[1, 1])/5 - 
                (2*g1^2*Log[MS/Q]*mu2[2, 2])/5 - (2*g1^2*Log[MS/Q]*mu2[3, 3])/
                 5 + (2*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^2))*
             ((-3*g1^2*TCF[3][Sqrt[mq2[3, 3]/md2[3, 3]]])/10 + 
              ((-3*g1^2)/10 - g2^2)*TCF[4][Sqrt[mq2[3, 3]/md2[3, 3]]]))/
           (2*md2[3, 3]*mq2[3, 3]*Sqrt[md2[3, 3]*mq2[3, 3]]) + 
          (((gb*Cos[2*ArcTan[tb]]*(-(g1^2*gb*Log[MS/Q]) - 9*g2^2*gb*
                  Log[MS/Q] - 32*g3^2*gb*Log[MS/Q] + 18*gb^3*Log[MS/Q] + 
                 6*gb*gt^2*Log[MS/Q] + 4*gb*gtau^2*Log[MS/Q]))/2 - 
              (2*gb^2*(-3*gt^2*Log[MS/Q] + 3*gb^2*tb^2*Log[MS/Q] + 
                 gtau^2*tb^2*Log[MS/Q])*Sin[2*ArcTan[tb]])/tb)*
             ((-3*g1^2*TCF[3][Sqrt[mq2[3, 3]/md2[3, 3]]])/10 + 
              ((-3*g1^2)/10 - g2^2)*TCF[4][Sqrt[mq2[3, 3]/md2[3, 3]]]) + 
            gb^2*Cos[2*ArcTan[tb]]*(((-123*g1^4*Log[MS/Q])/50 + 
                (19*g2^4*Log[MS/Q])/3)*TCF[4][Sqrt[mq2[3, 3]/md2[3, 3]]] - 
              (3*((41*g1^4*Log[MS/Q]*TCF[3][Sqrt[mq2[3, 3]/md2[3, 3]]])/5 + 
                 (g1^2*md2[3, 3]*Sqrt[mq2[3, 3]/md2[3, 3]]*
                   (((-2*g1^2*M1^2*Log[MS/Q])/15 - 6*g2^2*M2^2*Log[MS/Q] - 
                      (32*g3^2*M3^2*Log[MS/Q])/3 + (2*gt^2*mA^2*Log[MS/Q])/
                       tb^2 + (g1^2*mA^2*Log[MS/Q])/(5*(1 + tb^2)) - 
                      (g1^2*mA^2*tb^2*Log[MS/Q])/(5*(1 + tb^2)) + 
                      (2*At^2*gt^2*(1 + tb^2)*Log[MS/Q])/tb^2 - 
                      (2*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/tb^2 + 
                      (g1^2*Log[MS/Q]*md2[1, 1])/5 + (g1^2*Log[MS/Q]*
                        md2[2, 2])/5 + (g1^2*Log[MS/Q]*md2[3, 3])/5 + 
                      (g1^2*Log[MS/Q]*me2[1, 1])/5 + (g1^2*Log[MS/Q]*
                        me2[2, 2])/5 + (g1^2*Log[MS/Q]*me2[3, 3])/5 - 
                      (g1^2*Log[MS/Q]*ml2[1, 1])/5 - (g1^2*Log[MS/Q]*
                        ml2[2, 2])/5 - (g1^2*Log[MS/Q]*ml2[3, 3])/5 + 
                      (g1^2*Log[MS/Q]*mq2[1, 1])/5 + (g1^2*Log[MS/Q]*
                        mq2[2, 2])/5 + (g1^2*Log[MS/Q]*mq2[3, 3])/5 + 
                      (2*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3])/tb^2 - 
                      (2*g1^2*Log[MS/Q]*mu2[1, 1])/5 - (2*g1^2*Log[MS/Q]*
                        mu2[2, 2])/5 - (2*g1^2*Log[MS/Q]*mu2[3, 3])/5 + 
                      (2*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^2)/
                     md2[3, 3] + (mq2[3, 3]*((-2*g1^2*Log[MS/Q])/5 - 
                       (4*Ab^2*gb^2*Log[MS/Q])/md2[3, 3] + (8*g1^2*M1^2*
                         Log[MS/Q])/(15*md2[3, 3]) + (32*g3^2*M3^2*Log[MS/Q])/
                        (3*md2[3, 3]) - (4*gb^2*mA^2*Log[MS/Q])/md2[3, 3] - 
                       (4*Ab^2*gb^2*tb^2*Log[MS/Q])/md2[3, 3] - (2*g1^2*mA^2*
                         Log[MS/Q])/(5*(1 + tb^2)*md2[3, 3]) + (2*g1^2*mA^2*
                         tb^2*Log[MS/Q])/(5*(1 + tb^2)*md2[3, 3]) + 
                       (4*gb^2*\[Mu]^2*Log[MS/Q])/md2[3, 3] + (4*gb^2*tb^2*
                         \[Mu]^2*Log[MS/Q])/md2[3, 3] - (2*g1^2*Log[MS/Q]*
                         md2[1, 1])/(5*md2[3, 3]) - (2*g1^2*Log[MS/Q]*
                         md2[2, 2])/(5*md2[3, 3]) - (2*g1^2*Log[MS/Q]*
                         me2[1, 1])/(5*md2[3, 3]) - (2*g1^2*Log[MS/Q]*
                         me2[2, 2])/(5*md2[3, 3]) - (2*g1^2*Log[MS/Q]*
                         me2[3, 3])/(5*md2[3, 3]) + (2*g1^2*Log[MS/Q]*
                         ml2[1, 1])/(5*md2[3, 3]) + (2*g1^2*Log[MS/Q]*
                         ml2[2, 2])/(5*md2[3, 3]) + (2*g1^2*Log[MS/Q]*
                         ml2[3, 3])/(5*md2[3, 3]) - (2*g1^2*Log[MS/Q]*
                         mq2[1, 1])/(5*md2[3, 3]) - (2*g1^2*Log[MS/Q]*
                         mq2[2, 2])/(5*md2[3, 3]) - (2*g1^2*Log[MS/Q]*
                         mq2[3, 3])/(5*md2[3, 3]) - (4*gb^2*Log[MS/Q]*
                         mq2[3, 3])/md2[3, 3] - (4*gb^2*tb^2*Log[MS/Q]*
                         mq2[3, 3])/md2[3, 3] + (4*g1^2*Log[MS/Q]*mu2[1, 1])/
                        (5*md2[3, 3]) + (4*g1^2*Log[MS/Q]*mu2[2, 2])/
                        (5*md2[3, 3]) + (4*g1^2*Log[MS/Q]*mu2[3, 3])/
                        (5*md2[3, 3]) - (4*gb^2*Log[MS/Q]*mu2[3, 3])/
                        md2[3, 3] - (4*gb^2*tb^2*Log[MS/Q]*mu2[3, 3])/
                        md2[3, 3]))/md2[3, 3])*Derivative[1][TCF[3]][
                    Sqrt[mq2[3, 3]/md2[3, 3]]])/(2*mq2[3, 3])))/10 + 
              (((-3*g1^2)/10 - g2^2)*md2[3, 3]*Sqrt[mq2[3, 3]/md2[3, 3]]*
                (((-2*g1^2*M1^2*Log[MS/Q])/15 - 6*g2^2*M2^2*Log[MS/Q] - 
                   (32*g3^2*M3^2*Log[MS/Q])/3 + (2*gt^2*mA^2*Log[MS/Q])/
                    tb^2 + (g1^2*mA^2*Log[MS/Q])/(5*(1 + tb^2)) - 
                   (g1^2*mA^2*tb^2*Log[MS/Q])/(5*(1 + tb^2)) + 
                   (2*At^2*gt^2*(1 + tb^2)*Log[MS/Q])/tb^2 - 
                   (2*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/tb^2 + 
                   (g1^2*Log[MS/Q]*md2[1, 1])/5 + (g1^2*Log[MS/Q]*md2[2, 2])/
                    5 + (g1^2*Log[MS/Q]*md2[3, 3])/5 + (g1^2*Log[MS/Q]*
                     me2[1, 1])/5 + (g1^2*Log[MS/Q]*me2[2, 2])/5 + 
                   (g1^2*Log[MS/Q]*me2[3, 3])/5 - (g1^2*Log[MS/Q]*ml2[1, 1])/
                    5 - (g1^2*Log[MS/Q]*ml2[2, 2])/5 - (g1^2*Log[MS/Q]*
                     ml2[3, 3])/5 + (g1^2*Log[MS/Q]*mq2[1, 1])/5 + 
                   (g1^2*Log[MS/Q]*mq2[2, 2])/5 + (g1^2*Log[MS/Q]*mq2[3, 3])/
                    5 + (2*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3])/tb^2 - 
                   (2*g1^2*Log[MS/Q]*mu2[1, 1])/5 - (2*g1^2*Log[MS/Q]*
                     mu2[2, 2])/5 - (2*g1^2*Log[MS/Q]*mu2[3, 3])/5 + 
                   (2*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^2)/md2[3, 3] + 
                 (mq2[3, 3]*((-2*g1^2*Log[MS/Q])/5 - (4*Ab^2*gb^2*Log[MS/Q])/
                     md2[3, 3] + (8*g1^2*M1^2*Log[MS/Q])/(15*md2[3, 3]) + 
                    (32*g3^2*M3^2*Log[MS/Q])/(3*md2[3, 3]) - (4*gb^2*mA^2*
                      Log[MS/Q])/md2[3, 3] - (4*Ab^2*gb^2*tb^2*Log[MS/Q])/
                     md2[3, 3] - (2*g1^2*mA^2*Log[MS/Q])/(5*(1 + tb^2)*
                      md2[3, 3]) + (2*g1^2*mA^2*tb^2*Log[MS/Q])/(5*(1 + tb^2)*
                      md2[3, 3]) + (4*gb^2*\[Mu]^2*Log[MS/Q])/md2[3, 3] + 
                    (4*gb^2*tb^2*\[Mu]^2*Log[MS/Q])/md2[3, 3] - 
                    (2*g1^2*Log[MS/Q]*md2[1, 1])/(5*md2[3, 3]) - 
                    (2*g1^2*Log[MS/Q]*md2[2, 2])/(5*md2[3, 3]) - 
                    (2*g1^2*Log[MS/Q]*me2[1, 1])/(5*md2[3, 3]) - 
                    (2*g1^2*Log[MS/Q]*me2[2, 2])/(5*md2[3, 3]) - 
                    (2*g1^2*Log[MS/Q]*me2[3, 3])/(5*md2[3, 3]) + 
                    (2*g1^2*Log[MS/Q]*ml2[1, 1])/(5*md2[3, 3]) + 
                    (2*g1^2*Log[MS/Q]*ml2[2, 2])/(5*md2[3, 3]) + 
                    (2*g1^2*Log[MS/Q]*ml2[3, 3])/(5*md2[3, 3]) - 
                    (2*g1^2*Log[MS/Q]*mq2[1, 1])/(5*md2[3, 3]) - 
                    (2*g1^2*Log[MS/Q]*mq2[2, 2])/(5*md2[3, 3]) - 
                    (2*g1^2*Log[MS/Q]*mq2[3, 3])/(5*md2[3, 3]) - 
                    (4*gb^2*Log[MS/Q]*mq2[3, 3])/md2[3, 3] - (4*gb^2*tb^2*
                      Log[MS/Q]*mq2[3, 3])/md2[3, 3] + (4*g1^2*Log[MS/Q]*
                      mu2[1, 1])/(5*md2[3, 3]) + (4*g1^2*Log[MS/Q]*mu2[2, 2])/
                     (5*md2[3, 3]) + (4*g1^2*Log[MS/Q]*mu2[3, 3])/
                     (5*md2[3, 3]) - (4*gb^2*Log[MS/Q]*mu2[3, 3])/md2[3, 3] - 
                    (4*gb^2*tb^2*Log[MS/Q]*mu2[3, 3])/md2[3, 3]))/md2[3, 3])*
                Derivative[1][TCF[4]][Sqrt[mq2[3, 3]/md2[3, 3]]])/(2*
                mq2[3, 3])))/Sqrt[md2[3, 3]*mq2[3, 3]])))/4 + 
     ((2*(3*g1^2 + 5*g2^2)*gb^2*tb*(Ab - tb*\[Mu])*Cos[2*ArcTan[tb]]^2*
         (-3*g1^2*\[Mu]*Log[MS/Q] - 15*g2^2*\[Mu]*Log[MS/Q] + 
          30*gb^2*\[Mu]*Log[MS/Q] + 10*gtau^2*\[Mu]*Log[MS/Q] + 
          30*gb^2*tb^2*\[Mu]*Log[MS/Q] + 10*gtau^2*tb^2*\[Mu]*Log[MS/Q])*
         TCF[5][Sqrt[mq2[3, 3]/md2[3, 3]]])/(5*Sqrt[md2[3, 3]*mq2[3, 3]]) - 
       (Ab - tb*\[Mu])^2*(-((3*g1^2 + 5*g2^2)*gb^2*Cos[2*ArcTan[tb]]^2*
            (mq2[3, 3]*((-8*g1^2*M1^2*Log[MS/Q])/15 - (32*g3^2*M3^2*
                 Log[MS/Q])/3 + 4*gb^2*mA^2*Log[MS/Q] + (2*g1^2*mA^2*
                 Log[MS/Q])/(5*(1 + tb^2)) - (2*g1^2*mA^2*tb^2*Log[MS/Q])/
                (5*(1 + tb^2)) + 4*Ab^2*gb^2*(1 + tb^2)*Log[MS/Q] - 4*gb^2*
                (1 + tb^2)*\[Mu]^2*Log[MS/Q] + (2*g1^2*Log[MS/Q]*md2[1, 1])/
                5 + (2*g1^2*Log[MS/Q]*md2[2, 2])/5 + (2*g1^2*Log[MS/Q]*
                 md2[3, 3])/5 + (2*g1^2*Log[MS/Q]*me2[1, 1])/5 + 
               (2*g1^2*Log[MS/Q]*me2[2, 2])/5 + (2*g1^2*Log[MS/Q]*me2[3, 3])/
                5 - (2*g1^2*Log[MS/Q]*ml2[1, 1])/5 - (2*g1^2*Log[MS/Q]*
                 ml2[2, 2])/5 - (2*g1^2*Log[MS/Q]*ml2[3, 3])/5 + 
               (2*g1^2*Log[MS/Q]*mq2[1, 1])/5 + (2*g1^2*Log[MS/Q]*mq2[2, 2])/
                5 + (2*g1^2*Log[MS/Q]*mq2[3, 3])/5 + 4*gb^2*(1 + tb^2)*
                Log[MS/Q]*mq2[3, 3] - (4*g1^2*Log[MS/Q]*mu2[1, 1])/5 - 
               (4*g1^2*Log[MS/Q]*mu2[2, 2])/5 - (4*g1^2*Log[MS/Q]*mu2[3, 3])/
                5 + 4*gb^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3]) + 
             md2[3, 3]*((-2*g1^2*M1^2*Log[MS/Q])/15 - 6*g2^2*M2^2*Log[MS/Q] - 
               (32*g3^2*M3^2*Log[MS/Q])/3 + (2*gt^2*mA^2*Log[MS/Q])/tb^2 + 
               (g1^2*mA^2*Log[MS/Q])/(5*(1 + tb^2)) - (g1^2*mA^2*tb^2*
                 Log[MS/Q])/(5*(1 + tb^2)) + (2*At^2*gt^2*(1 + tb^2)*
                 Log[MS/Q])/tb^2 - (2*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/
                tb^2 + (g1^2*Log[MS/Q]*md2[1, 1])/5 + (g1^2*Log[MS/Q]*
                 md2[2, 2])/5 + (g1^2*Log[MS/Q]*md2[3, 3])/5 + 
               (g1^2*Log[MS/Q]*me2[1, 1])/5 + (g1^2*Log[MS/Q]*me2[2, 2])/5 + 
               (g1^2*Log[MS/Q]*me2[3, 3])/5 - (g1^2*Log[MS/Q]*ml2[1, 1])/5 - 
               (g1^2*Log[MS/Q]*ml2[2, 2])/5 - (g1^2*Log[MS/Q]*ml2[3, 3])/5 + 
               (g1^2*Log[MS/Q]*mq2[1, 1])/5 + (g1^2*Log[MS/Q]*mq2[2, 2])/5 + 
               (g1^2*Log[MS/Q]*mq2[3, 3])/5 + (2*gt^2*(1 + tb^2)*Log[MS/Q]*
                 mq2[3, 3])/tb^2 - (2*g1^2*Log[MS/Q]*mu2[1, 1])/5 - 
               (2*g1^2*Log[MS/Q]*mu2[2, 2])/5 - (2*g1^2*Log[MS/Q]*mu2[3, 3])/
                5 + (2*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^2))*
            TCF[5][Sqrt[mq2[3, 3]/md2[3, 3]]])/(2*md2[3, 3]*mq2[3, 3]*
           Sqrt[md2[3, 3]*mq2[3, 3]]) + 
         ((gb^2*Cos[2*ArcTan[tb]]^2*((123*g1^4*Log[MS/Q])/5 - (95*g2^4*
                 Log[MS/Q])/3) + (3*g1^2 + 5*g2^2)*((gb*Cos[2*ArcTan[tb]]^2*
                 (-(g1^2*gb*Log[MS/Q]) - 9*g2^2*gb*Log[MS/Q] - 32*g3^2*gb*
                   Log[MS/Q] + 18*gb^3*Log[MS/Q] + 6*gb*gt^2*Log[MS/Q] + 
                  4*gb*gtau^2*Log[MS/Q]))/2 - (4*gb^2*Cos[2*ArcTan[tb]]*
                 (-3*gt^2*Log[MS/Q] + 3*gb^2*tb^2*Log[MS/Q] + gtau^2*tb^2*
                   Log[MS/Q])*Sin[2*ArcTan[tb]])/tb))*
            TCF[5][Sqrt[mq2[3, 3]/md2[3, 3]]] + ((3*g1^2 + 5*g2^2)*gb^2*
             Cos[2*ArcTan[tb]]^2*md2[3, 3]*Sqrt[mq2[3, 3]/md2[3, 3]]*
             (((-2*g1^2*M1^2*Log[MS/Q])/15 - 6*g2^2*M2^2*Log[MS/Q] - 
                (32*g3^2*M3^2*Log[MS/Q])/3 + (2*gt^2*mA^2*Log[MS/Q])/tb^2 + 
                (g1^2*mA^2*Log[MS/Q])/(5*(1 + tb^2)) - (g1^2*mA^2*tb^2*
                  Log[MS/Q])/(5*(1 + tb^2)) + (2*At^2*gt^2*(1 + tb^2)*
                  Log[MS/Q])/tb^2 - (2*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/
                 tb^2 + (g1^2*Log[MS/Q]*md2[1, 1])/5 + (g1^2*Log[MS/Q]*
                  md2[2, 2])/5 + (g1^2*Log[MS/Q]*md2[3, 3])/5 + 
                (g1^2*Log[MS/Q]*me2[1, 1])/5 + (g1^2*Log[MS/Q]*me2[2, 2])/5 + 
                (g1^2*Log[MS/Q]*me2[3, 3])/5 - (g1^2*Log[MS/Q]*ml2[1, 1])/5 - 
                (g1^2*Log[MS/Q]*ml2[2, 2])/5 - (g1^2*Log[MS/Q]*ml2[3, 3])/5 + 
                (g1^2*Log[MS/Q]*mq2[1, 1])/5 + (g1^2*Log[MS/Q]*mq2[2, 2])/5 + 
                (g1^2*Log[MS/Q]*mq2[3, 3])/5 + (2*gt^2*(1 + tb^2)*Log[MS/Q]*
                  mq2[3, 3])/tb^2 - (2*g1^2*Log[MS/Q]*mu2[1, 1])/5 - 
                (2*g1^2*Log[MS/Q]*mu2[2, 2])/5 - (2*g1^2*Log[MS/Q]*mu2[3, 3])/
                 5 + (2*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^2)/md2[3, 
                3] + (mq2[3, 3]*((-2*g1^2*Log[MS/Q])/5 - (4*Ab^2*gb^2*
                   Log[MS/Q])/md2[3, 3] + (8*g1^2*M1^2*Log[MS/Q])/
                  (15*md2[3, 3]) + (32*g3^2*M3^2*Log[MS/Q])/(3*md2[3, 3]) - 
                 (4*gb^2*mA^2*Log[MS/Q])/md2[3, 3] - (4*Ab^2*gb^2*tb^2*
                   Log[MS/Q])/md2[3, 3] - (2*g1^2*mA^2*Log[MS/Q])/
                  (5*(1 + tb^2)*md2[3, 3]) + (2*g1^2*mA^2*tb^2*Log[MS/Q])/
                  (5*(1 + tb^2)*md2[3, 3]) + (4*gb^2*\[Mu]^2*Log[MS/Q])/
                  md2[3, 3] + (4*gb^2*tb^2*\[Mu]^2*Log[MS/Q])/md2[3, 3] - 
                 (2*g1^2*Log[MS/Q]*md2[1, 1])/(5*md2[3, 3]) - 
                 (2*g1^2*Log[MS/Q]*md2[2, 2])/(5*md2[3, 3]) - 
                 (2*g1^2*Log[MS/Q]*me2[1, 1])/(5*md2[3, 3]) - 
                 (2*g1^2*Log[MS/Q]*me2[2, 2])/(5*md2[3, 3]) - 
                 (2*g1^2*Log[MS/Q]*me2[3, 3])/(5*md2[3, 3]) + 
                 (2*g1^2*Log[MS/Q]*ml2[1, 1])/(5*md2[3, 3]) + 
                 (2*g1^2*Log[MS/Q]*ml2[2, 2])/(5*md2[3, 3]) + 
                 (2*g1^2*Log[MS/Q]*ml2[3, 3])/(5*md2[3, 3]) - 
                 (2*g1^2*Log[MS/Q]*mq2[1, 1])/(5*md2[3, 3]) - 
                 (2*g1^2*Log[MS/Q]*mq2[2, 2])/(5*md2[3, 3]) - 
                 (2*g1^2*Log[MS/Q]*mq2[3, 3])/(5*md2[3, 3]) - 
                 (4*gb^2*Log[MS/Q]*mq2[3, 3])/md2[3, 3] - (4*gb^2*tb^2*
                   Log[MS/Q]*mq2[3, 3])/md2[3, 3] + (4*g1^2*Log[MS/Q]*
                   mu2[1, 1])/(5*md2[3, 3]) + (4*g1^2*Log[MS/Q]*mu2[2, 2])/
                  (5*md2[3, 3]) + (4*g1^2*Log[MS/Q]*mu2[3, 3])/
                  (5*md2[3, 3]) - (4*gb^2*Log[MS/Q]*mu2[3, 3])/md2[3, 3] - 
                 (4*gb^2*tb^2*Log[MS/Q]*mu2[3, 3])/md2[3, 3]))/md2[3, 3])*
             Derivative[1][TCF[5]][Sqrt[mq2[3, 3]/md2[3, 3]]])/(2*mq2[3, 3]))/
          Sqrt[md2[3, 3]*mq2[3, 3]]))/20)/(16*Pi^2) + 
   ((Cos[2*ArcTan[tb]]^2*((1476*g1^6*Log[MS/Q]*(Log[me2[1, 1]/Q^2] + 
            Log[me2[2, 2]/Q^2] + Log[me2[3, 3]/Q^2]))/5 + 
         (2*(1107*g1^6*Log[MS/Q] - 2375*g2^6*Log[MS/Q])*(Log[ml2[1, 1]/Q^2] + 
            Log[ml2[2, 2]/Q^2] + Log[ml2[3, 3]/Q^2]))/15 + 
         6*((82*g1^6*Log[MS/Q]*(Log[md2[1, 1]/Q^2] + Log[md2[2, 2]/Q^2] + 
              Log[md2[3, 3]/Q^2]))/5 + (g1^4*((-8*g1^2*M1^2*Log[MS/Q])/15 - 
              (32*g3^2*M3^2*Log[MS/Q])/3 + 4*gb^2*mA^2*Log[MS/Q] + 
              (2*g1^2*mA^2*Log[MS/Q])/(5*(1 + tb^2)) - (2*g1^2*mA^2*tb^2*
                Log[MS/Q])/(5*(1 + tb^2)) + 4*Ab^2*gb^2*(1 + tb^2)*Log[
                MS/Q] - 4*gb^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q] + 
              (2*g1^2*Log[MS/Q]*md2[1, 1])/5 + (2*g1^2*Log[MS/Q]*md2[2, 2])/
               5 + (2*g1^2*Log[MS/Q]*md2[3, 3])/5 + (2*g1^2*Log[MS/Q]*
                me2[1, 1])/5 + (2*g1^2*Log[MS/Q]*me2[2, 2])/5 + 
              (2*g1^2*Log[MS/Q]*me2[3, 3])/5 - (2*g1^2*Log[MS/Q]*ml2[1, 1])/
               5 - (2*g1^2*Log[MS/Q]*ml2[2, 2])/5 - (2*g1^2*Log[MS/Q]*
                ml2[3, 3])/5 + (2*g1^2*Log[MS/Q]*mq2[1, 1])/5 + 
              (2*g1^2*Log[MS/Q]*mq2[2, 2])/5 + (2*g1^2*Log[MS/Q]*mq2[3, 3])/
               5 + 4*gb^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3] - (4*g1^2*Log[MS/Q]*
                mu2[1, 1])/5 - (4*g1^2*Log[MS/Q]*mu2[2, 2])/5 - 
              (4*g1^2*Log[MS/Q]*mu2[3, 3])/5 + 4*gb^2*(1 + tb^2)*Log[MS/Q]*
               mu2[3, 3]))/md2[3, 3]) + 
         3*(((82*g1^6*Log[MS/Q])/5 - (950*g2^6*Log[MS/Q])/3)*
            (Log[mq2[1, 1]/Q^2] + Log[mq2[2, 2]/Q^2] + Log[mq2[3, 3]/Q^2]) + 
           ((g1^4 + 25*g2^4)*((-2*g1^2*M1^2*Log[MS/Q])/15 - 6*g2^2*M2^2*Log[
                MS/Q] - (32*g3^2*M3^2*Log[MS/Q])/3 + (2*gt^2*mA^2*Log[MS/Q])/
               tb^2 + (g1^2*mA^2*Log[MS/Q])/(5*(1 + tb^2)) - (g1^2*mA^2*tb^2*
                Log[MS/Q])/(5*(1 + tb^2)) + (2*At^2*gt^2*(1 + tb^2)*
                Log[MS/Q])/tb^2 - (2*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/tb^
                2 + (g1^2*Log[MS/Q]*md2[1, 1])/5 + (g1^2*Log[MS/Q]*md2[2, 2])/
               5 + (g1^2*Log[MS/Q]*md2[3, 3])/5 + (g1^2*Log[MS/Q]*me2[1, 1])/
               5 + (g1^2*Log[MS/Q]*me2[2, 2])/5 + (g1^2*Log[MS/Q]*me2[3, 3])/
               5 - (g1^2*Log[MS/Q]*ml2[1, 1])/5 - (g1^2*Log[MS/Q]*ml2[2, 2])/
               5 - (g1^2*Log[MS/Q]*ml2[3, 3])/5 + (g1^2*Log[MS/Q]*mq2[1, 1])/
               5 + (g1^2*Log[MS/Q]*mq2[2, 2])/5 + (g1^2*Log[MS/Q]*mq2[3, 3])/
               5 + (2*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3])/tb^2 - 
              (2*g1^2*Log[MS/Q]*mu2[1, 1])/5 - (2*g1^2*Log[MS/Q]*mu2[2, 2])/
               5 - (2*g1^2*Log[MS/Q]*mu2[3, 3])/5 + (2*gt^2*(1 + tb^2)*
                Log[MS/Q]*mu2[3, 3])/tb^2))/mq2[3, 3]) + 
         24*((82*g1^6*Log[MS/Q]*(Log[mu2[1, 1]/Q^2] + Log[mu2[2, 2]/Q^2] + 
              Log[mu2[3, 3]/Q^2]))/5 + (g1^4*((-32*g1^2*M1^2*Log[MS/Q])/15 - 
              (32*g3^2*M3^2*Log[MS/Q])/3 + (4*gt^2*mA^2*Log[MS/Q])/tb^2 - 
              (4*g1^2*mA^2*Log[MS/Q])/(5*(1 + tb^2)) + (4*g1^2*mA^2*tb^2*
                Log[MS/Q])/(5*(1 + tb^2)) + (4*At^2*gt^2*(1 + tb^2)*
                Log[MS/Q])/tb^2 - (4*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/tb^
                2 - (4*g1^2*Log[MS/Q]*md2[1, 1])/5 - (4*g1^2*Log[MS/Q]*
                md2[2, 2])/5 - (4*g1^2*Log[MS/Q]*md2[3, 3])/5 - 
              (4*g1^2*Log[MS/Q]*me2[1, 1])/5 - (4*g1^2*Log[MS/Q]*me2[2, 2])/
               5 - (4*g1^2*Log[MS/Q]*me2[3, 3])/5 + (4*g1^2*Log[MS/Q]*
                ml2[1, 1])/5 + (4*g1^2*Log[MS/Q]*ml2[2, 2])/5 + 
              (4*g1^2*Log[MS/Q]*ml2[3, 3])/5 - (4*g1^2*Log[MS/Q]*mq2[1, 1])/
               5 - (4*g1^2*Log[MS/Q]*mq2[2, 2])/5 - (4*g1^2*Log[MS/Q]*
                mq2[3, 3])/5 + (4*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3])/tb^2 + 
              (8*g1^2*Log[MS/Q]*mu2[1, 1])/5 + (8*g1^2*Log[MS/Q]*mu2[2, 2])/
               5 + (8*g1^2*Log[MS/Q]*mu2[3, 3])/5 + (4*gt^2*(1 + tb^2)*
                Log[MS/Q]*mu2[3, 3])/tb^2))/mu2[3, 3])) - 
       (4*Cos[2*ArcTan[tb]]*(-3*gt^2*Log[MS/Q] + 3*gb^2*tb^2*Log[MS/Q] + 
          gtau^2*tb^2*Log[MS/Q])*(6*g1^4*(Log[md2[1, 1]/Q^2] + 
            Log[md2[2, 2]/Q^2] + Log[md2[3, 3]/Q^2]) + 
          18*g1^4*(Log[me2[1, 1]/Q^2] + Log[me2[2, 2]/Q^2] + 
            Log[me2[3, 3]/Q^2]) + (9*g1^4 + 25*g2^4)*(Log[ml2[1, 1]/Q^2] + 
            Log[ml2[2, 2]/Q^2] + Log[ml2[3, 3]/Q^2]) + 3*(g1^4 + 25*g2^4)*
           (Log[mq2[1, 1]/Q^2] + Log[mq2[2, 2]/Q^2] + Log[mq2[3, 3]/Q^2]) + 
          24*g1^4*(Log[mu2[1, 1]/Q^2] + Log[mu2[2, 2]/Q^2] + 
            Log[mu2[3, 3]/Q^2]))*Sin[2*ArcTan[tb]])/tb)/300 + 
     3*((gt^2*(gt^2 + (2*g1^2*Cos[2*ArcTan[tb]])/5)*
         ((-32*g1^2*M1^2*Log[MS/Q])/15 - (32*g3^2*M3^2*Log[MS/Q])/3 + 
          (4*gt^2*mA^2*Log[MS/Q])/tb^2 - (4*g1^2*mA^2*Log[MS/Q])/
           (5*(1 + tb^2)) + (4*g1^2*mA^2*tb^2*Log[MS/Q])/(5*(1 + tb^2)) + 
          (4*At^2*gt^2*(1 + tb^2)*Log[MS/Q])/tb^2 - 
          (4*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/tb^2 - 
          (4*g1^2*Log[MS/Q]*md2[1, 1])/5 - (4*g1^2*Log[MS/Q]*md2[2, 2])/5 - 
          (4*g1^2*Log[MS/Q]*md2[3, 3])/5 - (4*g1^2*Log[MS/Q]*me2[1, 1])/5 - 
          (4*g1^2*Log[MS/Q]*me2[2, 2])/5 - (4*g1^2*Log[MS/Q]*me2[3, 3])/5 + 
          (4*g1^2*Log[MS/Q]*ml2[1, 1])/5 + (4*g1^2*Log[MS/Q]*ml2[2, 2])/5 + 
          (4*g1^2*Log[MS/Q]*ml2[3, 3])/5 - (4*g1^2*Log[MS/Q]*mq2[1, 1])/5 - 
          (4*g1^2*Log[MS/Q]*mq2[2, 2])/5 - (4*g1^2*Log[MS/Q]*mq2[3, 3])/5 + 
          (4*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3])/tb^2 + 
          (8*g1^2*Log[MS/Q]*mu2[1, 1])/5 + (8*g1^2*Log[MS/Q]*mu2[2, 2])/5 + 
          (8*g1^2*Log[MS/Q]*mu2[3, 3])/5 + (4*gt^2*(1 + tb^2)*Log[MS/Q]*
            mu2[3, 3])/tb^2))/mu2[3, 3] + Log[mu2[3, 3]/Q^2]*
        ((gt*(gt^2 + (2*g1^2*Cos[2*ArcTan[tb]])/5)*(-17*g1^2*gt*Log[MS/Q] - 
            45*g2^2*gt*Log[MS/Q] - 160*g3^2*gt*Log[MS/Q] + 
            30*gb^2*gt*Log[MS/Q] + 90*gt^3*Log[MS/Q] + 20*gt*gtau^2*
             Log[MS/Q]))/10 + gt^2*((gt*(-17*g1^2*gt*Log[MS/Q] - 
              45*g2^2*gt*Log[MS/Q] - 160*g3^2*gt*Log[MS/Q] + 30*gb^2*gt*Log[
                MS/Q] + 90*gt^3*Log[MS/Q] + 20*gt*gtau^2*Log[MS/Q]))/10 + 
           (2*((41*g1^4*Cos[2*ArcTan[tb]]*Log[MS/Q])/5 - (2*g1^2*
                (-3*gt^2*Log[MS/Q] + 3*gb^2*tb^2*Log[MS/Q] + gtau^2*tb^2*
                  Log[MS/Q])*Sin[2*ArcTan[tb]])/tb))/5))) + 
     3*((gt^2*(gt^2 - ((g1^2 - 5*g2^2)*Cos[2*ArcTan[tb]])/10)*
         ((-2*g1^2*M1^2*Log[MS/Q])/15 - 6*g2^2*M2^2*Log[MS/Q] - 
          (32*g3^2*M3^2*Log[MS/Q])/3 + (2*gt^2*mA^2*Log[MS/Q])/tb^2 + 
          (g1^2*mA^2*Log[MS/Q])/(5*(1 + tb^2)) - (g1^2*mA^2*tb^2*Log[MS/Q])/
           (5*(1 + tb^2)) + (2*At^2*gt^2*(1 + tb^2)*Log[MS/Q])/tb^2 - 
          (2*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/tb^2 + 
          (g1^2*Log[MS/Q]*md2[1, 1])/5 + (g1^2*Log[MS/Q]*md2[2, 2])/5 + 
          (g1^2*Log[MS/Q]*md2[3, 3])/5 + (g1^2*Log[MS/Q]*me2[1, 1])/5 + 
          (g1^2*Log[MS/Q]*me2[2, 2])/5 + (g1^2*Log[MS/Q]*me2[3, 3])/5 - 
          (g1^2*Log[MS/Q]*ml2[1, 1])/5 - (g1^2*Log[MS/Q]*ml2[2, 2])/5 - 
          (g1^2*Log[MS/Q]*ml2[3, 3])/5 + (g1^2*Log[MS/Q]*mq2[1, 1])/5 + 
          (g1^2*Log[MS/Q]*mq2[2, 2])/5 + (g1^2*Log[MS/Q]*mq2[3, 3])/5 + 
          (2*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3])/tb^2 - 
          (2*g1^2*Log[MS/Q]*mu2[1, 1])/5 - (2*g1^2*Log[MS/Q]*mu2[2, 2])/5 - 
          (2*g1^2*Log[MS/Q]*mu2[3, 3])/5 + (2*gt^2*(1 + tb^2)*Log[MS/Q]*
            mu2[3, 3])/tb^2))/mq2[3, 3] + Log[mq2[3, 3]/Q^2]*
        ((gt*(gt^2 - ((g1^2 - 5*g2^2)*Cos[2*ArcTan[tb]])/10)*
           (-17*g1^2*gt*Log[MS/Q] - 45*g2^2*gt*Log[MS/Q] - 
            160*g3^2*gt*Log[MS/Q] + 30*gb^2*gt*Log[MS/Q] + 
            90*gt^3*Log[MS/Q] + 20*gt*gtau^2*Log[MS/Q]))/10 + 
         gt^2*((gt*(-17*g1^2*gt*Log[MS/Q] - 45*g2^2*gt*Log[MS/Q] - 
              160*g3^2*gt*Log[MS/Q] + 30*gb^2*gt*Log[MS/Q] + 
              90*gt^3*Log[MS/Q] + 20*gt*gtau^2*Log[MS/Q]))/10 + 
           (Cos[2*ArcTan[tb]]*((-41*g1^4*Log[MS/Q])/25 - (19*g2^4*Log[MS/Q])/
                3) - (2*(-g1^2/5 + g2^2)*(-3*gt^2*Log[MS/Q] + 3*gb^2*tb^2*
                 Log[MS/Q] + gtau^2*tb^2*Log[MS/Q])*Sin[2*ArcTan[tb]])/tb)/
            2))) - (3*((8*((9*g1^4)/25 + (6*g1^2*g2^2)/5 + g2^4)*
          Cos[4*ArcTan[tb]]*(-3*gt^2*Log[MS/Q] + 3*gb^2*tb^2*Log[MS/Q] + 
           gtau^2*tb^2*Log[MS/Q])*Sin[4*ArcTan[tb]])/tb + 
        (2*(1107*g1^6*Log[MS/Q] + 1845*g1^4*g2^2*Log[MS/Q] - 
           1425*g1^2*g2^4*Log[MS/Q] - 2375*g2^6*Log[MS/Q])*
          Sin[4*ArcTan[tb]]^2)/375))/16 + 
     (Log[mA^2/Q^2]*((21402*g1^6*Log[MS/Q])/5 + 5166*g1^4*g2^2*Log[MS/Q] - 
        3990*g1^2*g2^4*Log[MS/Q] - (50350*g2^6*Log[MS/Q])/3 - 
        4*(Cos[4*ArcTan[tb]]*((738*g1^6*Log[MS/Q])/5 + 738*g1^4*g2^2*
             Log[MS/Q] - 570*g1^2*g2^4*Log[MS/Q] - (6650*g2^6*Log[MS/Q])/3) - 
          (4*(9*g1^4 + 90*g1^2*g2^2 + 175*g2^4)*(-3*gt^2*Log[MS/Q] + 
             3*gb^2*tb^2*Log[MS/Q] + gtau^2*tb^2*Log[MS/Q])*
            Sin[4*ArcTan[tb]])/tb) - 
        9*(Cos[8*ArcTan[tb]]*((738*g1^6*Log[MS/Q])/5 + 246*g1^4*g2^2*
             Log[MS/Q] - 190*g1^2*g2^4*Log[MS/Q] - (950*g2^6*Log[MS/Q])/3) - 
          (8*(9*g1^4 + 30*g1^2*g2^2 + 25*g2^4)*(-3*gt^2*Log[MS/Q] + 
             3*gb^2*tb^2*Log[MS/Q] + gtau^2*tb^2*Log[MS/Q])*
            Sin[8*ArcTan[tb]])/tb)))/4800 + 
     6*(((2*gt^4*(At - \[Mu]/tb)*((26*g2^2*M1*Log[MS/Q])/15 + 
            6*g2^2*M2*Log[MS/Q] + (32*g3^2*M3*Log[MS/Q])/3 + 
            (12*At*gt^2*(1 + tb^2)*Log[MS/Q])/tb^2 - 
            (3*(10*gt^2*\[Mu]*Log[MS/Q] - g1^2*tb^2*\[Mu]*Log[MS/Q] - 5*g2^2*
                tb^2*\[Mu]*Log[MS/Q] + 10*gt^2*tb^2*\[Mu]*Log[MS/Q]))/
             (5*tb^3)))/Sqrt[mq2[3, 3]*mu2[3, 3]] + (At - \[Mu]/tb)^2*
          ((gt^3*(-17*g1^2*gt*Log[MS/Q] - 45*g2^2*gt*Log[MS/Q] - 
              160*g3^2*gt*Log[MS/Q] + 30*gb^2*gt*Log[MS/Q] + 
              90*gt^3*Log[MS/Q] + 20*gt*gtau^2*Log[MS/Q]))/
            (5*Sqrt[mq2[3, 3]*mu2[3, 3]]) - 
           (gt^4*(mu2[3, 3]*((-2*g1^2*M1^2*Log[MS/Q])/15 - 6*g2^2*M2^2*
                 Log[MS/Q] - (32*g3^2*M3^2*Log[MS/Q])/3 + (2*gt^2*mA^2*
                  Log[MS/Q])/tb^2 + (g1^2*mA^2*Log[MS/Q])/(5*(1 + tb^2)) - 
                (g1^2*mA^2*tb^2*Log[MS/Q])/(5*(1 + tb^2)) + 
                (2*At^2*gt^2*(1 + tb^2)*Log[MS/Q])/tb^2 - (2*gt^2*(1 + tb^2)*
                  \[Mu]^2*Log[MS/Q])/tb^2 + (g1^2*Log[MS/Q]*md2[1, 1])/5 + 
                (g1^2*Log[MS/Q]*md2[2, 2])/5 + (g1^2*Log[MS/Q]*md2[3, 3])/5 + 
                (g1^2*Log[MS/Q]*me2[1, 1])/5 + (g1^2*Log[MS/Q]*me2[2, 2])/5 + 
                (g1^2*Log[MS/Q]*me2[3, 3])/5 - (g1^2*Log[MS/Q]*ml2[1, 1])/5 - 
                (g1^2*Log[MS/Q]*ml2[2, 2])/5 - (g1^2*Log[MS/Q]*ml2[3, 3])/5 + 
                (g1^2*Log[MS/Q]*mq2[1, 1])/5 + (g1^2*Log[MS/Q]*mq2[2, 2])/5 + 
                (g1^2*Log[MS/Q]*mq2[3, 3])/5 + (2*gt^2*(1 + tb^2)*Log[MS/Q]*
                  mq2[3, 3])/tb^2 - (2*g1^2*Log[MS/Q]*mu2[1, 1])/5 - 
                (2*g1^2*Log[MS/Q]*mu2[2, 2])/5 - (2*g1^2*Log[MS/Q]*mu2[3, 3])/
                 5 + (2*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^2) + 
              mq2[3, 3]*((-32*g1^2*M1^2*Log[MS/Q])/15 - (32*g3^2*M3^2*
                  Log[MS/Q])/3 + (4*gt^2*mA^2*Log[MS/Q])/tb^2 - 
                (4*g1^2*mA^2*Log[MS/Q])/(5*(1 + tb^2)) + (4*g1^2*mA^2*tb^2*
                  Log[MS/Q])/(5*(1 + tb^2)) + (4*At^2*gt^2*(1 + tb^2)*
                  Log[MS/Q])/tb^2 - (4*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/
                 tb^2 - (4*g1^2*Log[MS/Q]*md2[1, 1])/5 - (4*g1^2*Log[MS/Q]*
                  md2[2, 2])/5 - (4*g1^2*Log[MS/Q]*md2[3, 3])/5 - 
                (4*g1^2*Log[MS/Q]*me2[1, 1])/5 - (4*g1^2*Log[MS/Q]*me2[2, 2])/
                 5 - (4*g1^2*Log[MS/Q]*me2[3, 3])/5 + (4*g1^2*Log[MS/Q]*
                  ml2[1, 1])/5 + (4*g1^2*Log[MS/Q]*ml2[2, 2])/5 + 
                (4*g1^2*Log[MS/Q]*ml2[3, 3])/5 - (4*g1^2*Log[MS/Q]*mq2[1, 1])/
                 5 - (4*g1^2*Log[MS/Q]*mq2[2, 2])/5 - (4*g1^2*Log[MS/Q]*
                  mq2[3, 3])/5 + (4*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3])/
                 tb^2 + (8*g1^2*Log[MS/Q]*mu2[1, 1])/5 + (8*g1^2*Log[MS/Q]*
                  mu2[2, 2])/5 + (8*g1^2*Log[MS/Q]*mu2[3, 3])/5 + 
                (4*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^2)))/
            (2*mq2[3, 3]*mu2[3, 3]*Sqrt[mq2[3, 3]*mu2[3, 3]])))*
        (TCF[1][Sqrt[mq2[3, 3]/mu2[3, 3]]] - 
         ((At - \[Mu]/tb)^2*TCF[2][Sqrt[mq2[3, 3]/mu2[3, 3]]])/
          (12*Sqrt[mq2[3, 3]*mu2[3, 3]])) + 
       (gt^4*(At - \[Mu]/tb)^2*((Sqrt[mq2[3, 3]/mu2[3, 3]]*mu2[3, 3]*
            ((mq2[3, 3]*((-8*g1^2*Log[MS/Q])/5 - 4*gt^2*Log[MS/Q] - 
                (4*gt^2*Log[MS/Q])/tb^2 - (4*At^2*gt^2*Log[MS/Q])/mu2[3, 3] + 
                (32*g1^2*M1^2*Log[MS/Q])/(15*mu2[3, 3]) + (32*g3^2*M3^2*
                  Log[MS/Q])/(3*mu2[3, 3]) - (4*At^2*gt^2*Log[MS/Q])/
                 (tb^2*mu2[3, 3]) - (4*gt^2*mA^2*Log[MS/Q])/(tb^2*
                  mu2[3, 3]) + (4*g1^2*mA^2*Log[MS/Q])/(5*(1 + tb^2)*
                  mu2[3, 3]) - (4*g1^2*mA^2*tb^2*Log[MS/Q])/(5*(1 + tb^2)*
                  mu2[3, 3]) + (4*gt^2*\[Mu]^2*Log[MS/Q])/mu2[3, 3] + 
                (4*gt^2*\[Mu]^2*Log[MS/Q])/(tb^2*mu2[3, 3]) + 
                (4*g1^2*Log[MS/Q]*md2[1, 1])/(5*mu2[3, 3]) + 
                (4*g1^2*Log[MS/Q]*md2[2, 2])/(5*mu2[3, 3]) + 
                (4*g1^2*Log[MS/Q]*md2[3, 3])/(5*mu2[3, 3]) + 
                (4*g1^2*Log[MS/Q]*me2[1, 1])/(5*mu2[3, 3]) + 
                (4*g1^2*Log[MS/Q]*me2[2, 2])/(5*mu2[3, 3]) + 
                (4*g1^2*Log[MS/Q]*me2[3, 3])/(5*mu2[3, 3]) - 
                (4*g1^2*Log[MS/Q]*ml2[1, 1])/(5*mu2[3, 3]) - 
                (4*g1^2*Log[MS/Q]*ml2[2, 2])/(5*mu2[3, 3]) - 
                (4*g1^2*Log[MS/Q]*ml2[3, 3])/(5*mu2[3, 3]) + 
                (4*g1^2*Log[MS/Q]*mq2[1, 1])/(5*mu2[3, 3]) + 
                (4*g1^2*Log[MS/Q]*mq2[2, 2])/(5*mu2[3, 3]) + 
                (4*g1^2*Log[MS/Q]*mq2[3, 3])/(5*mu2[3, 3]) - 
                (4*gt^2*Log[MS/Q]*mq2[3, 3])/mu2[3, 3] - (4*gt^2*Log[MS/Q]*
                  mq2[3, 3])/(tb^2*mu2[3, 3]) - (8*g1^2*Log[MS/Q]*mu2[1, 1])/
                 (5*mu2[3, 3]) - (8*g1^2*Log[MS/Q]*mu2[2, 2])/(5*mu2[3, 3])))/
              mu2[3, 3] + ((-2*g1^2*M1^2*Log[MS/Q])/15 - 6*g2^2*M2^2*
                Log[MS/Q] - (32*g3^2*M3^2*Log[MS/Q])/3 + (2*gt^2*mA^2*
                 Log[MS/Q])/tb^2 + (g1^2*mA^2*Log[MS/Q])/(5*(1 + tb^2)) - 
               (g1^2*mA^2*tb^2*Log[MS/Q])/(5*(1 + tb^2)) + (2*At^2*gt^2*
                 (1 + tb^2)*Log[MS/Q])/tb^2 - (2*gt^2*(1 + tb^2)*\[Mu]^2*
                 Log[MS/Q])/tb^2 + (g1^2*Log[MS/Q]*md2[1, 1])/5 + 
               (g1^2*Log[MS/Q]*md2[2, 2])/5 + (g1^2*Log[MS/Q]*md2[3, 3])/5 + 
               (g1^2*Log[MS/Q]*me2[1, 1])/5 + (g1^2*Log[MS/Q]*me2[2, 2])/5 + 
               (g1^2*Log[MS/Q]*me2[3, 3])/5 - (g1^2*Log[MS/Q]*ml2[1, 1])/5 - 
               (g1^2*Log[MS/Q]*ml2[2, 2])/5 - (g1^2*Log[MS/Q]*ml2[3, 3])/5 + 
               (g1^2*Log[MS/Q]*mq2[1, 1])/5 + (g1^2*Log[MS/Q]*mq2[2, 2])/5 + 
               (g1^2*Log[MS/Q]*mq2[3, 3])/5 + (2*gt^2*(1 + tb^2)*Log[MS/Q]*
                 mq2[3, 3])/tb^2 - (2*g1^2*Log[MS/Q]*mu2[1, 1])/5 - 
               (2*g1^2*Log[MS/Q]*mu2[2, 2])/5 - (2*g1^2*Log[MS/Q]*mu2[3, 3])/
                5 + (2*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^2)/mu2[3, 3])*
            Derivative[1][TCF[1]][Sqrt[mq2[3, 3]/mu2[3, 3]]])/(2*mq2[3, 3]) + 
          ((-2*(At - \[Mu]/tb)*((26*g2^2*M1*Log[MS/Q])/15 + 6*g2^2*M2*
                Log[MS/Q] + (32*g3^2*M3*Log[MS/Q])/3 + (12*At*gt^2*(1 + tb^2)*
                 Log[MS/Q])/tb^2 - (3*(10*gt^2*\[Mu]*Log[MS/Q] - g1^2*tb^2*
                   \[Mu]*Log[MS/Q] - 5*g2^2*tb^2*\[Mu]*Log[MS/Q] + 
                  10*gt^2*tb^2*\[Mu]*Log[MS/Q]))/(5*tb^3))*TCF[2][Sqrt[
                mq2[3, 3]/mu2[3, 3]]])/Sqrt[mq2[3, 3]*mu2[3, 3]] - 
            (At - \[Mu]/tb)^2*(-((mu2[3, 3]*((-2*g1^2*M1^2*Log[MS/Q])/15 - 
                    6*g2^2*M2^2*Log[MS/Q] - (32*g3^2*M3^2*Log[MS/Q])/3 + 
                    (2*gt^2*mA^2*Log[MS/Q])/tb^2 + (g1^2*mA^2*Log[MS/Q])/
                     (5*(1 + tb^2)) - (g1^2*mA^2*tb^2*Log[MS/Q])/
                     (5*(1 + tb^2)) + (2*At^2*gt^2*(1 + tb^2)*Log[MS/Q])/
                     tb^2 - (2*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/tb^2 + 
                    (g1^2*Log[MS/Q]*md2[1, 1])/5 + (g1^2*Log[MS/Q]*md2[2, 2])/
                     5 + (g1^2*Log[MS/Q]*md2[3, 3])/5 + (g1^2*Log[MS/Q]*
                      me2[1, 1])/5 + (g1^2*Log[MS/Q]*me2[2, 2])/5 + 
                    (g1^2*Log[MS/Q]*me2[3, 3])/5 - (g1^2*Log[MS/Q]*ml2[1, 1])/
                     5 - (g1^2*Log[MS/Q]*ml2[2, 2])/5 - (g1^2*Log[MS/Q]*
                      ml2[3, 3])/5 + (g1^2*Log[MS/Q]*mq2[1, 1])/5 + 
                    (g1^2*Log[MS/Q]*mq2[2, 2])/5 + (g1^2*Log[MS/Q]*mq2[3, 3])/
                     5 + (2*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3])/tb^2 - 
                    (2*g1^2*Log[MS/Q]*mu2[1, 1])/5 - (2*g1^2*Log[MS/Q]*
                      mu2[2, 2])/5 - (2*g1^2*Log[MS/Q]*mu2[3, 3])/5 + 
                    (2*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^2) + 
                  mq2[3, 3]*((-32*g1^2*M1^2*Log[MS/Q])/15 - (32*g3^2*M3^2*
                      Log[MS/Q])/3 + (4*gt^2*mA^2*Log[MS/Q])/tb^2 - 
                    (4*g1^2*mA^2*Log[MS/Q])/(5*(1 + tb^2)) + (4*g1^2*mA^2*
                      tb^2*Log[MS/Q])/(5*(1 + tb^2)) + (4*At^2*gt^2*
                      (1 + tb^2)*Log[MS/Q])/tb^2 - (4*gt^2*(1 + tb^2)*\[Mu]^2*
                      Log[MS/Q])/tb^2 - (4*g1^2*Log[MS/Q]*md2[1, 1])/5 - 
                    (4*g1^2*Log[MS/Q]*md2[2, 2])/5 - (4*g1^2*Log[MS/Q]*
                      md2[3, 3])/5 - (4*g1^2*Log[MS/Q]*me2[1, 1])/5 - 
                    (4*g1^2*Log[MS/Q]*me2[2, 2])/5 - (4*g1^2*Log[MS/Q]*
                      me2[3, 3])/5 + (4*g1^2*Log[MS/Q]*ml2[1, 1])/5 + 
                    (4*g1^2*Log[MS/Q]*ml2[2, 2])/5 + (4*g1^2*Log[MS/Q]*
                      ml2[3, 3])/5 - (4*g1^2*Log[MS/Q]*mq2[1, 1])/5 - 
                    (4*g1^2*Log[MS/Q]*mq2[2, 2])/5 - (4*g1^2*Log[MS/Q]*
                      mq2[3, 3])/5 + (4*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3])/
                     tb^2 + (8*g1^2*Log[MS/Q]*mu2[1, 1])/5 + 
                    (8*g1^2*Log[MS/Q]*mu2[2, 2])/5 + (8*g1^2*Log[MS/Q]*
                      mu2[3, 3])/5 + (4*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/
                     tb^2))*TCF[2][Sqrt[mq2[3, 3]/mu2[3, 3]]])/(2*mq2[3, 3]*
                mu2[3, 3]*Sqrt[mq2[3, 3]*mu2[3, 3]]) + 
              (Sqrt[mq2[3, 3]/mu2[3, 3]]*mu2[3, 3]*((mq2[3, 3]*
                   ((-8*g1^2*Log[MS/Q])/5 - 4*gt^2*Log[MS/Q] - 
                    (4*gt^2*Log[MS/Q])/tb^2 - (4*At^2*gt^2*Log[MS/Q])/
                     mu2[3, 3] + (32*g1^2*M1^2*Log[MS/Q])/(15*mu2[3, 3]) + 
                    (32*g3^2*M3^2*Log[MS/Q])/(3*mu2[3, 3]) - (4*At^2*gt^2*
                      Log[MS/Q])/(tb^2*mu2[3, 3]) - (4*gt^2*mA^2*Log[MS/Q])/
                     (tb^2*mu2[3, 3]) + (4*g1^2*mA^2*Log[MS/Q])/(5*(1 + tb^2)*
                      mu2[3, 3]) - (4*g1^2*mA^2*tb^2*Log[MS/Q])/(5*(1 + tb^2)*
                      mu2[3, 3]) + (4*gt^2*\[Mu]^2*Log[MS/Q])/mu2[3, 3] + 
                    (4*gt^2*\[Mu]^2*Log[MS/Q])/(tb^2*mu2[3, 3]) + 
                    (4*g1^2*Log[MS/Q]*md2[1, 1])/(5*mu2[3, 3]) + 
                    (4*g1^2*Log[MS/Q]*md2[2, 2])/(5*mu2[3, 3]) + 
                    (4*g1^2*Log[MS/Q]*md2[3, 3])/(5*mu2[3, 3]) + 
                    (4*g1^2*Log[MS/Q]*me2[1, 1])/(5*mu2[3, 3]) + 
                    (4*g1^2*Log[MS/Q]*me2[2, 2])/(5*mu2[3, 3]) + 
                    (4*g1^2*Log[MS/Q]*me2[3, 3])/(5*mu2[3, 3]) - 
                    (4*g1^2*Log[MS/Q]*ml2[1, 1])/(5*mu2[3, 3]) - 
                    (4*g1^2*Log[MS/Q]*ml2[2, 2])/(5*mu2[3, 3]) - 
                    (4*g1^2*Log[MS/Q]*ml2[3, 3])/(5*mu2[3, 3]) + 
                    (4*g1^2*Log[MS/Q]*mq2[1, 1])/(5*mu2[3, 3]) + 
                    (4*g1^2*Log[MS/Q]*mq2[2, 2])/(5*mu2[3, 3]) + 
                    (4*g1^2*Log[MS/Q]*mq2[3, 3])/(5*mu2[3, 3]) - 
                    (4*gt^2*Log[MS/Q]*mq2[3, 3])/mu2[3, 3] - 
                    (4*gt^2*Log[MS/Q]*mq2[3, 3])/(tb^2*mu2[3, 3]) - 
                    (8*g1^2*Log[MS/Q]*mu2[1, 1])/(5*mu2[3, 3]) - 
                    (8*g1^2*Log[MS/Q]*mu2[2, 2])/(5*mu2[3, 3])))/mu2[3, 3] + 
                 ((-2*g1^2*M1^2*Log[MS/Q])/15 - 6*g2^2*M2^2*Log[MS/Q] - 
                   (32*g3^2*M3^2*Log[MS/Q])/3 + (2*gt^2*mA^2*Log[MS/Q])/
                    tb^2 + (g1^2*mA^2*Log[MS/Q])/(5*(1 + tb^2)) - 
                   (g1^2*mA^2*tb^2*Log[MS/Q])/(5*(1 + tb^2)) + 
                   (2*At^2*gt^2*(1 + tb^2)*Log[MS/Q])/tb^2 - 
                   (2*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/tb^2 + 
                   (g1^2*Log[MS/Q]*md2[1, 1])/5 + (g1^2*Log[MS/Q]*md2[2, 2])/
                    5 + (g1^2*Log[MS/Q]*md2[3, 3])/5 + (g1^2*Log[MS/Q]*
                     me2[1, 1])/5 + (g1^2*Log[MS/Q]*me2[2, 2])/5 + 
                   (g1^2*Log[MS/Q]*me2[3, 3])/5 - (g1^2*Log[MS/Q]*ml2[1, 1])/
                    5 - (g1^2*Log[MS/Q]*ml2[2, 2])/5 - (g1^2*Log[MS/Q]*
                     ml2[3, 3])/5 + (g1^2*Log[MS/Q]*mq2[1, 1])/5 + 
                   (g1^2*Log[MS/Q]*mq2[2, 2])/5 + (g1^2*Log[MS/Q]*mq2[3, 3])/
                    5 + (2*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3])/tb^2 - 
                   (2*g1^2*Log[MS/Q]*mu2[1, 1])/5 - (2*g1^2*Log[MS/Q]*
                     mu2[2, 2])/5 - (2*g1^2*Log[MS/Q]*mu2[3, 3])/5 + 
                   (2*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^2)/mu2[3, 3])*
                Derivative[1][TCF[2]][Sqrt[mq2[3, 3]/mu2[3, 3]]])/(2*
                mq2[3, 3]*Sqrt[mq2[3, 3]*mu2[3, 3]])))/12))/
        Sqrt[mq2[3, 3]*mu2[3, 3]]) + 
     (3*((2*gt^2*(At - \[Mu]/tb)*Cos[2*ArcTan[tb]]*
          ((26*g2^2*M1*Log[MS/Q])/15 + 6*g2^2*M2*Log[MS/Q] + 
           (32*g3^2*M3*Log[MS/Q])/3 + (12*At*gt^2*(1 + tb^2)*Log[MS/Q])/
            tb^2 - (3*(10*gt^2*\[Mu]*Log[MS/Q] - g1^2*tb^2*\[Mu]*Log[MS/Q] - 
              5*g2^2*tb^2*\[Mu]*Log[MS/Q] + 10*gt^2*tb^2*\[Mu]*Log[MS/Q]))/
            (5*tb^3))*((3*g1^2*TCF[3][Sqrt[mq2[3, 3]/mu2[3, 3]]])/5 + 
           g2^2*TCF[4][Sqrt[mq2[3, 3]/mu2[3, 3]]]))/
         Sqrt[mq2[3, 3]*mu2[3, 3]] + (At - \[Mu]/tb)^2*
         (-(gt^2*Cos[2*ArcTan[tb]]*(mu2[3, 3]*((-2*g1^2*M1^2*Log[MS/Q])/15 - 
                6*g2^2*M2^2*Log[MS/Q] - (32*g3^2*M3^2*Log[MS/Q])/3 + 
                (2*gt^2*mA^2*Log[MS/Q])/tb^2 + (g1^2*mA^2*Log[MS/Q])/
                 (5*(1 + tb^2)) - (g1^2*mA^2*tb^2*Log[MS/Q])/(5*(1 + tb^2)) + 
                (2*At^2*gt^2*(1 + tb^2)*Log[MS/Q])/tb^2 - (2*gt^2*(1 + tb^2)*
                  \[Mu]^2*Log[MS/Q])/tb^2 + (g1^2*Log[MS/Q]*md2[1, 1])/5 + 
                (g1^2*Log[MS/Q]*md2[2, 2])/5 + (g1^2*Log[MS/Q]*md2[3, 3])/5 + 
                (g1^2*Log[MS/Q]*me2[1, 1])/5 + (g1^2*Log[MS/Q]*me2[2, 2])/5 + 
                (g1^2*Log[MS/Q]*me2[3, 3])/5 - (g1^2*Log[MS/Q]*ml2[1, 1])/5 - 
                (g1^2*Log[MS/Q]*ml2[2, 2])/5 - (g1^2*Log[MS/Q]*ml2[3, 3])/5 + 
                (g1^2*Log[MS/Q]*mq2[1, 1])/5 + (g1^2*Log[MS/Q]*mq2[2, 2])/5 + 
                (g1^2*Log[MS/Q]*mq2[3, 3])/5 + (2*gt^2*(1 + tb^2)*Log[MS/Q]*
                  mq2[3, 3])/tb^2 - (2*g1^2*Log[MS/Q]*mu2[1, 1])/5 - 
                (2*g1^2*Log[MS/Q]*mu2[2, 2])/5 - (2*g1^2*Log[MS/Q]*mu2[3, 3])/
                 5 + (2*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^2) + 
              mq2[3, 3]*((-32*g1^2*M1^2*Log[MS/Q])/15 - (32*g3^2*M3^2*
                  Log[MS/Q])/3 + (4*gt^2*mA^2*Log[MS/Q])/tb^2 - 
                (4*g1^2*mA^2*Log[MS/Q])/(5*(1 + tb^2)) + (4*g1^2*mA^2*tb^2*
                  Log[MS/Q])/(5*(1 + tb^2)) + (4*At^2*gt^2*(1 + tb^2)*
                  Log[MS/Q])/tb^2 - (4*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/
                 tb^2 - (4*g1^2*Log[MS/Q]*md2[1, 1])/5 - (4*g1^2*Log[MS/Q]*
                  md2[2, 2])/5 - (4*g1^2*Log[MS/Q]*md2[3, 3])/5 - 
                (4*g1^2*Log[MS/Q]*me2[1, 1])/5 - (4*g1^2*Log[MS/Q]*me2[2, 2])/
                 5 - (4*g1^2*Log[MS/Q]*me2[3, 3])/5 + (4*g1^2*Log[MS/Q]*
                  ml2[1, 1])/5 + (4*g1^2*Log[MS/Q]*ml2[2, 2])/5 + 
                (4*g1^2*Log[MS/Q]*ml2[3, 3])/5 - (4*g1^2*Log[MS/Q]*mq2[1, 1])/
                 5 - (4*g1^2*Log[MS/Q]*mq2[2, 2])/5 - (4*g1^2*Log[MS/Q]*
                  mq2[3, 3])/5 + (4*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3])/
                 tb^2 + (8*g1^2*Log[MS/Q]*mu2[1, 1])/5 + (8*g1^2*Log[MS/Q]*
                  mu2[2, 2])/5 + (8*g1^2*Log[MS/Q]*mu2[3, 3])/5 + 
                (4*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^2))*
             ((3*g1^2*TCF[3][Sqrt[mq2[3, 3]/mu2[3, 3]]])/5 + 
              g2^2*TCF[4][Sqrt[mq2[3, 3]/mu2[3, 3]]]))/(2*mq2[3, 3]*mu2[3, 3]*
            Sqrt[mq2[3, 3]*mu2[3, 3]]) + 
          (((gt*Cos[2*ArcTan[tb]]*(-17*g1^2*gt*Log[MS/Q] - 45*g2^2*gt*
                  Log[MS/Q] - 160*g3^2*gt*Log[MS/Q] + 30*gb^2*gt*Log[MS/Q] + 
                 90*gt^3*Log[MS/Q] + 20*gt*gtau^2*Log[MS/Q]))/10 - 
              (2*gt^2*(-3*gt^2*Log[MS/Q] + 3*gb^2*tb^2*Log[MS/Q] + 
                 gtau^2*tb^2*Log[MS/Q])*Sin[2*ArcTan[tb]])/tb)*
             ((3*g1^2*TCF[3][Sqrt[mq2[3, 3]/mu2[3, 3]]])/5 + 
              g2^2*TCF[4][Sqrt[mq2[3, 3]/mu2[3, 3]]]) + 
            gt^2*Cos[2*ArcTan[tb]]*((-19*g2^4*Log[MS/Q]*TCF[4][
                 Sqrt[mq2[3, 3]/mu2[3, 3]]])/3 + (3*((41*g1^4*Log[MS/Q]*
                   TCF[3][Sqrt[mq2[3, 3]/mu2[3, 3]]])/5 + 
                 (g1^2*Sqrt[mq2[3, 3]/mu2[3, 3]]*mu2[3, 3]*
                   ((mq2[3, 3]*((-8*g1^2*Log[MS/Q])/5 - 4*gt^2*Log[MS/Q] - 
                       (4*gt^2*Log[MS/Q])/tb^2 - (4*At^2*gt^2*Log[MS/Q])/
                        mu2[3, 3] + (32*g1^2*M1^2*Log[MS/Q])/(15*mu2[3, 3]) + 
                       (32*g3^2*M3^2*Log[MS/Q])/(3*mu2[3, 3]) - (4*At^2*gt^2*
                         Log[MS/Q])/(tb^2*mu2[3, 3]) - (4*gt^2*mA^2*
                         Log[MS/Q])/(tb^2*mu2[3, 3]) + (4*g1^2*mA^2*
                         Log[MS/Q])/(5*(1 + tb^2)*mu2[3, 3]) - (4*g1^2*mA^2*
                         tb^2*Log[MS/Q])/(5*(1 + tb^2)*mu2[3, 3]) + 
                       (4*gt^2*\[Mu]^2*Log[MS/Q])/mu2[3, 3] + (4*gt^2*\[Mu]^2*
                         Log[MS/Q])/(tb^2*mu2[3, 3]) + (4*g1^2*Log[MS/Q]*
                         md2[1, 1])/(5*mu2[3, 3]) + (4*g1^2*Log[MS/Q]*
                         md2[2, 2])/(5*mu2[3, 3]) + (4*g1^2*Log[MS/Q]*
                         md2[3, 3])/(5*mu2[3, 3]) + (4*g1^2*Log[MS/Q]*
                         me2[1, 1])/(5*mu2[3, 3]) + (4*g1^2*Log[MS/Q]*
                         me2[2, 2])/(5*mu2[3, 3]) + (4*g1^2*Log[MS/Q]*
                         me2[3, 3])/(5*mu2[3, 3]) - (4*g1^2*Log[MS/Q]*
                         ml2[1, 1])/(5*mu2[3, 3]) - (4*g1^2*Log[MS/Q]*
                         ml2[2, 2])/(5*mu2[3, 3]) - (4*g1^2*Log[MS/Q]*
                         ml2[3, 3])/(5*mu2[3, 3]) + (4*g1^2*Log[MS/Q]*
                         mq2[1, 1])/(5*mu2[3, 3]) + (4*g1^2*Log[MS/Q]*
                         mq2[2, 2])/(5*mu2[3, 3]) + (4*g1^2*Log[MS/Q]*
                         mq2[3, 3])/(5*mu2[3, 3]) - (4*gt^2*Log[MS/Q]*
                         mq2[3, 3])/mu2[3, 3] - (4*gt^2*Log[MS/Q]*mq2[3, 3])/
                        (tb^2*mu2[3, 3]) - (8*g1^2*Log[MS/Q]*mu2[1, 1])/
                        (5*mu2[3, 3]) - (8*g1^2*Log[MS/Q]*mu2[2, 2])/
                        (5*mu2[3, 3])))/mu2[3, 3] + ((-2*g1^2*M1^2*Log[MS/Q])/
                       15 - 6*g2^2*M2^2*Log[MS/Q] - (32*g3^2*M3^2*Log[MS/Q])/
                       3 + (2*gt^2*mA^2*Log[MS/Q])/tb^2 + (g1^2*mA^2*
                        Log[MS/Q])/(5*(1 + tb^2)) - (g1^2*mA^2*tb^2*
                        Log[MS/Q])/(5*(1 + tb^2)) + (2*At^2*gt^2*(1 + tb^2)*
                        Log[MS/Q])/tb^2 - (2*gt^2*(1 + tb^2)*\[Mu]^2*
                        Log[MS/Q])/tb^2 + (g1^2*Log[MS/Q]*md2[1, 1])/5 + 
                      (g1^2*Log[MS/Q]*md2[2, 2])/5 + (g1^2*Log[MS/Q]*
                        md2[3, 3])/5 + (g1^2*Log[MS/Q]*me2[1, 1])/5 + 
                      (g1^2*Log[MS/Q]*me2[2, 2])/5 + (g1^2*Log[MS/Q]*
                        me2[3, 3])/5 - (g1^2*Log[MS/Q]*ml2[1, 1])/5 - 
                      (g1^2*Log[MS/Q]*ml2[2, 2])/5 - (g1^2*Log[MS/Q]*
                        ml2[3, 3])/5 + (g1^2*Log[MS/Q]*mq2[1, 1])/5 + 
                      (g1^2*Log[MS/Q]*mq2[2, 2])/5 + (g1^2*Log[MS/Q]*
                        mq2[3, 3])/5 + (2*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 
                         3])/tb^2 - (2*g1^2*Log[MS/Q]*mu2[1, 1])/5 - 
                      (2*g1^2*Log[MS/Q]*mu2[2, 2])/5 - (2*g1^2*Log[MS/Q]*
                        mu2[3, 3])/5 + (2*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 
                         3])/tb^2)/mu2[3, 3])*Derivative[1][TCF[3]][
                    Sqrt[mq2[3, 3]/mu2[3, 3]]])/(2*mq2[3, 3])))/5 + 
              (g2^2*Sqrt[mq2[3, 3]/mu2[3, 3]]*mu2[3, 3]*
                ((mq2[3, 3]*((-8*g1^2*Log[MS/Q])/5 - 4*gt^2*Log[MS/Q] - 
                    (4*gt^2*Log[MS/Q])/tb^2 - (4*At^2*gt^2*Log[MS/Q])/
                     mu2[3, 3] + (32*g1^2*M1^2*Log[MS/Q])/(15*mu2[3, 3]) + 
                    (32*g3^2*M3^2*Log[MS/Q])/(3*mu2[3, 3]) - (4*At^2*gt^2*
                      Log[MS/Q])/(tb^2*mu2[3, 3]) - (4*gt^2*mA^2*Log[MS/Q])/
                     (tb^2*mu2[3, 3]) + (4*g1^2*mA^2*Log[MS/Q])/(5*(1 + tb^2)*
                      mu2[3, 3]) - (4*g1^2*mA^2*tb^2*Log[MS/Q])/(5*(1 + tb^2)*
                      mu2[3, 3]) + (4*gt^2*\[Mu]^2*Log[MS/Q])/mu2[3, 3] + 
                    (4*gt^2*\[Mu]^2*Log[MS/Q])/(tb^2*mu2[3, 3]) + 
                    (4*g1^2*Log[MS/Q]*md2[1, 1])/(5*mu2[3, 3]) + 
                    (4*g1^2*Log[MS/Q]*md2[2, 2])/(5*mu2[3, 3]) + 
                    (4*g1^2*Log[MS/Q]*md2[3, 3])/(5*mu2[3, 3]) + 
                    (4*g1^2*Log[MS/Q]*me2[1, 1])/(5*mu2[3, 3]) + 
                    (4*g1^2*Log[MS/Q]*me2[2, 2])/(5*mu2[3, 3]) + 
                    (4*g1^2*Log[MS/Q]*me2[3, 3])/(5*mu2[3, 3]) - 
                    (4*g1^2*Log[MS/Q]*ml2[1, 1])/(5*mu2[3, 3]) - 
                    (4*g1^2*Log[MS/Q]*ml2[2, 2])/(5*mu2[3, 3]) - 
                    (4*g1^2*Log[MS/Q]*ml2[3, 3])/(5*mu2[3, 3]) + 
                    (4*g1^2*Log[MS/Q]*mq2[1, 1])/(5*mu2[3, 3]) + 
                    (4*g1^2*Log[MS/Q]*mq2[2, 2])/(5*mu2[3, 3]) + 
                    (4*g1^2*Log[MS/Q]*mq2[3, 3])/(5*mu2[3, 3]) - 
                    (4*gt^2*Log[MS/Q]*mq2[3, 3])/mu2[3, 3] - 
                    (4*gt^2*Log[MS/Q]*mq2[3, 3])/(tb^2*mu2[3, 3]) - 
                    (8*g1^2*Log[MS/Q]*mu2[1, 1])/(5*mu2[3, 3]) - 
                    (8*g1^2*Log[MS/Q]*mu2[2, 2])/(5*mu2[3, 3])))/mu2[3, 3] + 
                 ((-2*g1^2*M1^2*Log[MS/Q])/15 - 6*g2^2*M2^2*Log[MS/Q] - 
                   (32*g3^2*M3^2*Log[MS/Q])/3 + (2*gt^2*mA^2*Log[MS/Q])/
                    tb^2 + (g1^2*mA^2*Log[MS/Q])/(5*(1 + tb^2)) - 
                   (g1^2*mA^2*tb^2*Log[MS/Q])/(5*(1 + tb^2)) + 
                   (2*At^2*gt^2*(1 + tb^2)*Log[MS/Q])/tb^2 - 
                   (2*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/tb^2 + 
                   (g1^2*Log[MS/Q]*md2[1, 1])/5 + (g1^2*Log[MS/Q]*md2[2, 2])/
                    5 + (g1^2*Log[MS/Q]*md2[3, 3])/5 + (g1^2*Log[MS/Q]*
                     me2[1, 1])/5 + (g1^2*Log[MS/Q]*me2[2, 2])/5 + 
                   (g1^2*Log[MS/Q]*me2[3, 3])/5 - (g1^2*Log[MS/Q]*ml2[1, 1])/
                    5 - (g1^2*Log[MS/Q]*ml2[2, 2])/5 - (g1^2*Log[MS/Q]*
                     ml2[3, 3])/5 + (g1^2*Log[MS/Q]*mq2[1, 1])/5 + 
                   (g1^2*Log[MS/Q]*mq2[2, 2])/5 + (g1^2*Log[MS/Q]*mq2[3, 3])/
                    5 + (2*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3])/tb^2 - 
                   (2*g1^2*Log[MS/Q]*mu2[1, 1])/5 - (2*g1^2*Log[MS/Q]*
                     mu2[2, 2])/5 - (2*g1^2*Log[MS/Q]*mu2[3, 3])/5 + 
                   (2*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^2)/mu2[3, 3])*
                Derivative[1][TCF[4]][Sqrt[mq2[3, 3]/mu2[3, 3]]])/(2*
                mq2[3, 3])))/Sqrt[mq2[3, 3]*mu2[3, 3]])))/4 + 
     ((-2*((3*g1^2)/5 + g2^2)*gt^2*(At - \[Mu]/tb)*Cos[2*ArcTan[tb]]^2*
         ((26*g2^2*M1*Log[MS/Q])/15 + 6*g2^2*M2*Log[MS/Q] + 
          (32*g3^2*M3*Log[MS/Q])/3 + (12*At*gt^2*(1 + tb^2)*Log[MS/Q])/tb^2 - 
          (3*(10*gt^2*\[Mu]*Log[MS/Q] - g1^2*tb^2*\[Mu]*Log[MS/Q] - 
             5*g2^2*tb^2*\[Mu]*Log[MS/Q] + 10*gt^2*tb^2*\[Mu]*Log[MS/Q]))/
           (5*tb^3))*TCF[5][Sqrt[mq2[3, 3]/mu2[3, 3]]])/
        Sqrt[mq2[3, 3]*mu2[3, 3]] - (At - \[Mu]/tb)^2*
        (-(((3*g1^2)/5 + g2^2)*gt^2*Cos[2*ArcTan[tb]]^2*
            (mu2[3, 3]*((-2*g1^2*M1^2*Log[MS/Q])/15 - 6*g2^2*M2^2*Log[MS/Q] - 
               (32*g3^2*M3^2*Log[MS/Q])/3 + (2*gt^2*mA^2*Log[MS/Q])/tb^2 + 
               (g1^2*mA^2*Log[MS/Q])/(5*(1 + tb^2)) - (g1^2*mA^2*tb^2*
                 Log[MS/Q])/(5*(1 + tb^2)) + (2*At^2*gt^2*(1 + tb^2)*
                 Log[MS/Q])/tb^2 - (2*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/
                tb^2 + (g1^2*Log[MS/Q]*md2[1, 1])/5 + (g1^2*Log[MS/Q]*
                 md2[2, 2])/5 + (g1^2*Log[MS/Q]*md2[3, 3])/5 + 
               (g1^2*Log[MS/Q]*me2[1, 1])/5 + (g1^2*Log[MS/Q]*me2[2, 2])/5 + 
               (g1^2*Log[MS/Q]*me2[3, 3])/5 - (g1^2*Log[MS/Q]*ml2[1, 1])/5 - 
               (g1^2*Log[MS/Q]*ml2[2, 2])/5 - (g1^2*Log[MS/Q]*ml2[3, 3])/5 + 
               (g1^2*Log[MS/Q]*mq2[1, 1])/5 + (g1^2*Log[MS/Q]*mq2[2, 2])/5 + 
               (g1^2*Log[MS/Q]*mq2[3, 3])/5 + (2*gt^2*(1 + tb^2)*Log[MS/Q]*
                 mq2[3, 3])/tb^2 - (2*g1^2*Log[MS/Q]*mu2[1, 1])/5 - 
               (2*g1^2*Log[MS/Q]*mu2[2, 2])/5 - (2*g1^2*Log[MS/Q]*mu2[3, 3])/
                5 + (2*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^2) + 
             mq2[3, 3]*((-32*g1^2*M1^2*Log[MS/Q])/15 - (32*g3^2*M3^2*
                 Log[MS/Q])/3 + (4*gt^2*mA^2*Log[MS/Q])/tb^2 - (4*g1^2*mA^2*
                 Log[MS/Q])/(5*(1 + tb^2)) + (4*g1^2*mA^2*tb^2*Log[MS/Q])/
                (5*(1 + tb^2)) + (4*At^2*gt^2*(1 + tb^2)*Log[MS/Q])/tb^2 - 
               (4*gt^2*(1 + tb^2)*\[Mu]^2*Log[MS/Q])/tb^2 - (4*g1^2*Log[MS/Q]*
                 md2[1, 1])/5 - (4*g1^2*Log[MS/Q]*md2[2, 2])/5 - 
               (4*g1^2*Log[MS/Q]*md2[3, 3])/5 - (4*g1^2*Log[MS/Q]*me2[1, 1])/
                5 - (4*g1^2*Log[MS/Q]*me2[2, 2])/5 - (4*g1^2*Log[MS/Q]*
                 me2[3, 3])/5 + (4*g1^2*Log[MS/Q]*ml2[1, 1])/5 + 
               (4*g1^2*Log[MS/Q]*ml2[2, 2])/5 + (4*g1^2*Log[MS/Q]*ml2[3, 3])/
                5 - (4*g1^2*Log[MS/Q]*mq2[1, 1])/5 - (4*g1^2*Log[MS/Q]*
                 mq2[2, 2])/5 - (4*g1^2*Log[MS/Q]*mq2[3, 3])/5 + 
               (4*gt^2*(1 + tb^2)*Log[MS/Q]*mq2[3, 3])/tb^2 + (8*g1^2*
                 Log[MS/Q]*mu2[1, 1])/5 + (8*g1^2*Log[MS/Q]*mu2[2, 2])/5 + 
               (8*g1^2*Log[MS/Q]*mu2[3, 3])/5 + (4*gt^2*(1 + tb^2)*Log[MS/Q]*
                 mu2[3, 3])/tb^2))*TCF[5][Sqrt[mq2[3, 3]/mu2[3, 3]]])/
          (2*mq2[3, 3]*mu2[3, 3]*Sqrt[mq2[3, 3]*mu2[3, 3]]) + 
         (((((3*g1^2)/5 + g2^2)*gt*Cos[2*ArcTan[tb]]^2*(-17*g1^2*gt*
                 Log[MS/Q] - 45*g2^2*gt*Log[MS/Q] - 160*g3^2*gt*Log[MS/Q] + 
                30*gb^2*gt*Log[MS/Q] + 90*gt^3*Log[MS/Q] + 20*gt*gtau^2*
                 Log[MS/Q]))/10 + gt^2*(Cos[2*ArcTan[tb]]^2*
                ((123*g1^4*Log[MS/Q])/25 - (19*g2^4*Log[MS/Q])/3) - 
               (4*((3*g1^2)/5 + g2^2)*Cos[2*ArcTan[tb]]*(-3*gt^2*Log[MS/Q] + 
                  3*gb^2*tb^2*Log[MS/Q] + gtau^2*tb^2*Log[MS/Q])*
                 Sin[2*ArcTan[tb]])/tb))*TCF[5][Sqrt[mq2[3, 3]/mu2[3, 3]]] + 
           (((3*g1^2)/5 + g2^2)*gt^2*Cos[2*ArcTan[tb]]^2*
             Sqrt[mq2[3, 3]/mu2[3, 3]]*mu2[3, 3]*
             ((mq2[3, 3]*((-8*g1^2*Log[MS/Q])/5 - 4*gt^2*Log[MS/Q] - 
                 (4*gt^2*Log[MS/Q])/tb^2 - (4*At^2*gt^2*Log[MS/Q])/
                  mu2[3, 3] + (32*g1^2*M1^2*Log[MS/Q])/(15*mu2[3, 3]) + 
                 (32*g3^2*M3^2*Log[MS/Q])/(3*mu2[3, 3]) - (4*At^2*gt^2*
                   Log[MS/Q])/(tb^2*mu2[3, 3]) - (4*gt^2*mA^2*Log[MS/Q])/
                  (tb^2*mu2[3, 3]) + (4*g1^2*mA^2*Log[MS/Q])/(5*(1 + tb^2)*
                   mu2[3, 3]) - (4*g1^2*mA^2*tb^2*Log[MS/Q])/(5*(1 + tb^2)*
                   mu2[3, 3]) + (4*gt^2*\[Mu]^2*Log[MS/Q])/mu2[3, 3] + 
                 (4*gt^2*\[Mu]^2*Log[MS/Q])/(tb^2*mu2[3, 3]) + 
                 (4*g1^2*Log[MS/Q]*md2[1, 1])/(5*mu2[3, 3]) + 
                 (4*g1^2*Log[MS/Q]*md2[2, 2])/(5*mu2[3, 3]) + 
                 (4*g1^2*Log[MS/Q]*md2[3, 3])/(5*mu2[3, 3]) + 
                 (4*g1^2*Log[MS/Q]*me2[1, 1])/(5*mu2[3, 3]) + 
                 (4*g1^2*Log[MS/Q]*me2[2, 2])/(5*mu2[3, 3]) + 
                 (4*g1^2*Log[MS/Q]*me2[3, 3])/(5*mu2[3, 3]) - 
                 (4*g1^2*Log[MS/Q]*ml2[1, 1])/(5*mu2[3, 3]) - 
                 (4*g1^2*Log[MS/Q]*ml2[2, 2])/(5*mu2[3, 3]) - 
                 (4*g1^2*Log[MS/Q]*ml2[3, 3])/(5*mu2[3, 3]) + 
                 (4*g1^2*Log[MS/Q]*mq2[1, 1])/(5*mu2[3, 3]) + 
                 (4*g1^2*Log[MS/Q]*mq2[2, 2])/(5*mu2[3, 3]) + 
                 (4*g1^2*Log[MS/Q]*mq2[3, 3])/(5*mu2[3, 3]) - 
                 (4*gt^2*Log[MS/Q]*mq2[3, 3])/mu2[3, 3] - (4*gt^2*Log[MS/Q]*
                   mq2[3, 3])/(tb^2*mu2[3, 3]) - (8*g1^2*Log[MS/Q]*mu2[1, 1])/
                  (5*mu2[3, 3]) - (8*g1^2*Log[MS/Q]*mu2[2, 2])/
                  (5*mu2[3, 3])))/mu2[3, 3] + ((-2*g1^2*M1^2*Log[MS/Q])/15 - 
                6*g2^2*M2^2*Log[MS/Q] - (32*g3^2*M3^2*Log[MS/Q])/3 + 
                (2*gt^2*mA^2*Log[MS/Q])/tb^2 + (g1^2*mA^2*Log[MS/Q])/
                 (5*(1 + tb^2)) - (g1^2*mA^2*tb^2*Log[MS/Q])/(5*(1 + tb^2)) + 
                (2*At^2*gt^2*(1 + tb^2)*Log[MS/Q])/tb^2 - (2*gt^2*(1 + tb^2)*
                  \[Mu]^2*Log[MS/Q])/tb^2 + (g1^2*Log[MS/Q]*md2[1, 1])/5 + 
                (g1^2*Log[MS/Q]*md2[2, 2])/5 + (g1^2*Log[MS/Q]*md2[3, 3])/5 + 
                (g1^2*Log[MS/Q]*me2[1, 1])/5 + (g1^2*Log[MS/Q]*me2[2, 2])/5 + 
                (g1^2*Log[MS/Q]*me2[3, 3])/5 - (g1^2*Log[MS/Q]*ml2[1, 1])/5 - 
                (g1^2*Log[MS/Q]*ml2[2, 2])/5 - (g1^2*Log[MS/Q]*ml2[3, 3])/5 + 
                (g1^2*Log[MS/Q]*mq2[1, 1])/5 + (g1^2*Log[MS/Q]*mq2[2, 2])/5 + 
                (g1^2*Log[MS/Q]*mq2[3, 3])/5 + (2*gt^2*(1 + tb^2)*Log[MS/Q]*
                  mq2[3, 3])/tb^2 - (2*g1^2*Log[MS/Q]*mu2[1, 1])/5 - 
                (2*g1^2*Log[MS/Q]*mu2[2, 2])/5 - (2*g1^2*Log[MS/Q]*mu2[3, 3])/
                 5 + (2*gt^2*(1 + tb^2)*Log[MS/Q]*mu2[3, 3])/tb^2)/mu2[3, 3])*
             Derivative[1][TCF[5]][Sqrt[mq2[3, 3]/mu2[3, 3]]])/(2*mq2[3, 3]))/
          Sqrt[mq2[3, 3]*mu2[3, 3]]))/4)/(16*Pi^2) + 
   ((((-9*g1^4)/(25*(1 + tb^2)^2) - (5*g2^4)/(1 + tb^2)^2 - 
         (12*g1^2*g2^2*tb^2)/(5*(1 + tb^2)^2) - (9*g1^4*tb^4)/
          (25*(1 + tb^2)^2) - (5*g2^4*tb^4)/(1 + tb^2)^2 - 
         (2*(5*g2^2 + 3*g1^2*tb^2)*(3*g1^2 + 5*g2^2*tb^2))/
          (25*(1 + tb^2)^2) + (3*((3*g1^2)/5 + g2^2)*(g1^2 + 5*g2^2)*
           Cos[2*ArcTan[tb]]^2)/10)*((-6*g1^2*Log[MS/Q])/5 - 
         6*g2^2*Log[MS/Q] + 6*gb^2*Log[MS/Q] + 6*gt^2*Log[MS/Q] + 
         2*gtau^2*Log[MS/Q] + (6*gt^2*Log[MS/Q])/tb^2 + 
         6*gb^2*tb^2*Log[MS/Q] + 2*gtau^2*tb^2*Log[MS/Q]) + 
       Log[\[Mu]^2/Q^2]*((-18*(41*g1^6*Log[MS/Q] + 30*g1^4*gt^2*Log[MS/Q] - 
            30*g1^4*gb^2*tb^2*Log[MS/Q] - 10*g1^4*gtau^2*tb^2*Log[MS/Q]))/
          (125*(1 + tb^2)^2) + (10*(19*g2^6*Log[MS/Q] - 18*g2^4*gt^2*
             Log[MS/Q] + 18*g2^4*gb^2*tb^2*Log[MS/Q] + 6*g2^4*gtau^2*tb^2*
             Log[MS/Q]))/(3*(1 + tb^2)^2) - 
         (18*(-30*g1^4*gt^2*tb^2*Log[MS/Q] + 41*g1^6*tb^4*Log[MS/Q] + 
            30*g1^4*gb^2*tb^4*Log[MS/Q] + 10*g1^4*gtau^2*tb^4*Log[MS/Q]))/
          (125*(1 + tb^2)^2) - (4*(-90*g1^2*g2^2*gt^2*Log[MS/Q] + 
            123*g1^4*g2^2*tb^2*Log[MS/Q] - 95*g1^2*g2^4*tb^2*Log[MS/Q] + 
            90*g1^2*g2^2*gb^2*tb^2*Log[MS/Q] + 90*g1^2*g2^2*gt^2*tb^2*
             Log[MS/Q] + 30*g1^2*g2^2*gtau^2*tb^2*Log[MS/Q] - 
            90*g1^2*g2^2*gb^2*tb^4*Log[MS/Q] - 30*g1^2*g2^2*gtau^2*tb^4*
             Log[MS/Q]))/(25*(1 + tb^2)^2) + 
         (10*(18*g2^4*gt^2*tb^2*Log[MS/Q] + 19*g2^6*tb^4*Log[MS/Q] - 
            18*g2^4*gb^2*tb^4*Log[MS/Q] - 6*g2^4*gtau^2*tb^4*Log[MS/Q]))/
          (3*(1 + tb^2)^2) - 2*(((3*g1^2 + 5*g2^2*tb^2)*
             (-475*g2^4*Log[MS/Q] - 270*g1^2*gt^2*Log[MS/Q] + 
              450*g2^2*gt^2*Log[MS/Q] + 369*g1^4*tb^2*Log[MS/Q] + 
              270*g1^2*gb^2*tb^2*Log[MS/Q] - 450*g2^2*gb^2*tb^2*Log[MS/Q] + 
              90*g1^2*gtau^2*tb^2*Log[MS/Q] - 150*g2^2*gtau^2*tb^2*Log[
                MS/Q]))/(375*(1 + tb^2)^2) + ((5*g2^2 + 3*g1^2*tb^2)*
             (369*g1^4*Log[MS/Q] + 270*g1^2*gt^2*Log[MS/Q] - 
              450*g2^2*gt^2*Log[MS/Q] - 475*g2^4*tb^2*Log[MS/Q] - 
              270*g1^2*gb^2*tb^2*Log[MS/Q] + 450*g2^2*gb^2*tb^2*Log[MS/Q] - 
              90*g1^2*gtau^2*tb^2*Log[MS/Q] + 150*g2^2*gtau^2*tb^2*Log[
                MS/Q]))/(375*(1 + tb^2)^2)) + 
         ((((3*g1^2)/5 + g2^2)*Cos[2*ArcTan[tb]]^2*(123*g1^4*Log[MS/Q] - 
              475*g2^4*Log[MS/Q]))/25 + (3*(g1^2 + 5*g2^2)*
             (Cos[2*ArcTan[tb]]^2*((123*g1^4*Log[MS/Q])/25 - 
                (19*g2^4*Log[MS/Q])/3) - (4*((3*g1^2)/5 + g2^2)*
                Cos[2*ArcTan[tb]]*(-3*gt^2*Log[MS/Q] + 3*gb^2*tb^2*
                  Log[MS/Q] + gtau^2*tb^2*Log[MS/Q])*Sin[2*ArcTan[tb]])/tb))/
            5)/2))/2 + 
     (2*((g1^2*tb*((-246*g1^4*Log[MS/Q])/25 + 
           (Cos[2*ArcTan[tb]]^2*((123*g1^4*Log[MS/Q])/25 - (19*g2^4*
                 Log[MS/Q])/3) - (4*((3*g1^2)/5 + g2^2)*Cos[2*ArcTan[tb]]*(
                -3*gt^2*Log[MS/Q] + 3*gb^2*tb^2*Log[MS/Q] + gtau^2*tb^2*
                 Log[MS/Q])*Sin[2*ArcTan[tb]])/tb)/4)*TCf0[M1/\[Mu]])/
         (1 + tb^2) + ((-6*g1^2)/5 + (((3*g1^2)/5 + g2^2)*Cos[2*ArcTan[tb]]^
             2)/4)*((-2*g1^2*tb*(-3*gt^2*Log[MS/Q] + 3*gb^2*tb^2*Log[MS/Q] + 
             gtau^2*tb^2*Log[MS/Q])*TCf0[M1/\[Mu]])/(1 + tb^2) + 
          (g1^2*((-3*gt^2*(1 + tb^2)*Log[MS/Q])/tb + 3*gb^2*tb*(1 + tb^2)*Log[
                MS/Q] + gtau^2*tb*(1 + tb^2)*Log[MS/Q])*TCf0[M1/\[Mu]] + 
            tb*((41*g1^4*Log[MS/Q]*TCf0[M1/\[Mu]])/5 + (g1^2*M1*
                ((3*g1^2*Log[MS/Q])/5 + 3*g2^2*Log[MS/Q] - 3*gb^2*Log[MS/Q] - 
                 3*gt^2*Log[MS/Q] - gtau^2*Log[MS/Q] - (3*gt^2*Log[MS/Q])/
                  tb^2 - 3*gb^2*tb^2*Log[MS/Q] - gtau^2*tb^2*Log[MS/Q])*
                Derivative[1][TCf0][M1/\[Mu]])/\[Mu]))/(1 + tb^2))))/5 + 
     2*((g2^2*tb*((38*g2^4*Log[MS/Q])/3 + 
          (Cos[2*ArcTan[tb]]^2*((123*g1^4*Log[MS/Q])/25 - (19*g2^4*Log[MS/Q])/
               3) - (4*((3*g1^2)/5 + g2^2)*Cos[2*ArcTan[tb]]*
              (-3*gt^2*Log[MS/Q] + 3*gb^2*tb^2*Log[MS/Q] + gtau^2*tb^2*
                Log[MS/Q])*Sin[2*ArcTan[tb]])/tb)/4)*TCf0[M2/\[Mu]])/
        (1 + tb^2) + (-2*g2^2 + (((3*g1^2)/5 + g2^2)*Cos[2*ArcTan[tb]]^2)/4)*
        ((-2*g2^2*tb*(-3*gt^2*Log[MS/Q] + 3*gb^2*tb^2*Log[MS/Q] + 
            gtau^2*tb^2*Log[MS/Q])*TCf0[M2/\[Mu]])/(1 + tb^2) + 
         (g2^2*((-3*gt^2*(1 + tb^2)*Log[MS/Q])/tb + 3*gb^2*tb*(1 + tb^2)*
              Log[MS/Q] + gtau^2*tb*(1 + tb^2)*Log[MS/Q])*TCf0[M2/\[Mu]] + 
           tb*((-19*g2^4*Log[MS/Q]*TCf0[M2/\[Mu]])/3 + 
             (g2^2*M2*((3*g1^2*Log[MS/Q])/5 + 3*g2^2*Log[MS/Q] - 
                3*gb^2*Log[MS/Q] - 3*gt^2*Log[MS/Q] - gtau^2*Log[MS/Q] - 
                (3*gt^2*Log[MS/Q])/tb^2 - 3*gb^2*tb^2*Log[MS/Q] - 
                gtau^2*tb^2*Log[MS/Q])*Derivative[1][TCf0][M2/\[Mu]])/\[Mu]))/
          (1 + tb^2))) + ((123*g1^4*((3*g1^2)/5 + g2^2)*Cos[2*ArcTan[tb]]^2*
         Log[MS/Q]*TCg0[M1/\[Mu]])/25 + 
       (3*g1^2*((Cos[2*ArcTan[tb]]^2*((123*g1^4*Log[MS/Q])/25 - 
              (19*g2^4*Log[MS/Q])/3) - (4*((3*g1^2)/5 + g2^2)*
              Cos[2*ArcTan[tb]]*(-3*gt^2*Log[MS/Q] + 3*gb^2*tb^2*Log[MS/Q] + 
               gtau^2*tb^2*Log[MS/Q])*Sin[2*ArcTan[tb]])/tb)*TCg0[M1/\[Mu]] + 
          (((3*g1^2)/5 + g2^2)*M1*Cos[2*ArcTan[tb]]^2*((3*g1^2*Log[MS/Q])/5 + 
             3*g2^2*Log[MS/Q] - 3*gb^2*Log[MS/Q] - 3*gt^2*Log[MS/Q] - 
             gtau^2*Log[MS/Q] - (3*gt^2*Log[MS/Q])/tb^2 - 3*gb^2*tb^2*
              Log[MS/Q] - gtau^2*tb^2*Log[MS/Q])*Derivative[1][TCg0][
             M1/\[Mu]])/\[Mu]))/5)/12 + 
     ((-19*g2^4*((3*g1^2)/5 + g2^2)*Cos[2*ArcTan[tb]]^2*Log[MS/Q]*
         TCg0[M2/\[Mu]])/3 + 
       g2^2*((Cos[2*ArcTan[tb]]^2*((123*g1^4*Log[MS/Q])/25 - 
             (19*g2^4*Log[MS/Q])/3) - (4*((3*g1^2)/5 + g2^2)*
             Cos[2*ArcTan[tb]]*(-3*gt^2*Log[MS/Q] + 3*gb^2*tb^2*Log[MS/Q] + 
              gtau^2*tb^2*Log[MS/Q])*Sin[2*ArcTan[tb]])/tb)*TCg0[M2/\[Mu]] + 
         (((3*g1^2)/5 + g2^2)*M2*Cos[2*ArcTan[tb]]^2*((3*g1^2*Log[MS/Q])/5 + 
            3*g2^2*Log[MS/Q] - 3*gb^2*Log[MS/Q] - 3*gt^2*Log[MS/Q] - 
            gtau^2*Log[MS/Q] - (3*gt^2*Log[MS/Q])/tb^2 - 3*gb^2*tb^2*
             Log[MS/Q] - gtau^2*tb^2*Log[MS/Q])*Derivative[1][TCg0][
            M2/\[Mu]])/\[Mu]))/4 - 
     (7*((18*(41*g1^6*Log[MS/Q] + 30*g1^4*gt^2*Log[MS/Q] - 
           30*g1^4*gb^2*tb^2*Log[MS/Q] - 30*g1^4*gt^2*tb^2*Log[MS/Q] - 
           10*g1^4*gtau^2*tb^2*Log[MS/Q] + 41*g1^6*tb^4*Log[MS/Q] + 
           30*g1^4*gb^2*tb^4*Log[MS/Q] + 10*g1^4*gtau^2*tb^4*Log[MS/Q])*
          TCf[1][M1/\[Mu]])/(125*(1 + tb^2)^2) + 
        (9*M1*(g1^4 + g1^4*tb^4)*((3*g1^2*Log[MS/Q])/5 + 3*g2^2*Log[MS/Q] - 
           3*gb^2*Log[MS/Q] - 3*gt^2*Log[MS/Q] - gtau^2*Log[MS/Q] - 
           (3*gt^2*Log[MS/Q])/tb^2 - 3*gb^2*tb^2*Log[MS/Q] - 
           gtau^2*tb^2*Log[MS/Q])*Derivative[1][TCf[1]][M1/\[Mu]])/
         (25*(1 + tb^2)^2*\[Mu])))/12 - 
     (9*((-2*(19*g2^6*Log[MS/Q] - 18*g2^4*gt^2*Log[MS/Q] + 
           18*g2^4*gb^2*tb^2*Log[MS/Q] + 18*g2^4*gt^2*tb^2*Log[MS/Q] + 
           6*g2^4*gtau^2*tb^2*Log[MS/Q] + 19*g2^6*tb^4*Log[MS/Q] - 
           18*g2^4*gb^2*tb^4*Log[MS/Q] - 6*g2^4*gtau^2*tb^4*Log[MS/Q])*
          TCf[2][M2/\[Mu]])/(3*(1 + tb^2)^2) + 
        (M2*(g2^4 + g2^4*tb^4)*((3*g1^2*Log[MS/Q])/5 + 3*g2^2*Log[MS/Q] - 
           3*gb^2*Log[MS/Q] - 3*gt^2*Log[MS/Q] - gtau^2*Log[MS/Q] - 
           (3*gt^2*Log[MS/Q])/tb^2 - 3*gb^2*tb^2*Log[MS/Q] - 
           gtau^2*tb^2*Log[MS/Q])*Derivative[1][TCf[2]][M2/\[Mu]])/
         ((1 + tb^2)^2*\[Mu])))/4 - 
     (27*((-4*g1^4*tb^2*(-3*gt^2*Log[MS/Q] + 3*gb^2*tb^2*Log[MS/Q] + 
           gtau^2*tb^2*Log[MS/Q])*TCf[3][M1/\[Mu]])/(1 + tb^2)^2 + 
        (2*g1^4*tb*((-3*gt^2*(1 + tb^2)*Log[MS/Q])/tb + 3*gb^2*tb*(1 + tb^2)*
             Log[MS/Q] + gtau^2*tb*(1 + tb^2)*Log[MS/Q])*TCf[3][M1/\[Mu]] + 
          tb^2*((82*g1^6*Log[MS/Q]*TCf[3][M1/\[Mu]])/5 + 
            (g1^4*M1*((3*g1^2*Log[MS/Q])/5 + 3*g2^2*Log[MS/Q] - 3*gb^2*
                Log[MS/Q] - 3*gt^2*Log[MS/Q] - gtau^2*Log[MS/Q] - 
               (3*gt^2*Log[MS/Q])/tb^2 - 3*gb^2*tb^2*Log[MS/Q] - gtau^2*tb^2*
                Log[MS/Q])*Derivative[1][TCf[3]][M1/\[Mu]])/\[Mu]))/
         (1 + tb^2)^2))/50 - 
     (7*((-4*g2^4*tb^2*(-3*gt^2*Log[MS/Q] + 3*gb^2*tb^2*Log[MS/Q] + 
           gtau^2*tb^2*Log[MS/Q])*TCf[4][M2/\[Mu]])/(1 + tb^2)^2 + 
        (2*g2^4*tb*((-3*gt^2*(1 + tb^2)*Log[MS/Q])/tb + 3*gb^2*tb*(1 + tb^2)*
             Log[MS/Q] + gtau^2*tb*(1 + tb^2)*Log[MS/Q])*TCf[4][M2/\[Mu]] + 
          tb^2*((-38*g2^6*Log[MS/Q]*TCf[4][M2/\[Mu]])/3 + 
            (g2^4*M2*((3*g1^2*Log[MS/Q])/5 + 3*g2^2*Log[MS/Q] - 3*gb^2*
                Log[MS/Q] - 3*gt^2*Log[MS/Q] - gtau^2*Log[MS/Q] - 
               (3*gt^2*Log[MS/Q])/tb^2 - 3*gb^2*tb^2*Log[MS/Q] - gtau^2*tb^2*
                Log[MS/Q])*Derivative[1][TCf[4]][M2/\[Mu]])/\[Mu]))/
         (1 + tb^2)^2))/2 - 
     (8*((-4*g1^2*g2^2*tb^2*(-3*gt^2*Log[MS/Q] + 3*gb^2*tb^2*Log[MS/Q] + 
           gtau^2*tb^2*Log[MS/Q])*TCf[5][M1/\[Mu], M2/\[Mu]])/(1 + tb^2)^2 + 
        (2*g1^2*g2^2*tb*((-3*gt^2*(1 + tb^2)*Log[MS/Q])/tb + 
            3*gb^2*tb*(1 + tb^2)*Log[MS/Q] + gtau^2*tb*(1 + tb^2)*Log[MS/Q])*
           TCf[5][M1/\[Mu], M2/\[Mu]] + 
          tb^2*(((41*g1^4*g2^2*Log[MS/Q])/5 - (19*g1^2*g2^4*Log[MS/Q])/3)*
             TCf[5][M1/\[Mu], M2/\[Mu]] + (g1^2*g2^2*(-15*gt^2*Log[MS/Q] + 3*
                g1^2*tb^2*Log[MS/Q] + 15*g2^2*tb^2*Log[MS/Q] - 15*gb^2*tb^2*
                Log[MS/Q] - 15*gt^2*tb^2*Log[MS/Q] - 5*gtau^2*tb^2*
                Log[MS/Q] - 15*gb^2*tb^4*Log[MS/Q] - 5*gtau^2*tb^4*Log[MS/Q])*
              (M2*Derivative[0, 1][TCf[5]][M1/\[Mu], M2/\[Mu]] + M1*
                Derivative[1, 0][TCf[5]][M1/\[Mu], M2/\[Mu]]))/
             (5*tb^2*\[Mu])))/(1 + tb^2)^2))/5 - 
     (7*(((123*g1^4*g2^2*Log[MS/Q] - 95*g1^2*g2^4*Log[MS/Q] + 
           180*g1^2*g2^2*gt^2*Log[MS/Q] - 180*g1^2*g2^2*gb^2*tb^2*Log[MS/Q] - 
           180*g1^2*g2^2*gt^2*tb^2*Log[MS/Q] - 60*g1^2*g2^2*gtau^2*tb^2*
            Log[MS/Q] + 123*g1^4*g2^2*tb^4*Log[MS/Q] - 95*g1^2*g2^4*tb^4*
            Log[MS/Q] + 180*g1^2*g2^2*gb^2*tb^4*Log[MS/Q] + 
           60*g1^2*g2^2*gtau^2*tb^4*Log[MS/Q])*TCf[6][M1/\[Mu], M2/\[Mu]])/
         (25*(1 + tb^2)^2) + (3*(g1^2*g2^2 + g1^2*g2^2*tb^4)*
          (-15*gt^2*Log[MS/Q] + 3*g1^2*tb^2*Log[MS/Q] + 15*g2^2*tb^2*
            Log[MS/Q] - 15*gb^2*tb^2*Log[MS/Q] - 15*gt^2*tb^2*Log[MS/Q] - 
           5*gtau^2*tb^2*Log[MS/Q] - 15*gb^2*tb^4*Log[MS/Q] - 
           5*gtau^2*tb^4*Log[MS/Q])*(M2*Derivative[0, 1][TCf[6]][M1/\[Mu], 
             M2/\[Mu]] + M1*Derivative[1, 0][TCf[6]][M1/\[Mu], M2/\[Mu]]))/
         (25*tb^2*(1 + tb^2)^2*\[Mu])))/6 + 
     ((4*g1^2*g2^2*tb^2*(-3*gt^2*Log[MS/Q] + 3*gb^2*tb^2*Log[MS/Q] + 
          gtau^2*tb^2*Log[MS/Q])*TCf[7][M1/\[Mu], M2/\[Mu]])/(1 + tb^2)^2 - 
       (2*g1^2*g2^2*tb*((-3*gt^2*(1 + tb^2)*Log[MS/Q])/tb + 
           3*gb^2*tb*(1 + tb^2)*Log[MS/Q] + gtau^2*tb*(1 + tb^2)*Log[MS/Q])*
          TCf[7][M1/\[Mu], M2/\[Mu]] + 
         tb^2*(((41*g1^4*g2^2*Log[MS/Q])/5 - (19*g1^2*g2^4*Log[MS/Q])/3)*
            TCf[7][M1/\[Mu], M2/\[Mu]] + (g1^2*g2^2*(-15*gt^2*Log[MS/Q] + 
              3*g1^2*tb^2*Log[MS/Q] + 15*g2^2*tb^2*Log[MS/Q] - 
              15*gb^2*tb^2*Log[MS/Q] - 15*gt^2*tb^2*Log[MS/Q] - 
              5*gtau^2*tb^2*Log[MS/Q] - 15*gb^2*tb^4*Log[MS/Q] - 
              5*gtau^2*tb^4*Log[MS/Q])*(M2*Derivative[0, 1][TCf[7]][M1/\[Mu], 
                M2/\[Mu]] + M1*Derivative[1, 0][TCf[7]][M1/\[Mu], M2/\[Mu]]))/
            (5*tb^2*\[Mu])))/(1 + tb^2)^2)/5 - 
     (8*((g1*g2*tb*(123*g1^3*g2*Log[MS/Q] - 95*g1*g2^3*Log[MS/Q])*
          TCf[8][M1/\[Mu], M2/\[Mu]])/(10*Sqrt[15]*(1 + tb^2)) + 
        Sqrt[3/5]*g1*g2*((-2*g1*g2*tb*(-3*gt^2*Log[MS/Q] + 
             3*gb^2*tb^2*Log[MS/Q] + gtau^2*tb^2*Log[MS/Q])*
            TCf[8][M1/\[Mu], M2/\[Mu]])/(1 + tb^2) + 
          (g1*g2*((-3*gt^2*(1 + tb^2)*Log[MS/Q])/tb + 3*gb^2*tb*(1 + tb^2)*
               Log[MS/Q] + gtau^2*tb*(1 + tb^2)*Log[MS/Q])*TCf[8][M1/\[Mu], 
              M2/\[Mu]] + tb*(((41*g1^3*g2*Log[MS/Q])/10 - 
                (19*g1*g2^3*Log[MS/Q])/6)*TCf[8][M1/\[Mu], M2/\[Mu]] + 
              (g1*g2*(-15*gt^2*Log[MS/Q] + 3*g1^2*tb^2*Log[MS/Q] + 
                 15*g2^2*tb^2*Log[MS/Q] - 15*gb^2*tb^2*Log[MS/Q] - 
                 15*gt^2*tb^2*Log[MS/Q] - 5*gtau^2*tb^2*Log[MS/Q] - 
                 15*gb^2*tb^4*Log[MS/Q] - 5*gtau^2*tb^4*Log[MS/Q])*
                (M2*Derivative[0, 1][TCf[8]][M1/\[Mu], M2/\[Mu]] + 
                 M1*Derivative[1, 0][TCf[8]][M1/\[Mu], M2/\[Mu]]))/(5*tb^2*
                \[Mu])))/(1 + tb^2))))/Sqrt[15])/(16*Pi^2))
