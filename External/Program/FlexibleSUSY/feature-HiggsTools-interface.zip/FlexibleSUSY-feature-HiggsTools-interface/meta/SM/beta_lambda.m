{1/100 (27 g1^4 + 90 g1^2 (g2^2 - 2 \[Lambda]) + 25 (9 g2^4 - 36 g2^2
 \[Lambda] - 16 (3 gb^4 + 3 gt^4 + g\[Tau]^4 - 3 gb^2 \[Lambda] - 3
 gt^2 \[Lambda] - g\[Tau]^2 \[Lambda] - 3 \[Lambda]^2))),

 (1/1000)(-3411 g1^6 - 15 g1^4 (559 g2^2 - 60 gb^2 + 228 gt^2 + 300
 g\[Tau]^2 - 629 \[Lambda]) - 25 g1^2 (289 g2^4 - 6 g2^2 (36 gb^2 + 84
 gt^2 + 44 g\[Tau]^2 + 39 \[Lambda]) - 4 (16 gb^4 - 32 gt^4 - 48
 g\[Tau]^4 + 25 gb^2 \[Lambda] + 85 gt^2 \[Lambda] + 75 g\[Tau]^2
 \[Lambda] + 108 \[Lambda]^2)) + 125 (305 g2^6 + 12 g2^2 \[Lambda] (15
 gb^2 + 15 gt^2 + 5 g\[Tau]^2 + 36 \[Lambda]) - g2^4 (36 gb^2 + 36
 gt^2 + 12 g\[Tau]^2 + 73 \[Lambda]) - 8 (-60 gb^6 - 60 gt^6 - 20
 g\[Tau]^6 + 3 gt^4 \[Lambda] + g\[Tau]^4 \[Lambda] + 72 gt^2
 \[Lambda]^2 + 24 g\[Tau]^2 \[Lambda]^2 + 78 \[Lambda]^3 + 3 gb^4 (4
 gt^2 + \[Lambda]) + 16 g3^2 (4 gb^4 + 4 gt^4 - 5 gb^2 \[Lambda] - 5
 gt^2 \[Lambda]) + 6 gb^2 (2 gt^4 + 7 gt^2 \[Lambda] + 12
 \[Lambda]^2)))),

 (1/1440000)(243 g1^8 (-155535 + 99656 Zeta[3]) + 180 g1^6 (145569
 gb^2 + 376509 gt^2 + 296163 g\[Tau]^2 + 709112 \[Lambda] + 8640 gb^2
 Zeta[3] - 17280 gt^2 Zeta[3] - 25920 g\[Tau]^2 Zeta[3] - 214992
 \[Lambda] Zeta[3] + 9504 g3^2 (-17 + 16 Zeta[3]) + g2^2 (-237787 +
 156744 Zeta[3])) + 300 g1^4 (2 g2^4 (-81509 + 119718 Zeta[3]) + 9
 g2^2 (25441 gt^2 + 18051 g\[Tau]^2 + 74352 \[Lambda] - 2304 gt^2
 Zeta[3] - 5760 g\[Tau]^2 Zeta[3] - 7056 \[Lambda] Zeta[3] + 1056 g3^2
 (-17 + 16 Zeta[3]) + 3 gb^2 (7603 + 1152 Zeta[3])) - 2 (-67793 gt^4 -
 100944 gt^2 g\[Tau]^2 - 209979 g\[Tau]^4 + 203887 gt^2 \[Lambda] +
 132381 g\[Tau]^2 \[Lambda] + 361152 \[Lambda]^2 - 70968 gt^4 Zeta[3]
 - 81000 g\[Tau]^4 Zeta[3] + 129312 gt^2 \[Lambda] Zeta[3] + 106272
 g\[Tau]^2 \[Lambda] Zeta[3] + 69984 \[Lambda]^2 Zeta[3] + gb^4
 (104383 + 48840 Zeta[3]) + 144 g3^2 (66 \[Lambda] (-15 + 16 Zeta[3])
 + gb^2 (-683 + 432 Zeta[3]) + gt^2 (-587 + 432 Zeta[3])) + gb^2
 (-5904 g\[Tau]^2 + 54 gt^2 (709 + 64 Zeta[3]) + \[Lambda] (149623 +
 13536 Zeta[3])))) - 500 g1^2 (10 g2^6 (33133 + 8748 Zeta[3]) - 27
 g2^4 (3487 gt^2 + 1449 g\[Tau]^2 + 24548 \[Lambda] + 1728 gt^2
 Zeta[3] - 384 g\[Tau]^2 Zeta[3] - 6288 \[Lambda] Zeta[3] + 288 g3^2
 (-17 + 16 Zeta[3]) + 3 gb^2 (2033 + 768 Zeta[3])) + 36 g2^2 (1079
 gt^4 - 1392 gt^2 g\[Tau]^2 + 45 g\[Tau]^4 + 19527 gt^2 \[Lambda] +
 11313 g\[Tau]^2 \[Lambda] + 15984 \[Lambda]^2 + 17832 gt^4 Zeta[3] +
 9144 g\[Tau]^4 Zeta[3] - 16992 gt^2 \[Lambda] Zeta[3] - 12096
 g\[Tau]^2 \[Lambda] Zeta[3] + 7776 \[Lambda]^2 Zeta[3] + gb^4 (3239 +
 7464 Zeta[3]) + 48 g3^2 (3 gt^2 (-83 + 48 Zeta[3]) + gb^2 (-233 + 144
 Zeta[3])) + gb^2 (-2 gt^2 (1001 + 1488 Zeta[3]) + 3 (80 g\[Tau]^2 +
 3009 \[Lambda] - 384 \[Lambda] Zeta[3]))) - 24 (8 g3^2 (gb^2
 \[Lambda] (-991 + 720 Zeta[3]) + 2 gb^4 (-641 + 816 Zeta[3]) + gt^2
 (gt^2 (1862 - 672 Zeta[3]) + \[Lambda] (-2419 + 2448 Zeta[3]))) - 3
 (gb^4 (2 \[Lambda] (5737 - 5976 Zeta[3]) + gt^2 (2299 - 2496
 Zeta[3])) + gt^4 \[Lambda] (4970 - 2736 Zeta[3]) - gt^6 (3467 + 1632
 Zeta[3]) + gb^6 (-5111 + 2400 Zeta[3]) + 18 gt^2 \[Lambda] (24
 g\[Tau]^2 + \[Lambda] (65 + 64 Zeta[3])) - 3 (8 \[Lambda]^3 (-79 + 12
 Zeta[3]) - 78 g\[Tau]^4 \[Lambda] (-13 + 24 Zeta[3]) + 3 g\[Tau]^6
 (45 + 352 Zeta[3]) + 2 g\[Tau]^2 \[Lambda]^2 (-541 + 384 Zeta[3])) +
 gb^2 (4 gt^2 \[Lambda] (929 + 24 Zeta[3]) + 7 gt^4 (-191 + 384
 Zeta[3]) + 18 \[Lambda] (24 g\[Tau]^2 - 139 \[Lambda] + 256 \[Lambda]
 Zeta[3]))))) - 625 (3 g2^8 (-228259 + 481464 Zeta[3]) - 4 g2^6
 (-61641 gt^2 - 20547 g\[Tau]^2 + 232124 \[Lambda] + 171072 gt^2
 Zeta[3] + 57024 g\[Tau]^2 Zeta[3] + 636336 \[Lambda] Zeta[3] + 7776
 g3^2 (-17 + 16 Zeta[3]) + 81 gb^2 (-761 + 2112 Zeta[3])) + 216 g2^4
 (-3303 gt^4 - 48 gt^2 g\[Tau]^2 - 1085 g\[Tau]^4 + 2319 gt^2
 \[Lambda] + 773 g\[Tau]^2 \[Lambda] + 1852 \[Lambda]^2 + 2184 gt^4
 Zeta[3] + 728 g\[Tau]^4 Zeta[3] + 3744 gt^2 \[Lambda] Zeta[3] + 1248
 g\[Tau]^2 \[Lambda] Zeta[3] + 5472 \[Lambda]^2 Zeta[3] + 3 gb^4
 (-1101 + 728 Zeta[3]) + 16 g3^2 (18 \[Lambda] (-15 + 16 Zeta[3]) +
 gb^2 (-217 + 144 Zeta[3]) + gt^2 (-217 + 144 Zeta[3])) - 3 gb^2 (16
 g\[Tau]^2 + gt^2 (-590 + 832 Zeta[3]) - \[Lambda] (773 + 1248
 Zeta[3]))) - 288 g2^2 (8 g3^2 (gb^4 (-62 + 96 Zeta[3]) + gb^2 (32
 gt^2 (-1 + 12 Zeta[3]) + 3 \[Lambda] (-163 + 144 Zeta[3])) + gt^2
 (gt^2 (-62 + 96 Zeta[3]) + 3 \[Lambda] (-163 + 144 Zeta[3]))) - 3
 (-379 g\[Tau]^6 + 1058 g\[Tau]^4 \[Lambda] - 142 g\[Tau]^2
 \[Lambda]^2 + 632 \[Lambda]^3 + 96 g\[Tau]^6 Zeta[3] - 912 g\[Tau]^4
 \[Lambda] Zeta[3] + 384 g\[Tau]^2 \[Lambda]^2 Zeta[3] - 96
 \[Lambda]^3 Zeta[3] + 3 gb^6 (-379 + 96 Zeta[3]) + 3 gt^6 (-379 + 96
 Zeta[3]) - 6 gt^4 \[Lambda] (-553 + 456 Zeta[3]) + 6 gt^2 \[Lambda]
 (24 g\[Tau]^2 - 71 \[Lambda] + 192 \[Lambda] Zeta[3]) - 3 gb^4 (53
 gt^2 + 2 \[Lambda] (-553 + 456 Zeta[3])) - 3 gb^2 (53 gt^4 + 4 gt^2
 \[Lambda] (-59 + 24 Zeta[3]) - 2 \[Lambda] (24 g\[Tau]^2 - 71
 \[Lambda] + 192 \[Lambda] Zeta[3])))) - 192 (32 g3^4 (gb^2 (288 gt^2
 + \[Lambda] (311 - 36 Zeta[3])) + gb^4 (-133 + 48 Zeta[3]) + gt^2
 (\[Lambda] (311 - 36 Zeta[3]) + gt^2 (-133 + 48 Zeta[3]))) + 24 g3^2
 (gb^6 (-76 + 480 Zeta[3]) - 2 gb^2 (18 \[Lambda]^2 (17 - 16 Zeta[3])
 + gt^2 \[Lambda] (-41 + 48 Zeta[3]) + gt^4 (2 + 48 Zeta[3])) + gt^2
 (gt^2 \[Lambda] (895 - 1296 Zeta[3]) + 36 \[Lambda]^2 (-17 + 16
 Zeta[3]) + gt^4 (-76 + 480 Zeta[3])) - gb^4 (gt^2 (4 + 96 Zeta[3]) +
 \[Lambda] (-895 + 1296 Zeta[3]))) - 3 (286 g\[Tau]^8 + 1241 g\[Tau]^6
 \[Lambda] - 1434 g\[Tau]^4 \[Lambda]^2 - 582 g\[Tau]^2 \[Lambda]^3 -
 3588 \[Lambda]^4 + 6 gt^2 (99 g\[Tau]^6 - 320 g\[Tau]^4 \[Lambda] +
 144 g\[Tau]^2 \[Lambda]^2 - 291 \[Lambda]^3) + 192 g\[Tau]^8 Zeta[3]
 + 528 g\[Tau]^6 \[Lambda] Zeta[3] - 1008 g\[Tau]^4 \[Lambda]^2
 Zeta[3] - 2016 \[Lambda]^4 Zeta[3] + 6 gb^8 (533 + 96 Zeta[3]) + 6
 gt^8 (533 + 96 Zeta[3]) + 3 gb^6 (198 g\[Tau]^2 - 39 \[Lambda] + 528
 \[Lambda] Zeta[3] + 2 gt^2 (239 + 96 Zeta[3])) + 6 gt^4 (192
 g\[Tau]^4 - 320 g\[Tau]^2 \[Lambda] - 3 \[Lambda]^2 (191 + 168
 Zeta[3])) + 9 gt^6 (66 g\[Tau]^2 + \[Lambda] (-13 + 176 Zeta[3])) - 3
 gb^4 (-384 g\[Tau]^4 + 640 g\[Tau]^2 \[Lambda] + 384 gt^4 Zeta[3] + 6
 \[Lambda]^2 (191 + 168 Zeta[3]) + 3 gt^2 (10 g\[Tau]^2 + \[Lambda]
 (711 + 128 Zeta[3]))) + 3 gb^2 (198 g\[Tau]^6 - 640 g\[Tau]^4
 \[Lambda] + 288 g\[Tau]^2 \[Lambda]^2 - 582 \[Lambda]^3 - 4 gt^2 (16
 g\[Tau]^4 + 14 g\[Tau]^2 \[Lambda] + 3 \[Lambda]^2 (13 - 96 Zeta[3]))
 + 2 gt^6 (239 + 96 Zeta[3]) - 3 gt^4 (10 g\[Tau]^2 + \[Lambda] (711 +
 128 Zeta[3]))))))),

 (* from Chetyrkin, Zoller [JHEP 1606 (2016) 175] [arXiv:1604.00853]
    https://www.ttp.kit.edu/Progdata/ttp16/ttp16-008/ *)
 16/27 g3^6 gt^4 (13097 + 108 \[Pi]^4 + 44568 Zeta[3] - 47400 Zeta[5])
}
