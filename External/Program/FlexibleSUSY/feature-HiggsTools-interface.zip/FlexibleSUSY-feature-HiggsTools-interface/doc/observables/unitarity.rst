===========
Unitarity constraints
===========

Calculation relies on expression provided by SARAH and requires SARAH >= 4.13.0.
