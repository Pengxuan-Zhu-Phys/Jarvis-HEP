* TLaqasvars.h
* this file is part of FeynHiggs
* generated 5-Jun-2021 13:03

	ComplexType Tad(3), SE(7), SER(7), dAf1(-1:1,3:4,3:3)
	ComplexType dAf1Q(0:3,0:1,3:4,3:3)
	ComplexType dAf1s(0:3,-1:1,3:4,3:3)
	ComplexType dghBBL(-1:1,4), dghBBR(-1:1,4)
	ComplexType dghhSbSb(-1:1,4,4,2,2)
	ComplexType dghhStSt(-1:1,4,4,2,2)
	ComplexType dgHpHpSbSb(-1:1,1,1,2,2)
	ComplexType dgHpHpStSt(-1:1,1,1,2,2)
	ComplexType dgHpStSb(-1:1,1,2,2), dgHpTBL(-1:1,1)
	ComplexType dgHpTBR(-1:1,1), dghSbSb(-1:1,4,2,2)
	ComplexType dghStSt(-1:1,4,2,2), dghTTL(-1:1,4)
	ComplexType dghTTR(-1:1,4), dhb1hb(-1:1), dht1ht(-1:1)
	ComplexType dMf1(-1:1,3:4,3:3)
	ComplexType dMf1Q(0:3,0:1,3:4,3:3)
	ComplexType dMf1s(0:3,-1:1,3:4,3:3)
	ComplexType dMHiggs2gl(0:0,5,5), dMHiggsZ2gl(0:0,5,5)
	ComplexType dMHinsq2(0:0), dMHinsq2s(0:3,0:0)
	ComplexType dMSDsq1(-1:1,3:3)
	ComplexType dMSDsq1Q(0:3,0:1,3:3)
	ComplexType dMSDsq1s(0:3,-1:1,3:3)
	ComplexType dMSfsq1(-1:1,2,2,3:4,3:3)
	ComplexType dMsq11Sf1(-1:1,3:4,3:3)
	ComplexType dMsq12Sf1(-1:1,3:4,3:3)
	ComplexType dMsq21Sf1(-1:1,3:4,3:3)
	ComplexType dMsq22Sf1(-1:1,3:4,3:3)
	ComplexType dMSQsq1(-1:1,3:3)
	ComplexType dMSQsq1Q(0:3,0:1,3:3)
	ComplexType dMSQsq1s(0:3,-1:1,3:3)
	ComplexType dMSUsq1(-1:1,3:3)
	ComplexType dMSUsq1Q(0:3,0:1,3:3)
	ComplexType dMSUsq1s(0:3,-1:1,3:3), dTA02(0:0)
	ComplexType dTA02s(0:3,0:0), dTB2(0:0)
	ComplexType dTB2fingl(0:0), dTB2fingls(0:3,0:0)
	ComplexType dTh02(0:0), dTh02s(0:3,0:0), dTHH2(0:0)
	ComplexType dTHH2s(0:3,0:0), dZ11H2gl(0:0)
	ComplexType dZ11H2gls(0:3,0:0), dZ12H2gl(0:0)
	ComplexType dZ12H2gls(0:3,0:0), dZ21H2gl(0:0)
	ComplexType dZ21H2gls(0:3,0:0), dZ22H2gl(0:0)
	ComplexType dZ22H2gls(0:3,0:0), dZHiggs2gl(0:0,5,5)
	ComplexType gCGlBSbL(2), gCGlBSbR(2), gCGlTStL(2)
	ComplexType gCGlTStR(2), gChHpStSb(4,2,2,2)
	ComplexType gChhSbSb(4,4,2,2), gChhStSt(4,4,2,2)
	ComplexType gCHpHpSbSb(2,2,2,2), gCHpHpStSt(2,2,2,2)
	ComplexType gCHpStSb(2,2,2), gCHpTBL(2), gCHpTBR(2)
	ComplexType gChSbSb(4,2,2), gChStSt(4,2,2)
	ComplexType gCSbSbSbSb(2,2,2,2), gCSbSbSbSbV(2,2,2,2)
	ComplexType gCStStSbSb(2,2,2,2), gCStStSbSbV(2,2,2,2)
	ComplexType gCStStStSt(2,2,2,2), gCStStStStV(2,2,2,2)
	ComplexType gGlBSbL(2), gGlBSbR(2), gGlTStL(2), gGlTStR(2)
	ComplexType ghBBL(4), ghBBR(4), ghHpStSb(4,2,2,2)
	ComplexType ghhSbSb(4,4,2,2), ghhStSt(4,4,2,2)
	ComplexType gHpHpSbSb(2,2,2,2), gHpHpStSt(2,2,2,2)
	ComplexType gHpStSb(2,2,2), gHpTBL(2), gHpTBR(2)
	ComplexType ghSbSb(4,2,2), ghStSt(4,2,2), ghTTL(4), ghTTR(4)
	ComplexType gSbSbSbSb(2,2,2,2), gSbSbSbSbV(2,2,2,2)
	ComplexType gStStSbSb(2,2,2,2), gStStSbSbV(2,2,2,2)
	ComplexType gStStStSt(2,2,2,2), gStStStStV(2,2,2,2), MHC(2)
	ComplexType MHN(4), SEabashjhk2(4,4), SEatashjhk2(4,4)
	ComplexType SECTabashjhk2(4,4), SECTatashjhk2(4,4)
	ComplexType Tadabashj2(4), Tadatashj2(4), TadCTabashj2(4)
	ComplexType TadCTatashj2(4), ZHd(4), ZHu(4), ZPd(2), ZPu(2)
	common /aqasvar/ Tad, SE, SER, dAf1, dAf1Q, dAf1s, dghBBL
	common /aqasvar/ dghBBR, dghhSbSb, dghhStSt, dgHpHpSbSb
	common /aqasvar/ dgHpHpStSt, dgHpStSb, dgHpTBL, dgHpTBR
	common /aqasvar/ dghSbSb, dghStSt, dghTTL, dghTTR, dhb1hb
	common /aqasvar/ dht1ht, dMf1, dMf1Q, dMf1s, dMHiggs2gl
	common /aqasvar/ dMHiggsZ2gl, dMHinsq2, dMHinsq2s, dMSDsq1
	common /aqasvar/ dMSDsq1Q, dMSDsq1s, dMSfsq1, dMsq11Sf1
	common /aqasvar/ dMsq12Sf1, dMsq21Sf1, dMsq22Sf1, dMSQsq1
	common /aqasvar/ dMSQsq1Q, dMSQsq1s, dMSUsq1, dMSUsq1Q
	common /aqasvar/ dMSUsq1s, dTA02, dTA02s, dTB2, dTB2fingl
	common /aqasvar/ dTB2fingls, dTh02, dTh02s, dTHH2, dTHH2s
	common /aqasvar/ dZ11H2gl, dZ11H2gls, dZ12H2gl, dZ12H2gls
	common /aqasvar/ dZ21H2gl, dZ21H2gls, dZ22H2gl, dZ22H2gls
	common /aqasvar/ dZHiggs2gl, gCGlBSbL, gCGlBSbR, gCGlTStL
	common /aqasvar/ gCGlTStR, gChHpStSb, gChhSbSb, gChhStSt
	common /aqasvar/ gCHpHpSbSb, gCHpHpStSt, gCHpStSb, gCHpTBL
	common /aqasvar/ gCHpTBR, gChSbSb, gChStSt, gCSbSbSbSb
	common /aqasvar/ gCSbSbSbSbV, gCStStSbSb, gCStStSbSbV
	common /aqasvar/ gCStStStSt, gCStStStStV, gGlBSbL, gGlBSbR
	common /aqasvar/ gGlTStL, gGlTStR, ghBBL, ghBBR, ghHpStSb
	common /aqasvar/ ghhSbSb, ghhStSt, gHpHpSbSb, gHpHpStSt
	common /aqasvar/ gHpStSb, gHpTBL, gHpTBR, ghSbSb, ghStSt
	common /aqasvar/ ghTTL, ghTTR, gSbSbSbSb, gSbSbSbSbV
	common /aqasvar/ gStStSbSb, gStStSbSbV, gStStStSt
	common /aqasvar/ gStStStStV, MHC, MHN, SEabashjhk2
	common /aqasvar/ SEatashjhk2, SECTabashjhk2, SECTatashjhk2
	common /aqasvar/ Tadabashj2, Tadatashj2, TadCTabashj2
	common /aqasvar/ TadCTatashj2, ZHd, ZHu, ZPd, ZPu

	ComplexType GS, hb, ht, Nc, SECTHpHp2, SEHpHp2, SqrtEGl
	ComplexType SqrtEGlC
	common /aqasvar/ GS, hb, ht, Nc, SECTHpHp2, SEHpHp2, SqrtEGl
	common /aqasvar/ SqrtEGlC

	ComplexType QSt, QSb, QT, QB, QTMS, QBMS, QAt, QAb
	common /aqasvar/ QSt, QSb, QT, QB, QTMS, QBMS, QAt, QAb

	integer TAGsusy, TAGthdm, TAGdreg, Stscheme, Sbscheme
	integer Tscheme, Bscheme, Atscheme, Abscheme, TB2Lscheme
	integer Z2Lscheme, H2Lscheme
	common /aqasvar/ TAGsusy, TAGthdm, TAGdreg, Stscheme
	common /aqasvar/ Sbscheme, Tscheme, Bscheme, Atscheme
	common /aqasvar/ Abscheme, TB2Lscheme, Z2Lscheme, H2Lscheme

	integer DR, OS, MDR, MS_SM
	parameter (DR = 0, OS = 1, MDR = 2, MS_SM = 3)
