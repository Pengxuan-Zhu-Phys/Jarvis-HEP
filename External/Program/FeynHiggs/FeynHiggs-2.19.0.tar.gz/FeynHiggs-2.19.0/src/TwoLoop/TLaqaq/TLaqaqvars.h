* TLaqaqvars.h
* this file is part of FeynHiggs
* generated 26-Aug-2022 14:44

	ComplexType Tad(3), SE(7), SER(7), dAf1(-1:1,3:4,3:3)
	ComplexType dAf1Q(0:3,0:1,3:4,3:3)
	ComplexType dAf1s(0:3,-1:1,3:4,3:3), dCB1(-1:1)
	ComplexType dghBBL(-1:1,4), dghBBR(-1:1,4)
	ComplexType dghhSbSb(-1:1,4,4,2,2)
	ComplexType dghhStSt(-1:1,4,4,2,2)
	ComplexType dgHpHpSbSb(-1:1,1,1,2,2)
	ComplexType dgHpHpStSt(-1:1,1,1,2,2)
	ComplexType dgHpStSb(-1:1,1,2,2), dgHpTBL(-1:1,1)
	ComplexType dgHpTBR(-1:1,1), dghSbSb(-1:1,4,2,2)
	ComplexType dghStSt(-1:1,4,2,2), dghTTL(-1:1,4)
	ComplexType dghTTR(-1:1,4), dhb1hb(-1:1), dht1ht(-1:1)
	ComplexType dMf1(-1:1,3:4,3:3)
	ComplexType dMf1Q(0:3,0:1,3:4,3:3)
	ComplexType dMf1s(0:3,-1:1,3:4,3:3)
	ComplexType dMHiggs1gl(-1:1,6,6), dMHiggs2gl(0:0,5,5)
	ComplexType dMHiggsZ2gl(0:0,5,5), dMHinsq1(-1:1)
	ComplexType dMHinsq1s(0:3,-1:1), dMHinsq2(0:0)
	ComplexType dMHinsq2s(0:3,0:0), dMSDsq1(-1:1,3:3)
	ComplexType dMSDsq1Q(0:3,0:1,3:3)
	ComplexType dMSDsq1s(0:3,-1:1,3:3)
	ComplexType dMSfsq1(-1:1,2,2,3:4,3:3)
	ComplexType dMsq11Sf1(-1:1,3:4,3:3)
	ComplexType dMsq12Sf1(-1:1,3:4,3:3)
	ComplexType dMsq21Sf1(-1:1,3:4,3:3)
	ComplexType dMsq22Sf1(-1:1,3:4,3:3)
	ComplexType dMSQsq1(-1:1,3:3)
	ComplexType dMSQsq1Q(0:3,0:1,3:3)
	ComplexType dMSQsq1s(0:3,-1:1,3:3)
	ComplexType dMSUsq1(-1:1,3:3)
	ComplexType dMSUsq1Q(0:3,0:1,3:3)
	ComplexType dMSUsq1s(0:3,-1:1,3:3), dMUE1(-1:1)
	ComplexType dMUE1Q(0:3,0:1), dMUE1s(0:3,-1:1)
	ComplexType dMWsq1MW2(-1:1), dMWsq1MW2Q(0:3,0:1)
	ComplexType dMWsq1MW2s(0:3,-1:1), dSB1(-1:1)
	ComplexType dTA01(-1:1), dTA01s(0:3,-1:1)
	ComplexType dTA02(0:0), dTA02s(0:3,0:0), dTB1(-1:1)
	ComplexType dTB1finglQ(0:3,0:1)
	ComplexType dTB1fingls(0:3,-1:1), dTB1finitegl(-1:1)
	ComplexType dTB2(0:0), dTB2fingl(0:0)
	ComplexType dTB2fingls(0:3,0:0), dTG01(-1:1)
	ComplexType dTG01s(0:3,-1:1), dTh01(-1:1)
	ComplexType dTh01s(0:3,-1:1), dTh02(0:0)
	ComplexType dTh02s(0:3,0:0), dTHH1(-1:1)
	ComplexType dTHH1s(0:3,-1:1), dTHH2(0:0)
	ComplexType dTHH2s(0:3,0:0), dv1(-1:1)
	ComplexType dZ11H1gl(-1:1), dZ11H1glQ(0:3,0:1)
	ComplexType dZ11H1gls(0:3,-1:1), dZ11H2gl(0:0)
	ComplexType dZ11H2gls(0:3,0:0), dZ12H1gl(-1:1)
	ComplexType dZ12H1glQ(0:3,0:1), dZ12H1gls(0:3,-1:1)
	ComplexType dZ12H2gl(0:0), dZ12H2gls(0:3,0:0)
	ComplexType dZ21H1gl(-1:1), dZ21H1glQ(0:3,0:1)
	ComplexType dZ21H1gls(0:3,-1:1), dZ21H2gl(0:0)
	ComplexType dZ21H2gls(0:3,0:0), dZ22H1gl(-1:1)
	ComplexType dZ22H1glQ(0:3,0:1), dZ22H1gls(0:3,-1:1)
	ComplexType dZ22H2gl(0:0), dZ22H2gls(0:3,0:0)
	ComplexType dZbarHiggs1gl(-1:1,5:6,5:5)
	ComplexType dZHiggs1gl(-1:1,6,6), dZHiggs2gl(0:0,5,5)
	ComplexType gCBStL(2:2,2), gCBStR(2:2,2)
	ComplexType gCCBStL(2:2,2), gCCBStR(2:2,2)
	ComplexType gCCTSbL(2:2,2), gCCTSbR(2:2,2)
	ComplexType gChHpStSb(4,2,2,2), gChhSbSb(4,4,2,2)
	ComplexType gChhStSt(4,4,2,2), gCHpHpSbSb(2,2,2,2)
	ComplexType gCHpHpStSt(2,2,2,2), gCHpStSb(2,2,2), gCHpTBL(2)
	ComplexType gCHpTBR(2), gChSbSb(4,2,2), gChStSt(4,2,2)
	ComplexType gCNBSbL(3:4,2), gCNBSbR(3:4,2)
	ComplexType gCNTStL(3:4,2), gCNTStR(3:4,2)
	ComplexType gCSbSbSbSb(2,2,2,2), gCSbSbSbSbV(2,2,2,2)
	ComplexType gCStStSbSb(2,2,2,2), gCStStSbSbV(2,2,2,2)
	ComplexType gCStStStSt(2,2,2,2), gCStStStStV(2,2,2,2)
	ComplexType gCTSbL(2:2,2), gCTSbR(2:2,2), ghBBL(4)
	ComplexType ghBBR(4), ghHpStSb(4,2,2,2), ghhSbSb(4,4,2,2)
	ComplexType ghhStSt(4,4,2,2), gHpHpSbSb(2,2,2,2)
	ComplexType gHpHpStSt(2,2,2,2), gHpStSb(2,2,2), gHpTBL(2)
	ComplexType gHpTBR(2), ghSbSb(4,2,2), ghStSt(4,2,2)
	ComplexType ghTTL(4), ghTTR(4), gNBSbL(3:4,2)
	ComplexType gNBSbR(3:4,2), gNTStL(3:4,2)
	ComplexType gNTStR(3:4,2), gSbSbSbSb(2,2,2,2)
	ComplexType gSbSbSbSbV(2,2,2,2), gStStSbSb(2,2,2,2)
	ComplexType gStStSbSbV(2,2,2,2), gStStStSt(2,2,2,2)
	ComplexType gStStStStV(2,2,2,2), MHC(2), MHN(4)
	ComplexType SECThjhk2(4,4), SEhjhk2(4,4), TadCThj2(4)
	ComplexType Tadhj2(4), UChaCgl(2,2:2), UChagl(2,2:2)
	ComplexType ZHd(4), ZHu(4), ZNeuCgl(3:4,3:4)
	ComplexType ZNeugl(3:4,3:4), ZPd(2), ZPu(2)
	common /aqaqvar/ Tad, SE, SER, dAf1, dAf1Q, dAf1s, dCB1
	common /aqaqvar/ dghBBL, dghBBR, dghhSbSb, dghhStSt
	common /aqaqvar/ dgHpHpSbSb, dgHpHpStSt, dgHpStSb, dgHpTBL
	common /aqaqvar/ dgHpTBR, dghSbSb, dghStSt, dghTTL, dghTTR
	common /aqaqvar/ dhb1hb, dht1ht, dMf1, dMf1Q, dMf1s
	common /aqaqvar/ dMHiggs1gl, dMHiggs2gl, dMHiggsZ2gl
	common /aqaqvar/ dMHinsq1, dMHinsq1s, dMHinsq2, dMHinsq2s
	common /aqaqvar/ dMSDsq1, dMSDsq1Q, dMSDsq1s, dMSfsq1
	common /aqaqvar/ dMsq11Sf1, dMsq12Sf1, dMsq21Sf1, dMsq22Sf1
	common /aqaqvar/ dMSQsq1, dMSQsq1Q, dMSQsq1s, dMSUsq1
	common /aqaqvar/ dMSUsq1Q, dMSUsq1s, dMUE1, dMUE1Q, dMUE1s
	common /aqaqvar/ dMWsq1MW2, dMWsq1MW2Q, dMWsq1MW2s, dSB1
	common /aqaqvar/ dTA01, dTA01s, dTA02, dTA02s, dTB1
	common /aqaqvar/ dTB1finglQ, dTB1fingls, dTB1finitegl, dTB2
	common /aqaqvar/ dTB2fingl, dTB2fingls, dTG01, dTG01s, dTh01
	common /aqaqvar/ dTh01s, dTh02, dTh02s, dTHH1, dTHH1s, dTHH2
	common /aqaqvar/ dTHH2s, dv1, dZ11H1gl, dZ11H1glQ, dZ11H1gls
	common /aqaqvar/ dZ11H2gl, dZ11H2gls, dZ12H1gl, dZ12H1glQ
	common /aqaqvar/ dZ12H1gls, dZ12H2gl, dZ12H2gls, dZ21H1gl
	common /aqaqvar/ dZ21H1glQ, dZ21H1gls, dZ21H2gl, dZ21H2gls
	common /aqaqvar/ dZ22H1gl, dZ22H1glQ, dZ22H1gls, dZ22H2gl
	common /aqaqvar/ dZ22H2gls, dZbarHiggs1gl, dZHiggs1gl
	common /aqaqvar/ dZHiggs2gl, gCBStL, gCBStR, gCCBStL
	common /aqaqvar/ gCCBStR, gCCTSbL, gCCTSbR, gChHpStSb
	common /aqaqvar/ gChhSbSb, gChhStSt, gCHpHpSbSb, gCHpHpStSt
	common /aqaqvar/ gCHpStSb, gCHpTBL, gCHpTBR, gChSbSb
	common /aqaqvar/ gChStSt, gCNBSbL, gCNBSbR, gCNTStL, gCNTStR
	common /aqaqvar/ gCSbSbSbSb, gCSbSbSbSbV, gCStStSbSb
	common /aqaqvar/ gCStStSbSbV, gCStStStSt, gCStStStStV
	common /aqaqvar/ gCTSbL, gCTSbR, ghBBL, ghBBR, ghHpStSb
	common /aqaqvar/ ghhSbSb, ghhStSt, gHpHpSbSb, gHpHpStSt
	common /aqaqvar/ gHpStSb, gHpTBL, gHpTBR, ghSbSb, ghStSt
	common /aqaqvar/ ghTTL, ghTTR, gNBSbL, gNBSbR, gNTStL
	common /aqaqvar/ gNTStR, gSbSbSbSb, gSbSbSbSbV, gStStSbSb
	common /aqaqvar/ gStStSbSbV, gStStStSt, gStStStStV, MHC, MHN
	common /aqaqvar/ SECThjhk2, SEhjhk2, TadCThj2, Tadhj2
	common /aqaqvar/ UChaCgl, UChagl, ZHd, ZHu, ZNeuCgl, ZNeugl
	common /aqaqvar/ ZPd, ZPu

	ComplexType hb, ht, Nc, rMUE, SECTHpHp2, SEHpHp2
	common /aqaqvar/ hb, ht, Nc, rMUE, SECTHpHp2, SEHpHp2

	ComplexType MHSM2, TAGsusy, TAGthdm, QSt, QSb, QT, QB, QTMS
	ComplexType QBMS, QAt, QAb, QMUE, Qvev, Qtb, QZ
	common /aqaqvar/ MHSM2, TAGsusy, TAGthdm, QSt, QSb, QT, QB
	common /aqaqvar/ QTMS, QBMS, QAt, QAb, QMUE, Qvev, Qtb, QZ

	integer Stscheme, Sbscheme, Tscheme, Bscheme, Atscheme
	integer Abscheme, vevscheme, Hscheme, MUEscheme, Zscheme
	integer TBscheme, TB2Lscheme, Z2Lscheme, H2Lscheme
	common /aqaqvar/ Stscheme, Sbscheme, Tscheme, Bscheme
	common /aqaqvar/ Atscheme, Abscheme, vevscheme, Hscheme
	common /aqaqvar/ MUEscheme, Zscheme, TBscheme, TB2Lscheme
	common /aqaqvar/ Z2Lscheme, H2Lscheme

	integer DR, OS, MDR, MS_SM
	parameter (DR = 0, OS = 1, MDR = 2, MS_SM = 3)
