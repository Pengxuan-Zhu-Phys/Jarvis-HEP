import os
import shutil
from multiprocessing.pool import ThreadPool

import numpy as np
import matplotlib.pyplot as plt

import torch
import torch.nn as nn
import torch.optim as optim
from torch.autograd import Variable


# ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# Scan settings
# ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

N_PARAM = 1
N_OBS = 1

N_INIT = 200
N_INC = 200
N_RANDOM = 40
N_TEST = 10000


# ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# Define parameter space and proposal distributions of parameters.
# ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

def RandomParameters(n):
    """ Generate random parameters with specified proposal distributions.

    Parameters
    ==========

    n: int
        Number of parameters to be generated.

    Returns
    ==========

    x: numpy array
        Parameters, whose shape is [n, N_PARAM].

    Examples
    ==========

    Parameter `i` is uniformly distributed on [5, 80],
    ```
    x[:, i] = np.random.rand(n) * (80 - 5) + 5
    ```

    Parameter `j` has a log distribution on [0.01, 1000],
    ```
    x[:, i] = 10**(np.random.rand(n) * (np.log10(1000) - np.log10(0.01)) + np.log10(0.01))
    ```

    Parameter `k` has a Gaussian distribution with mean 5 and standard deviation 0.3,
    ```
    x[:, k] = np.random.randn(n) * 0.3 + 5
    ```
    """
    return np.random.rand(n, 1) * 4 - 2


# ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# Define the exact calculation of physical observables.
# ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

def Observables(x):
    """ Calculate the observables for given parameter points.

    Parameters
    ==========

    x: list / numpy array
        Parameters, whose shape is [N_POINT, N_PARAM].

    Returns
    ==========

    obs: numpy array
        Observables, whose shape is [N_POINT, N_OBS].
    """
    return x**2

# ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# Define the exact calculation of physical observables.
# ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++


def LogLikelihood(y):
    """ Calculate the likelihoods of given observables.

    Parameters
    ==========

    obs: numpy array
        Observables, whose shape is [N_POINT, N_OBS].

    Returns
    ==========

    logL: numpy array
        Likelihoods, whose shape is [N_POINT].
    """
    chi2 = (y - 2)**2 / 0.1**2
    return np.reshape(-chi2 / 2, [-1])


# === DEBUG ===
# Observables([[9701, 2881, 50.3, 8869, 173.78]])
# Observables([[4509.84777063, 2560.34500122, 48.3477828904, -285.50977604, 173.807745798]])
# exit()

# ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# Define machine learning models.
# ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

class Regressor():
    def __init__(self, model, x_dim, y_dim, learning_rate=1e-2):
        self.model = model

        # Training method
        self.criterion = nn.MSELoss()
        self.optimizer = optim.Adam(self.model.parameters(), lr=learning_rate)

        # Data normalization parameters
        self.x_mean = np.zeros([1, x_dim])
        self.x_std = np.ones([1, x_dim])

        self.y_mean = np.zeros([1, y_dim])
        self.y_std = np.ones([1, y_dim])

    def train(self, x, y, epoch=1000):
        # Normalize the data
        self.x_mean = np.mean(x, axis=0)
        self.x_std = np.std(x, axis=0)

        self.y_mean = np.mean(y, axis=0)
        self.y_std = np.std(y, axis=0)

        x = (x - self.x_mean) / self.x_std
        y = (y - self.y_mean) / self.y_std

        # Train
        x = torch.Tensor(x)
        y = torch.Tensor(y)

        for i in range(epoch):
            yhat = self.model(Variable(x))
            loss = self.criterion(yhat, Variable(y))
            self.optimizer.zero_grad()
            loss.backward()
            self.optimizer.step()

            if i % (epoch / 10) == 0:
                print('epoch %d, loss %g' % (i, loss.item()))

    def predict(self, x):
        x = (x - self.x_mean) / self.x_std
        x = Variable(torch.Tensor(x))
        yhat = self.model(x).data.cpu().numpy()
        return yhat * self.y_std + self.y_mean

    def save(self, path):
        torch.save(self.model, path)
        with open(path + '.norm', 'w') as f:
            f.write(' '.join(map(str, self.x_mean)) + '\n')
            f.write(' '.join(map(str, self.x_std)) + '\n')
            f.write(' '.join(map(str, self.y_mean)) + '\n')
            f.write(' '.join(map(str, self.y_std)) + '\n')



# Several neural network regressors are used to fit physical observables.
reg_model = Regressor(nn.Sequential(nn.Linear(N_PARAM, 100), nn.ReLU(),
                                    nn.Linear(100, 100), nn.ReLU(),
                                    nn.Linear(100, 1)), N_PARAM, N_OBS)


# ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# Explore the parameter space.
# ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#
# Initial samples.
#
Tx = RandomParameters(N_INIT)
Ty = Observables(Tx)
Tl = LogLikelihood(Ty)

for round in range(1, 100):
    print('\n======== ROUND %d ========' % round)

    # --------------------------------------
    # Train the models.
    # --------------------------------------

    reg_model.train(Tx, Ty)

    # --------------------------------------
    # Recommend points.
    # --------------------------------------

    print('\n--- Recommend points ---\n')
    Dx = np.zeros([0, N_PARAM])

    while len(Dx) < N_INC - N_RANDOM:
        # Generate large number of samples randomly.
        x = RandomParameters(N_TEST)

        # Sample according to likelihoods.
        y = reg_model.predict(x)
        logL = LogLikelihood(y)
        x = x[np.log(np.random.rand(len(x))) < logL - np.max(logL)]
        print(Dx)
        print('11111111111111111111111111')
        print(x)
        print('222222222222222222222222222222222222')
        # Append to recommended set.
        Dx = np.concatenate([Dx, x])
        print(Dx)
        print('3333333333333333333333333333333333')

        print('max logL', np.max(logL), 'recommend', x.shape, 'total', Dx.shape)

    Dx = Dx[:N_INC - N_RANDOM]

    # Add some random samples to enhance exploration.
    Dx = np.concatenate([Dx, RandomParameters(N_RANDOM)])

    # --------------------------------------
    # Exactly calculate the observables of recommended points.
    # --------------------------------------

    Dy = Observables(Dx)
    Dl = LogLikelihood(Dy)

    # --------------------------------------
    # Append to the training set.
    # --------------------------------------

    Tx = np.concatenate([Tx, Dx])
    Ty = np.concatenate([Ty, Dy])
    Tl = np.concatenate([Tl, Dl])

    # --------------------------------------
    # Output
    # --------------------------------------

    # Write training samples into file.
    os.makedirs('T', exist_ok=True)
    with open('T/%d.txt' % round, 'w') as f:
        for i in range(len(Tx)):
            for t in Tx[i]:
                f.write(str(t) + ' ')
            for t in Ty[i]:
                f.write(str(t) + ' ')
            f.write(str(Tl[i]) + '\n')

    # Write recommended samples into file.
    os.makedirs('D', exist_ok=True)
    with open('D/%d.txt' % round, 'w') as f:
        for i in range(len(Dx)):
            for t in Dx[i]:
                f.write(str(t) + ' ')
            for t in Dy[i]:
                f.write(str(t) + ' ')
            f.write(str(Dl[i]) + '\n')

    # Save machine learning models.
    os.makedirs('Models', exist_ok=True)
    reg_model.save('Models/reg-%d.torch' % round)
