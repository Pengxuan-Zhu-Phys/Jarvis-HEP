import os
import sys
import numpy as np
import pyslha

phys, lhc, lux, hb = 1, 0, 0, 0
omg, gm2, bsg, bsmumu, Rbtaunu, mh1, mW, SW2eff = 0, 0, 0, 0, 0, 0, 0, 0

try:
    in_template = sys.argv[1]
    m0, m12, A0, tanb, mu, mt = map(float, sys.argv[2:8])

    # +++++++++++++++++++++++++++++++++++++++++++++
    # LHC limit
    # +++++++++++++++++++++++++++++++++++++++++++++

    os.system('$LHCLIMITS/LHClimits.py %g %g > lhc_limits.out' % (m0, m12))
    lhc = np.loadtxt('lhc_limits.out', dtype=np.int)

    # +++++++++++++++++++++++++++++++++++++++++++++
    # softsusy
    # +++++++++++++++++++++++++++++++++++++++++++++

    with open(in_template) as f:
        text = f.read()
    text = text.replace('<<<m0>>>', str(m0))
    text = text.replace('<<<m12>>>', str(m12))
    text = text.replace('<<<tanb>>>', str(tanb))
    text = text.replace('<<<A0>>>', str(A0))
    text = text.replace('<<<mt>>>', str(mt))
    text = text.replace('<<<mu>>>', str(mu))
    with open('softsusy.in', 'w') as f:
        f.write(text)

    os.system('$SOFTSUSY/softpoint.x leshouches < softsusy.in > softsusy.out')

    # +++++++++++++++++++++++++++++++++++++++++++++
    # micrOMEGAS
    # +++++++++++++++++++++++++++++++++++++++++++++

    os.system('$MICROMEGAS/MSSM/main softsusy.out > micromegas.stdout')
    data = np.loadtxt('micromegas.out')
    omg, mn1, DMSI = data[0], data[1], data[2]

    if omg < 0:
        raise Exception('omg < 0')

    # +++++++++++++++++++++++++++++++++++++++++++++
    # LUXlimit
    # +++++++++++++++++++++++++++++++++++++++++++++

    os.system('$LUXLIMITS/LUXlimits.py %g %g > lux_limits.out' % (mn1, DMSI))
    lux = np.loadtxt('lux_limits.out', dtype=np.int)

    # +++++++++++++++++++++++++++++++++++++++++++++
    # HiggsBounds
    # +++++++++++++++++++++++++++++++++++++++++++++

    os.system('$HIGGSBOUNDS/HBSLHAinputblocksfromFH softsusy.out > higgsbounds.stdout')

    slha = pyslha.read('softsusy.out.fh')
    mh1 = slha.blocks['MASS'][25]

    data = np.loadtxt('HBmwandsin.dat')
    mW, SW2eff = data[0], data[1]

    # +++++++++++++++++++++++++++++++++++++++++++++
    # HiggsSignals
    # +++++++++++++++++++++++++++++++++++++++++++++

    os.system('$HIGGSSIGNALS/HBandHSwithSLHA > higgssignals.stdout')

    data = np.loadtxt('softsusy.out.fh-fromHBandHS')
    hb = data[4]

    # +++++++++++++++++++++++++++++++++++++++++++++
    # superiso
    # +++++++++++++++++++++++++++++++++++++++++++++

    os.system('$SUPERISO/slha.x softsusy.out > superiso.out')
    with open('superiso.out') as f:
        lines = f.readlines()
        bsg = float(lines[7].split()[2])
        bsmumu = float(lines[10].split()[2])
        Rbtaunu = float(lines[33].split()[2])

    # +++++++++++++++++++++++++++++++++++++++++++++
    # gm2calc
    # +++++++++++++++++++++++++++++++++++++++++++++

    os.system(
        '$GM2CALC/gm2calc.x --slha-input-file=softsusy.out > gm2.out 2> gm2.stderr')
    slha = pyslha.read('gm2.out')
    gm2 = slha.blocks['SPHENOLOWENERGY'][21]

except:
    phys = 0

finally:
    with open('results.dat', 'w') as f:
        f.write('%d %d %d %d %e %e %e %e %e %e %e %e' % (phys, lhc, lux, hb, omg, gm2, bsg, bsmumu, Rbtaunu, mh1, mW, SW2eff, mn1, DMSI))
