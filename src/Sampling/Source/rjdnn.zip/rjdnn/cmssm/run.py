import os
import shutil
from multiprocessing.pool import ThreadPool

import numpy as np
import matplotlib.pyplot as plt

import torch
import torch.nn as nn
import torch.optim as optim
from torch.autograd import Variable


# ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# Scan settings
# ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

N_PARAM = 6
N_OBS = 14

N_INIT = 200
N_INC = 200
N_RANDOM = 40
N_SAMPLE = 100000


# ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# Define parameter space and proposal distributions of parameters.
# ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

def RandomParameters(n):
    """ Generate random parameters with specified proposal distributions.

    Parameters
    ==========

    n: int
        Number of parameters to be generated.

    Returns
    ==========

    x: numpy array
        Parameters, whose shape is [n, N_PARAM].

    Examples
    ==========

    Parameter `i` is uniformly distributed on [5, 80],
    ```
    x[:, i] = np.random.rand(n) * (80 - 5) + 5
    ```

    Parameter `j` has a log distribution on [0.01, 1000],
    ```
    x[:, i] = 10**(np.random.rand(n) * (np.log10(1000) - np.log10(0.01)) + np.log10(0.01))
    ```

    Parameter `k` has a Gaussian distribution with mean 5 and standard deviation 0.3,
    ```
    x[:, k] = np.random.randn(n) * 0.3 + 5
    ```
    """
    x = np.empty([n, N_PARAM])
    x[:, 0] = np.random.rand(n) * (10000 - 100) + 100               # M0    linear [100, 10000]
    x[:, 1] = np.random.rand(n) * (4000 - 500) + 500                # M1/2  linear [500, 4000]
    x[:, 2] = np.random.rand(n) * (10000 - (-10000)) + (-10000)     # A0    linear [-10000, 10000]
    x[:, 3] = np.random.rand(n) * (68 - 2) + 2                      # tanb  linear [2, 68]
    x[:, 4] = np.random.randint(2, size=n) * 2 - 1                  # mu    int    -1, 1
    x[:, 5] = np.random.rand(n) * (174 - 172) + 172                 # mt    linear [172, 174]
    return x


# ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# Define the exact calculation of physical observables.
# ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

def Observables(x):
    """ Calculate the observables for given parameter points.

    Parameters
    ==========

    x: list / numpy array
        Parameters, whose shape is [N_POINT, N_PARAM].

    Returns
    ==========

    obs: numpy array
        Observables, whose shape is [N_POINT, N_OBS].
    """

    # A helper function calculate the observables of one parameter point, in a concurrent environment.
    def calc(x, i):
        try:
            os.makedirs('raw/%d' % i)
            os.system('cd raw/%d; python3 ../../calc.py ../../softsusy.in.template %g %g %g %g %g %g > stdout 2>&1' % (i, *x))
            y = np.loadtxt('raw/%d/results.dat' % i)
            print('[%d]' % i, *x, *y, LogLikelihood(y.reshape([1, -1])))
            return y
        except Exception as e:
            print('[%d]' % i, e)
            return [0] * N_OBS
        finally:
            shutil.rmtree('raw/%d' % i)

    # Calculate the observables concurrently using a thread pool.
    pool = ThreadPool()
    tasks = []
    for i, x_ in enumerate(x):
        t = pool.apply_async(calc, (x_, i))
        tasks.append(t)
    pool.close()
    pool.join()

    # Collect the calcuated observables.
    obs = np.zeros([len(x), N_OBS])
    for i, t in enumerate(tasks):
        obs[i] = t.get()
    return obs

# ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# Define the exact calculation of physical observables.
# ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++


def LogLikelihood(obs):
    """ Calculate the likelihoods of given observables.

    Parameters
    ==========

    obs: numpy array
        Observables, whose shape is [N_POINT, N_OBS].

    Returns
    ==========

    logL: numpy array
        Likelihoods, whose shape is [N_POINT].
    """
    chi2 = np.zeros(len(obs))
    chi2 += (obs[:, 4] - 0.1187)**2 / 0.01198**2
    chi2 += (obs[:, 5] - 26.1E-10)**2 / 8.2E-10**2
    chi2 += (obs[:, 6] - 3.43E-4)**2 / 0.326E-4**2
    chi2 += (obs[:, 7] - 2.9E-9)**2 / 0.76E-9**2
    chi2 += (obs[:, 8] - 1.04)**2 / 0.34**2
    chi2 += (obs[:, 9] - 125.36)**2 / 2.04**2
    chi2 += (obs[:, 10] - 80.385)**2 / 0.018**2
    chi2 += (obs[:, 11] - 0.23153)**2 / 0.00019**2
    return -chi2 / 2

# === DEBUG ===
# Observables([[9701, 2881, 8869, 50.3, 1, 173.78], [9701, 2881, 8869, 50.3, 1, 173.78]])
# exit()


# ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# Define machine learning models.
# ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

class Regressor():
    def __init__(self, model, x_dim, y_dim, learning_rate=1e-2):
        self.model = model.cuda()

        # Training method
        self.criterion = nn.MSELoss()
        self.optimizer = optim.Adam(self.model.parameters(), lr=learning_rate)

        # Data normalization parameters
        self.x_mean = np.zeros([1, x_dim])
        self.x_std = np.ones([1, x_dim])

        self.y_mean = np.zeros([1, y_dim])
        self.y_std = np.ones([1, y_dim])

    def train(self, x, y, epoch=1000):
        # Normalize the data
        self.x_mean = np.mean(x, axis=0)
        self.x_std = np.std(x, axis=0)

        self.y_mean = np.mean(y, axis=0)
        self.y_std = np.std(y, axis=0)

        x = (x - self.x_mean) / self.x_std
        y = (y - self.y_mean) / self.y_std

        # Train
        x = torch.Tensor(x).cuda()
        y = torch.Tensor(y).cuda()

        for i in range(epoch):
            yhat = self.model(Variable(x))
            loss = self.criterion(yhat, Variable(y))
            self.optimizer.zero_grad()
            loss.backward()
            self.optimizer.step()

            if i % (epoch / 10) == 0:
                print('epoch %d, loss %g' % (i, loss.data[0]))

    def predict(self, x):
        x = (x - self.x_mean) / self.x_std
        x = Variable(torch.Tensor(x).cuda())
        yhat = self.model(x).data.cpu().numpy()
        return yhat * self.y_std + self.y_mean

    def save(self, path):
        torch.save(self.model, path)
        with open(path + '.norm', 'w') as f:
            f.write(' '.join(map(str, self.x_mean)) + '\n')
            f.write(' '.join(map(str, self.x_std)) + '\n')
            f.write(' '.join(map(str, self.y_mean)) + '\n')
            f.write(' '.join(map(str, self.y_std)) + '\n')


class Classifier():
    def __init__(self, model, x_dim, learning_rate=1e-2):
        self.model = model.cuda()
        self.x_dim = x_dim

        # Training method
        self.criterion = nn.BCELoss()
        self.optimizer = optim.Adam(self.model.parameters(), lr=learning_rate)

        # Data normalization parameters
        self.x_mean = np.zeros([1, x_dim])
        self.x_std = np.ones([1, x_dim])

    def train(self, x, y, epoch=1000):
        # Normalize the data
        self.x_mean = np.mean(x, axis=0)
        self.x_std = np.std(x, axis=0)

        x = (x - self.x_mean) / self.x_std

        # Train
        x = torch.Tensor(x).cuda()
        y = torch.Tensor(y).cuda()

        for i in range(epoch):
            yhat = self.model(Variable(x))
            loss = self.criterion(yhat, Variable(y))
            self.optimizer.zero_grad()
            loss.backward()
            self.optimizer.step()

            if i % (epoch / 10) == 0:
                print('epoch %d, loss %g' % (i, loss.data[0]))

    def predict(self, x):
        x = (x - self.x_mean) / self.x_std
        x = Variable(torch.Tensor(x).cuda())
        return self.model(x).data.cpu().numpy()

    def save(self, path):
        torch.save(self.model, path)
        with open(path + '.norm', 'w') as f:
            f.write(' '.join(map(str, self.x_mean)) + '\n')
            f.write(' '.join(map(str, self.x_std)) + '\n')


# One neural network classifier is used to identify non-physical and excluded parameter points.
cls_model = Classifier(nn.Sequential(nn.Linear(N_PARAM, 100), nn.ReLU(),
                                     nn.Linear(100, 100), nn.ReLU(),
                                     nn.Linear(100, 100), nn.ReLU(),
                                     nn.Linear(100, 100), nn.ReLU(),
                                     nn.Linear(100, 1), nn.Sigmoid()), N_PARAM)

# Several neural network regressors are used to fit physical observables.
reg_models = [Regressor(nn.Sequential(nn.Linear(N_PARAM, 100), nn.ReLU(),
                                      nn.Linear(100, 100), nn.ReLU(),
                                      nn.Linear(100, 100), nn.ReLU(),
                                      nn.Linear(100, 100), nn.ReLU(),
                                      nn.Linear(100, 1)), N_PARAM, 1) for _ in range(8)]


# ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# Explore the parameter space.
# ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#
# Initial samples.
#
Tx = RandomParameters(N_INIT)
Ty = Observables(Tx)
Tl = LogLikelihood(Ty)

for round in range(1, 100000000):
    print('\n======== ROUND %d ========' % round)

    # --------------------------------------
    # Train the models.
    # --------------------------------------

    print('\n--- Train physical/non-physical classifier ---\n')
    cls_model.train(Tx, Ty[:, 0, np.newaxis])

    for i, reg_model in enumerate(reg_models):
        print('\n--- Train regressor %d ---\n' % i)
        reg_model.train(Tx[Ty[:, 0] == 1], Ty[Ty[:, 0] == 1, i + 4, np.newaxis])

    # --------------------------------------
    # Recommend points.
    # --------------------------------------

    print('\n--- Recommend points ---\n')
    Dx = np.zeros([0, N_PARAM])

    while len(Dx) < N_INC - N_RANDOM:
        x = np.zeros([0, N_PARAM])

        while len(X) < N_SAMPLE:
            # Generate large number of samples randomly.
            x_ = RandomParameters(N_SAMPLE)

            # Filter out the non-physical and excluded points.
            y = cls_model.predict(x_).reshape(-1)
            x_ = x_[y > 0.5]

            x = np.vstack([x, x_])

        # Sample according to likelihoods.
        y = np.hstack([np.ones([len(x), 4]), *[reg_models[i].predict(x) for i in range(len(reg_models))], np.zeors([len(x), 2])])
        logL = LogLikelihood(y)
        x = x[np.log(np.random.rand(len(x))) < logL - np.max(logL)]

        # Append to recommended set.
        Dx = np.vstack([Dx, x])
        print('max logL', np.max(logL), 'recommend', x.shape, 'total', Dx.shape)

    Dx = Dx[:N_INC - N_RANDOM]

    # Add some random samples to enhance exploration.
    Dx = np.vstack([Dx, RandomParameters(N_RANDOM)])

    # --------------------------------------
    # Exactly calculate the observables of recommended points.
    # --------------------------------------

    Dy = Observables(Dx)
    Dl = LogLikelihood(Dy)

    # --------------------------------------
    # Append to the training set.
    # --------------------------------------

    Tx = np.vstack([Tx, Dx])
    Ty = np.vstack([Ty, Dy])
    Tl = np.vstack([Tl, Dl])

    # --------------------------------------
    # Output
    # --------------------------------------

    # Write training samples into file.
    os.makedirs('T', exist_ok=True)
    with open('T/%d.txt' % round, 'w') as f:
        for i in range(len(Tx)):
            for t in Tx[i]:
                f.write(str(t) + ' ')
            for t in Ty[i]:
                f.write(str(t) + ' ')
            f.write(str(Tl[i]) + '\n')

    # Write recommended samples into file.
    os.makedirs('D', exist_ok=True)
    with open('D/%d.txt' % round, 'w') as f:
        for i in range(len(Dx)):
            for t in Dx[i]:
                f.write(str(t) + ' ')
            for t in Dy[i]:
                f.write(str(t) + ' ')
            f.write(str(Dl[i]) + '\n')

    # Save machine learning models.
    os.makedirs('Models', exist_ok=True)
    cls_model.save('Models/cls-%d.torch' % round)
    for i, reg_model in enumerate(reg_models):
        reg_model.save('Models/reg%d-%d.torch' % (i, round))
