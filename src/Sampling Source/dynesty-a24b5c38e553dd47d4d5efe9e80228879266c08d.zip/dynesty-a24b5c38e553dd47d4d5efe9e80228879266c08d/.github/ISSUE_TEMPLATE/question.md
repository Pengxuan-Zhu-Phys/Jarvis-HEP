---
name: Question
about: Ask us a question
title: ''
labels: 'question'
assignees: ''

---

** Dynesty version **
Specify the exact version, and how you installed it (pip/git)

** Your question **
Ask your question
If you are not sure it is a bug or not, please submit the bug report instead.