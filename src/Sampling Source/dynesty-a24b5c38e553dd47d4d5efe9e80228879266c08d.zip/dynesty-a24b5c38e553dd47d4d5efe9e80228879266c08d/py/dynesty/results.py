#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Utilities for handling results.

"""

from .utils import print_fn, Results

__all__ = ["Results", "print_fn"]
