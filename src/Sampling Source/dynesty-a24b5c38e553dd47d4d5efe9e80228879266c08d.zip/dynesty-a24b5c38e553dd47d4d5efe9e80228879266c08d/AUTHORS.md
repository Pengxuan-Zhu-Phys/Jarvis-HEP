Authors:

- [Josh Speagle](https://github.com/joshspeagle)
- [Sergey Koposov](https://github.com/segasai)

Contributors:

- [Kyle Barbary](https://github.com/kbarbary/)
- [Johannes Buchner](https://github.com/JohannesBuchner)
- [Ben Cook](https://github.com/bacook17)
- [James Guillochon](https://github.com/guillochon)
- [Ben Johnson](https://github.com/bd-j)
- [Ed Bennett](https://github.com/edbennett)

Feedback:

- [Ana Bonaca](https://github.com/abonaca)
- [Phil Cargile](https://github.com/pacargile)
- [Hannah Diamond-Lowe](https://github.com/hdiamondlowe)
- [Joel Leja](https://github.com/jrleja)
- [Ashley Villar](https://github.com/villrv)
- [Avi Vajpeyi](https://github.com/avivajpeyi)
- [Catherine Zucker](https://github.com/catherinezucker)

If you have contributed and your name is missing, please contact @segasai and/or @joshspeagle
