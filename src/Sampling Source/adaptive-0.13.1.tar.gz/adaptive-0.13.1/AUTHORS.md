## Authors

The current maintainers of Adaptive are:

- [Bas Nijholt](<http://nijho.lt>)
- [Joseph Weston](<https://joseph.weston.cloud>)
- [Anton Akhmerov](<https://antonakhmerov.org>)

Other contributors to Adaptive include:

- Andrey E. Antipov
- [Christoph Groth](<http://inac.cea.fr/Pisp/christoph.groth/>)
- Jorn Hoofwijk
- Philippe Solodov (@philippeitis)
- Victor Negîrneac (@caenrigen)
- Thomas A Caswell (@tacaswell)
- Álvaro Gómez Iñesta (@AlvaroGI)
- Sultan Orazbayev (@SultanOrazbayev)
- Thomas Aarholt (@thomasaarholt)
